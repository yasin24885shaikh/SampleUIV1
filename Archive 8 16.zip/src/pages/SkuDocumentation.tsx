import { Fragment, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Alert,
  Avatar,
  Box,
  Button,
  Chip,
  Collapse,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  LinearProgress,
  Pagination,
  Paper,
  MenuItem,
  Select,
  Stack,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Tooltip,
  Typography,
  alpha,
  useTheme
} from '@mui/material';
import CalendarMonthRoundedIcon from '@mui/icons-material/CalendarMonthRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';
import ArrowDownwardRoundedIcon from '@mui/icons-material/ArrowDownwardRounded';
import SwapVertRoundedIcon from '@mui/icons-material/SwapVertRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import RestartAltRoundedIcon from '@mui/icons-material/RestartAltRounded';
import GridViewRoundedIcon from '@mui/icons-material/GridViewRounded';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import ExpandLessRoundedIcon from '@mui/icons-material/ExpandLessRounded';
import SyncRoundedIcon from '@mui/icons-material/SyncRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import FileDownloadRoundedIcon from '@mui/icons-material/FileDownloadRounded';
import ViewColumnRoundedIcon from '@mui/icons-material/ViewColumnRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import CloudOffRoundedIcon from '@mui/icons-material/CloudOffRounded';
import { AnimatePresence, motion } from 'framer-motion';
import type { Theme } from '@mui/material/styles';
import PageHeader from '../components/PageHeader';
import {
  skuTraceApi,
  skuTraceTabKeys,
  productAttributeColumnKeys,
  type BannerTrace,
  type ProductAttributeColumnKey,
  type ProductAttributeTrace,
  type SellingChannelTrace,
  type SkuExclusionTrace,
  type SkuAvailabilityTrace,
  type SkuSizeAvailability,
  type SkuTraceSearchResult,
  type SkuTraceTabResponse,
  type WarehouseSizeAvailability,
  type XrefTrace
} from '../services/skuTraceApi';

type SkuStatus = 'A' | 'D' | 'I' | '';
type YesNo = 'Yes' | 'No' | '' | null;
type FrenchValue = 'Yes' | 'No' | 'N/A';
type InventoryStatus = 'Yes' | 'No';
type LaunchType = 'Cool' | 'Hot' | 'Atomic' | 'Flow';
type Row = {
  sku: string;
  skuStatus: SkuStatus;
  launchReservationDate: string;
  frCopy: YesNo;
  frName: YesNo;
  launchType: LaunchType;
  changeDate: string;
  description: string;
  image: YesNo;
  copy: YesNo;
  productType: YesNo;
  sportsAttribute: YesNo;
  field1: string;
  field2: string;
  field3: string;
  field4: string;
  launchDate: string;
  launchedBanners: string;
  banners: string;
  frenchName: FrenchValue;
  frenchCopy: FrenchValue;
  availableInIex: InventoryStatus;
  avavailableInIexStore: InventoryStatus;
  avavailbleInIexWhse: InventoryStatus;
  avavailableInIexDropship: InventoryStatus;
};
type SortKey = keyof Row;
type ResultView = 'all' | 'launch' | 'productAttributes' | 'inventory';
type SeedRow = Omit<Row, 'launchDate' | 'launchedBanners' | 'banners' | 'frenchName' | 'frenchCopy' | 'availableInIex' | 'avavailableInIexStore' | 'avavailbleInIexWhse' | 'avavailableInIexDropship'>;
type AppliedSearch =
  | { type: 'date'; date: string }
  | { type: 'manual'; skus: string[] };

const skuSeedRows: SeedRow[] = [
  { sku: '314103249004', skuStatus: 'A', launchReservationDate: '2026-08-01', frCopy: 'Yes', frName: 'Yes', launchType: 'Atomic', changeDate: '2026-07-14', description: 'Nike Air Max Dn8 - Men\'s', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 1', field2: 'NA', field3: 'Digital', field4: 'Ready' },
  { sku: '314103249104', skuStatus: 'A', launchReservationDate: '2026-08-01', frCopy: 'Yes', frName: null, launchType: 'Hot', changeDate: '2026-07-14', description: 'Nike Air Max Dn8 - Women\'s', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'No', field1: 'Tier 1', field2: 'NA', field3: 'Digital', field4: 'Review' },
  { sku: '316705839804', skuStatus: 'A', launchReservationDate: '2026-07-29', frCopy: 'Yes', frName: 'Yes', launchType: 'Cool', changeDate: '2026-07-13', description: 'adidas Originals Samba OG - Kids\'', image: 'Yes', copy: 'Yes', productType: 'No', sportsAttribute: 'Yes', field1: 'Tier 2', field2: 'US', field3: 'Store', field4: 'Review' },
  { sku: '314216734104', skuStatus: 'I', launchReservationDate: '2026-08-08', frCopy: '', frName: 'Yes', launchType: 'Hot', changeDate: '2026-07-12', description: 'New Balance 9060 - Men\'s', image: 'No', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 1', field2: 'CA', field3: 'Digital', field4: 'Hold' },
  { sku: '317138201204', skuStatus: 'A', launchReservationDate: '2026-08-15', frCopy: 'No', frName: 'Yes', launchType: 'Atomic', changeDate: '2026-07-11', description: 'Jordan Retro 4 - Grade School', image: 'Yes', copy: 'No', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 1', field2: 'NA', field3: 'Omni', field4: 'Review' },
  { sku: '316475000204', skuStatus: 'D', launchReservationDate: '2026-07-26', frCopy: '', frName: '', launchType: 'Cool', changeDate: '2026-07-10', description: 'PUMA Speedcat OG - Women\'s', image: 'No', copy: 'No', productType: 'Yes', sportsAttribute: 'No', field1: 'Tier 3', field2: 'US', field3: 'Store', field4: 'Hold' },
  { sku: '318202118404', skuStatus: 'A', launchReservationDate: '2026-07-30', frCopy: 'Yes', frName: 'Yes', launchType: 'Hot', changeDate: '2026-07-10', description: 'Crocs Classic Clog - Unisex', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 2', field2: 'NA', field3: 'Omni', field4: 'Ready' },
  { sku: '314521908104', skuStatus: 'A', launchReservationDate: '2026-08-22', frCopy: 'Yes', frName: 'Yes', launchType: 'Atomic', changeDate: '2026-07-09', description: 'ASICS GEL-Kayano 14 - Men\'s', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 1', field2: 'NA', field3: 'Digital', field4: 'Ready' },
  { sku: '315552107704', skuStatus: 'A', launchReservationDate: '2026-07-25', frCopy: 'Yes', frName: 'No', launchType: 'Cool', changeDate: '2026-07-08', description: 'Converse Chuck 70 Plus - Unisex', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'No', field1: 'Tier 2', field2: 'US', field3: 'Store', field4: 'Review' },
  { sku: '317649102804', skuStatus: 'I', launchReservationDate: '2026-08-05', frCopy: 'No', frName: 'Yes', launchType: 'Hot', changeDate: '2026-07-07', description: 'Nike Dunk Low - Preschool', image: 'Yes', copy: 'No', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 2', field2: 'CA', field3: 'Digital', field4: 'Hold' },
  { sku: '314208734504', skuStatus: 'A', launchReservationDate: '2026-08-29', frCopy: 'Yes', frName: 'Yes', launchType: 'Atomic', changeDate: '2026-07-06', description: 'Jordan Tatum 4 - Men\'s Basketball', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 1', field2: 'NA', field3: 'Omni', field4: 'Ready' },
  { sku: '316842017304', skuStatus: 'D', launchReservationDate: '2026-07-24', frCopy: 'No', frName: 'No', launchType: 'Cool', changeDate: '2026-07-05', description: 'Vans Knu Skool - Women\'s', image: 'No', copy: 'Yes', productType: 'Yes', sportsAttribute: 'No', field1: 'Tier 3', field2: 'US', field3: 'Store', field4: 'Hold' },
  { sku: '318415709904', skuStatus: 'A', launchReservationDate: '2026-08-12', frCopy: 'Yes', frName: 'Yes', launchType: 'Hot', changeDate: '2026-07-04', description: 'UGG Tasman II - Women\'s', image: 'Yes', copy: 'Yes', productType: 'Yes', sportsAttribute: 'Yes', field1: 'Tier 2', field2: 'NA', field3: 'Digital', field4: 'Ready' }
];

const rows: Row[] = skuSeedRows.map((row, index) => ({
  ...row,
  skuStatus: index === 12 ? '' : row.skuStatus,
  launchDate: `${row.changeDate} 00:00:00.000`,
  launchReservationDate: `${row.launchReservationDate} 00:00:00.000`,
  launchType: index === 9 ? 'Flow' : row.launchType,
  launchedBanners: ['FL, CS, KFL', 'FL, FLCA', 'CS, CSCA', 'FL, KFL, FLCA', 'FL, CSCA'][index % 5],
  banners: ['CHP, FL, KIDS', 'FL, FLCA', 'CHP, CSCA', 'FL, KIDS, CSCA', 'FL, FLCA, CSCA'][index % 5],
  frenchName: index % 6 === 1 ? 'N/A' : row.frName || 'N/A',
  frenchCopy: index % 5 === 2 ? 'N/A' : row.frCopy || 'N/A',
  availableInIex: index % 2 ? 'No' : 'Yes',
  avavailableInIexStore: index % 3 ? 'Yes' : 'No',
  avavailbleInIexWhse: index % 2 ? 'Yes' : 'No',
  avavailableInIexDropship: index % 2 ? 'No' : 'Yes'
}));

function toResultRow(result: SkuTraceSearchResult): Row {
  return {
    sku: result.sku,
    skuStatus: result.skuStatus,
    launchDate: result.launchDate,
    launchReservationDate: result.launchReservationDate,
    launchType: result.launchType,
    launchedBanners: result.launchedBanners,
    banners: result.banners,
    description: result.description,
    image: result.image,
    copy: result.copy,
    productType: result.productType,
    sportsAttribute: result.sportsAttribute,
    frenchName: result.frenchName,
    frenchCopy: result.frenchCopy,
    availableInIex: result.availableInIex,
    avavailableInIexStore: result.avavailableInIexStore,
    avavailbleInIexWhse: result.avavailbleInIexWhse,
    avavailableInIexDropship: result.avavailableInIexDropship,
    changeDate: result.launchDate.slice(0, 10),
    frCopy: result.frenchCopy === 'N/A' ? '' : result.frenchCopy,
    frName: result.frenchName === 'N/A' ? '' : result.frenchName,
    field1: '',
    field2: '',
    field3: '',
    field4: ''
  };
}

const columns: { key: SortKey; label: string; minWidth?: number }[] = [
  { key: 'sku', label: 'SKU', minWidth: 150 },
  { key: 'skuStatus', label: 'Status', minWidth: 72 },
  { key: 'launchDate', label: 'Launch date', minWidth: 125 },
  { key: 'launchReservationDate', label: 'Launch res. date', minWidth: 125 },
  { key: 'launchType', label: 'Launch type', minWidth: 110 },
  { key: 'launchedBanners', label: 'Launched banners', minWidth: 165 },
  { key: 'banners', label: 'Banners', minWidth: 150 },
  { key: 'description', label: 'Description', minWidth: 240 },
  { key: 'image', label: 'Image', minWidth: 90 },
  { key: 'copy', label: 'Copy', minWidth: 85 },
  { key: 'productType', label: 'Product type', minWidth: 120 },
  { key: 'sportsAttribute', label: 'Sports attribute', minWidth: 140 },
  { key: 'frenchName', label: 'French name', minWidth: 105 },
  { key: 'frenchCopy', label: 'French copy', minWidth: 105 },
  { key: 'availableInIex', label: 'Available in IEX', minWidth: 120 },
  { key: 'avavailableInIexStore', label: 'Available in IEX Store', minWidth: 140 },
  { key: 'avavailbleInIexWhse', label: 'Available in IEX Warehouse', minWidth: 155 },
  { key: 'avavailableInIexDropship', label: 'Available in IEX Dropship', minWidth: 150 }
];

const resultViewColumns: Record<ResultView, SortKey[]> = {
  all: ['sku', 'skuStatus', 'description'],
  launch: ['sku', 'skuStatus', 'launchDate', 'launchReservationDate', 'launchType', 'launchedBanners'],
  productAttributes: ['sku', 'skuStatus', 'banners', 'image', 'copy', 'productType', 'sportsAttribute', 'frenchName', 'frenchCopy'],
  inventory: ['sku', 'skuStatus', 'availableInIex', 'avavailableInIexStore', 'avavailbleInIexWhse', 'avavailableInIexDropship']
};

const detailTabs = ['Banners', 'Selling Channel', 'SKU Availability', 'Product Attributes', 'UPC', 'Xref', 'Exclusions', 'Dirty Node'];

function polishedTableSx(theme: Theme) {
  return {
    borderCollapse: 'separate' as const,
    borderSpacing: 0,
    '& .MuiTableCell-root': {
      borderRight: `1px solid ${alpha(theme.palette.divider, .95)}`,
      borderBottom: `1px solid ${alpha(theme.palette.divider, .95)}`
    },
    '& .MuiTableRow-root > .MuiTableCell-root:last-of-type': { borderRight: 0 },
    '& thead .MuiTableCell-root': {
      background: '#2f668f !important',
      boxShadow: 'inset 0 3px 0 #92c7e8',
      color: '#ffffff !important'
    },
    '& thead .MuiTableRow-root:first-of-type .MuiButton-root': {
      color: '#ffffff !important'
    },
    '& thead .MuiTableRow-root:nth-of-type(2) .MuiTableCell-root': {
      backgroundColor: `${theme.palette.mode === 'light' ? '#e8edf3' : '#243446'} !important`,
      boxShadow: 'none',
      color: `${theme.palette.text.primary} !important`
    },
    '& tbody .MuiTableCell-root': {
      bgcolor: theme.palette.mode === 'light' ? '#ffffff' : '#1a2028'
    },
    '& tbody .MuiTableRow-root:nth-of-type(even) .MuiTableCell-root': {
      bgcolor: theme.palette.mode === 'light' ? '#edf3f8' : '#25303c'
    },
    '& tbody .MuiTableRow-root:nth-of-type(even) .MuiTableCell-root:first-of-type': {
      boxShadow: `inset 3px 0 0 ${alpha(theme.palette.info.main, .55)}`
    },
    '& tbody .MuiTableRow-root:hover .MuiTableCell-root': {
      bgcolor: `${alpha(theme.palette.primary.main, theme.palette.mode === 'light' ? .075 : .13)} !important`
    }
  };
}

export default function SkuDocumentation() {
  const theme = useTheme();
  const [launchDate, setLaunchDate] = useState('2026-07-14');
  const [skuText, setSkuText] = useState('');
  const [searched, setSearched] = useState(true);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [sort, setSort] = useState<{ key: SortKey; direction: 'asc' | 'desc' }>({ key: 'launchDate', direction: 'desc' });
  const [selectedSku, setSelectedSku] = useState<Row | null>(null);
  const [tab, setTab] = useState(0);
  const [page, setPage] = useState(1);
  const [resultView, setResultView] = useState<ResultView>('all');
  const [searchCollapsed, setSearchCollapsed] = useState(false);
  const [appliedSearch, setAppliedSearch] = useState<AppliedSearch>({ type: 'date', date: '2026-07-14' });
  const [searching, setSearching] = useState(false);
  const [searchRows, setSearchRows] = useState<Row[]>(rows);
  const [searchError, setSearchError] = useState('');
  const [expandedSkus, setExpandedSkus] = useState<Set<string>>(new Set());
  const [onlineStatuses, setOnlineStatuses] = useState<Record<string, boolean>>({});
  const [checkingOnline, setCheckingOnline] = useState(false);
  const searchProgress = useApiProgress(searching);

  const enteredSkus = skuText.split(/[\s,;]+/).map((value) => value.trim()).filter(Boolean);
  const overLimit = enteredSkus.length > 50;
  const dateMode = Boolean(launchDate) && enteredSkus.length === 0;
  const manualMode = enteredSkus.length > 0;

  const sourceRows = searchRows;

  const filteredRows = useMemo(() => {
    const query = globalSearch.toLowerCase().trim();
    return [...sourceRows]
      .filter((row) => !query || Object.values(row).some((value) => String(value ?? '').toLowerCase().includes(query)))
      .filter((row) => columns.every(({ key }) => {
        const filter = columnFilters[key]?.toLowerCase().trim();
        return !filter || String(row[key] ?? '').toLowerCase().includes(filter);
      }))
      .sort((a, b) => {
        const comparison = String(a[sort.key] ?? '').localeCompare(String(b[sort.key] ?? ''), undefined, { numeric: true, sensitivity: 'base' });
        return sort.direction === 'asc' ? comparison : -comparison;
      });
  }, [columnFilters, globalSearch, sort, sourceRows]);
  const pageCount = Math.max(1, Math.ceil(filteredRows.length / 5));
  const visibleRows = filteredRows.slice((page - 1) * 5, page * 5);
  const activeColumns = useMemo(
    () => resultViewColumns[resultView].map((key) => columns.find((column) => column.key === key)!).filter(Boolean),
    [resultView]
  );
  const readyCount = filteredRows.filter((row) => row.image === 'Yes' && row.copy === 'Yes' && row.productType === 'Yes' && row.sportsAttribute === 'Yes').length;
  const attentionCount = filteredRows.length - readyCount;

  const setSortKey = (key: SortKey) => {
    setSort((current) => current.key === key
      ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
      : { key, direction: 'asc' });
  };

  const handleSearch = async () => {
    if (!overLimit && (launchDate || enteredSkus.length)) {
      const nextSearch: AppliedSearch = enteredSkus.length
        ? { type: 'manual', skus: [...new Set(enteredSkus)] }
        : { type: 'date', date: launchDate };
      setSearched(false);
      setSearching(true);
      setSearchError('');
      setSearchRows([]);
      setExpandedSkus(new Set());
      setOnlineStatuses({});
      setAppliedSearch(nextSearch);
      setGlobalSearch('');
      setColumnFilters({});
      setPage(1);
      setSearchCollapsed(true);
      try {
        const response = await skuTraceApi.search(
          nextSearch.type === 'manual'
            ? { skus: nextSearch.skus }
            : { launchDate: nextSearch.date }
        );
        setSearchRows(response.results.map(toResultRow));
        setCheckingOnline(true);
        void skuTraceApi.checkOnlineAvailability(response.results.map((result) => ({
          sku: result.sku,
          banners: [...new Set([...result.launchedBanners.split(','), ...result.banners.split(',')].map((banner) => banner.trim()).filter(Boolean))]
        }))).then((onlineResponse) => {
          setOnlineStatuses(Object.fromEntries(onlineResponse.results.map((result) => [`${result.sku}:${result.banner.toUpperCase()}`, result.online])));
        }).catch(() => {
          setOnlineStatuses({});
        }).finally(() => setCheckingOnline(false));
      } catch (error) {
        setSearchError(error instanceof Error ? error.message : 'Unable to load SKU trace results.');
      } finally {
        setSearching(false);
        setSearched(true);
      }
    }
  };

  return (
    <Box
      sx={{
        position: 'relative',
        isolation: 'isolate',
        '&:before': {
          content: '""',
          position: 'absolute',
          zIndex: -1,
          top: -70,
          right: -30,
          width: 310,
          height: 310,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${alpha(theme.palette.primary.main, .09)} 0%, transparent 68%)`,
          pointerEvents: 'none'
        }
      }}
    >
      <PageHeader
        title="SKU Tracert"
        subtitle="Trace SKU readiness from product configuration through site publication in one operational view."
        badge="PRODUCT → SITES"
      />

      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .36, ease: 'easeOut' }}>
        <Paper
          elevation={0}
          sx={{
          position: 'relative', overflow: 'hidden', mb: 2.25, borderRadius: 3,
          border: `1px solid ${alpha(theme.palette.primary.main, 0.18)}`,
          background: theme.palette.mode === 'light'
            ? 'radial-gradient(circle at 92% 5%, rgba(215,25,32,.09), transparent 34%), linear-gradient(145deg, #ffffff 0%, #f6f8fb 100%)'
            : 'radial-gradient(circle at 92% 5%, rgba(215,25,32,.18), transparent 34%), linear-gradient(145deg, #202630 0%, #151a21 100%)',
            boxShadow: `0 16px 44px ${alpha('#18202b', theme.palette.mode === 'light' ? 0.11 : 0.3)}`,
            transition: 'box-shadow .25s ease, border-color .25s ease',
            '&:hover': {
              borderColor: alpha(theme.palette.primary.main, .28),
              boxShadow: `0 20px 52px ${alpha('#18202b', theme.palette.mode === 'light' ? .14 : .34)}`
            }
          }}
        >
        <Box sx={{ height: 4, background: 'linear-gradient(90deg, #d71920, #ff5b60 42%, #242a33 42%)' }} />
        <Box sx={{ p: { xs: 1.5, md: 1.9 } }}>
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" gap={1.25} sx={{ mb: 1.4 }}>
            <Box>
              <Stack direction="row" alignItems="center" spacing={1}>
                <Box
                  component={motion.div}
                  whileHover={{ rotate: 8, scale: 1.06 }}
                  sx={{ width: 32, height: 32, display: 'grid', placeItems: 'center', borderRadius: 1.6, color: '#fff', bgcolor: 'primary.main', boxShadow: `0 8px 20px ${alpha(theme.palette.primary.main, .3)}` }}
                >
                  <TuneRoundedIcon fontSize="small" />
                </Box>
                <Box>
                  <Typography variant="h6" fontWeight={950}>Find SKUs to trace</Typography>
                  <Typography variant="body2" color="text.secondary">Choose one launch date or enter specific SKUs manually.</Typography>
                </Box>
              </Stack>
            </Box>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ sm: 'center' }}>
              <Stack direction="row" spacing={.6} alignItems="center" flexWrap="wrap" useFlexGap>
                {['Product config', 'Assets', 'Channels', 'Sites'].map((step, index) => (
                  <Stack key={step} direction="row" spacing={.6} alignItems="center">
                    <Chip size="small" label={step} variant={index === 0 ? 'filled' : 'outlined'} color={index === 0 ? 'primary' : 'default'} sx={{ fontWeight: 850, bgcolor: index === 0 ? undefined : alpha(theme.palette.background.paper, .74) }} />
                    {index < 3 && <Typography color="text.disabled" fontWeight={900}>›</Typography>}
                  </Stack>
                ))}
              </Stack>
              {searched && (
                <Button
                  size="small"
                  variant={searchCollapsed ? 'contained' : 'text'}
                  startIcon={searchCollapsed ? <ExpandMoreRoundedIcon /> : <ExpandLessRoundedIcon />}
                  onClick={() => setSearchCollapsed((current) => !current)}
                  sx={{ whiteSpace: 'nowrap', borderRadius: 2, fontWeight: 900 }}
                >
                  {searchCollapsed ? 'Edit search' : 'Collapse'}
                </Button>
              )}
            </Stack>
          </Stack>

          <AnimatePresence initial={false}>
            {searchCollapsed && (
              <motion.div
                key="search-summary"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: .24 }}
              >
                <Stack
                  direction={{ xs: 'column', sm: 'row' }}
                  alignItems={{ sm: 'center' }}
                  justifyContent="space-between"
                  spacing={1}
                  sx={{ px: 1.5, py: 1.15, borderRadius: 2, border: 1, borderColor: alpha(theme.palette.primary.main, .2), bgcolor: alpha(theme.palette.primary.main, .045) }}
                >
                  <Stack direction="row" alignItems="center" spacing={1}>
                    <CheckCircleRoundedIcon color="success" />
                    <Box>
                      <Typography variant="body2" fontWeight={950}>Search criteria applied</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {appliedSearch.type === 'manual'
                          ? `${appliedSearch.skus.length} manually entered SKU${appliedSearch.skus.length === 1 ? '' : 's'}`
                          : `Launch date: ${formatDate(appliedSearch.date)}`}
                      </Typography>
                    </Box>
                  </Stack>
                  <Chip size="small" label={`${filteredRows.length} results`} color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
                </Stack>
              </motion.div>
            )}
          </AnimatePresence>

          <Collapse in={!searchCollapsed} timeout={300} unmountOnExit>
          <Box sx={{ pt: searchCollapsed ? 0 : .2 }}>
          <Stack direction={{ xs: 'column', lg: 'row' }} spacing={1.4} alignItems={{ lg: 'flex-start' }}>
            <Box sx={{ flex: '0 1 330px', width: { xs: '100%', lg: 330 }, p: 1.35, borderRadius: 2.25, border: 1.5, borderColor: dateMode ? 'primary.main' : 'divider', bgcolor: dateMode ? alpha(theme.palette.primary.main, .035) : alpha(theme.palette.background.paper, .78), boxShadow: dateMode ? `0 10px 28px ${alpha(theme.palette.primary.main, .14)}` : `0 8px 24px ${alpha('#18202b', .055)}`, transition: 'transform .2s ease, box-shadow .2s ease, border-color .2s ease', '&:hover': { transform: 'translateY(-2px)', boxShadow: `0 13px 30px ${alpha('#18202b', .09)}` } }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: .8 }}>
                <Stack direction="row" alignItems="center" spacing={1}>
                  <CalendarMonthRoundedIcon color="primary" />
                  <Stack direction="row" spacing={.75} alignItems="center">
                    <Typography variant="caption" sx={{ width: 20, height: 20, display: 'grid', placeItems: 'center', borderRadius: '50%', color: '#fff', bgcolor: 'primary.main', fontWeight: 950 }}>1</Typography>
                    <Typography fontWeight={900}>Launch calendar</Typography>
                  </Stack>
                </Stack>
                <Chip size="small" label={dateMode ? 'Selected' : 'Single date'} color={dateMode ? 'primary' : 'default'} icon={dateMode ? <CheckCircleRoundedIcon /> : undefined} sx={{ fontWeight: 850 }} />
              </Stack>
              <LaunchCalendar
                value={launchDate}
                onChange={(value) => {
                  setLaunchDate(value);
                  setSkuText('');
                }}
              />
            </Box>

            <Box sx={{ display: { xs: 'none', lg: 'grid' }, placeItems: 'center', width: 34, pt: 9 }}>
              <Avatar sx={{ width: 32, height: 32, fontSize: 10, fontWeight: 950, color: 'text.secondary', bgcolor: 'background.paper', border: 1, borderColor: 'divider' }}>OR</Avatar>
            </Box>

            <Box sx={{ flex: 1, p: 1.5, borderRadius: 2.25, border: manualMode ? '1.5px solid' : '1px dashed', borderColor: overLimit ? 'error.main' : manualMode ? 'primary.main' : alpha(theme.palette.primary.main, .34), bgcolor: manualMode ? alpha(theme.palette.primary.main, .035) : alpha(theme.palette.background.paper, .82), boxShadow: manualMode ? `0 10px 28px ${alpha(theme.palette.primary.main, .14)}` : `0 8px 24px ${alpha('#18202b', .055)}, inset 0 1px 0 ${alpha('#fff', .45)}`, transition: 'transform .2s ease, box-shadow .2s ease, border-color .2s ease', '&:hover': { transform: 'translateY(-2px)', borderColor: overLimit ? 'error.main' : 'primary.main', boxShadow: `0 13px 30px ${alpha('#18202b', .09)}` } }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: .9 }}>
                <Stack direction="row" alignItems="center" spacing={1}>
                  <Inventory2OutlinedIcon color="primary" />
                  <Stack direction="row" spacing={.75} alignItems="center">
                    <Typography variant="caption" sx={{ width: 20, height: 20, display: 'grid', placeItems: 'center', borderRadius: '50%', color: '#fff', bgcolor: 'primary.main', fontWeight: 950 }}>2</Typography>
                    <Typography fontWeight={900}>Enter SKUs manually</Typography>
                  </Stack>
                </Stack>
                <Chip size="small" label={`${enteredSkus.length} / 50`} color={overLimit ? 'error' : enteredSkus.length ? 'primary' : 'default'} sx={{ fontWeight: 900 }} />
              </Stack>
              <TextField
                fullWidth multiline minRows={3} maxRows={4} value={skuText}
                onChange={(event) => {
                  const nextValue = event.target.value;
                  setSkuText(nextValue);
                  if (nextValue.split(/[\s,;]+/).some((value) => value.trim())) setLaunchDate('');
                }}
                placeholder="Enter SKUs separated by commas, spaces, or new lines"
                error={overLimit}
                helperText={overLimit ? `Remove ${enteredSkus.length - 50} SKU${enteredSkus.length - 50 === 1 ? '' : 's'} to continue. Maximum 50 SKUs allowed.` : 'Maximum 50 SKUs allowed.'}
                sx={{ '& .MuiOutlinedInput-root': { bgcolor: 'background.paper', borderRadius: 2 } }}
              />
            </Box>
          </Stack>

          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="flex-end" spacing={1} sx={{ mt: 1.35 }}>
            <Button startIcon={<RestartAltRoundedIcon />} color="inherit" onClick={() => { setLaunchDate(''); setSkuText(''); }}>Clear</Button>
            <Button
              variant="contained" size="large" startIcon={<SearchRoundedIcon />} disabled={searching || overLimit || (!launchDate && !enteredSkus.length)} onClick={() => void handleSearch()}
              sx={{ minWidth: 178, borderRadius: 2, fontWeight: 950, boxShadow: `0 10px 22px ${alpha(theme.palette.primary.main, .3)}`, transition: 'transform .18s ease, box-shadow .18s ease', '&:hover': { transform: 'translateY(-2px)', boxShadow: `0 14px 28px ${alpha(theme.palette.primary.main, .38)}` }, '&:active': { transform: 'translateY(0)' } }}
            >{searching ? 'Searching…' : 'Search SKUs'}</Button>
          </Stack>
          </Box>
          </Collapse>
          </Box>
        </Paper>
      </motion.div>

      {searching && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <Paper elevation={0} sx={{ mb: 2, overflow: 'hidden', borderRadius: 3, border: 1, borderColor: 'divider' }}>
            <Box sx={{ px: 2.25, py: 1.75 }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1.25} sx={{ mb: 1.1 }}>
                <Stack direction="row" alignItems="center" spacing={1.25}>
                  <SearchRoundedIcon color="primary" />
                  <Box>
                    <Typography fontWeight={950}>Searching SKU trace data</Typography>
                    <Typography variant="body2" color="text.secondary">POST /skus/trace/search · Previous results were cleared. Loading the new result set…</Typography>
                  </Box>
                </Stack>
                <Typography variant="body2" color="primary.main" fontWeight={950}>{searchProgress}%</Typography>
              </Stack>
              <LinearProgress variant="determinate" value={searchProgress} sx={{ height: 7, borderRadius: 99 }} />
            </Box>
          </Paper>
        </motion.div>
      )}

      {searchError && <Alert severity="error" sx={{ mb: 2 }}>{searchError}</Alert>}

      {searched && (
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .4, delay: .08, ease: 'easeOut' }}>
        <Paper elevation={0} sx={{ borderRadius: 3, overflow: 'hidden', border: 1, borderColor: 'divider', boxShadow: `0 14px 38px ${alpha('#18202b', .1)}` }}>
          <Box sx={{ p: { xs: 1.75, md: 2.1 }, borderBottom: 1, borderColor: 'divider', background: theme.palette.mode === 'light' ? 'linear-gradient(110deg, #fff, #f7f9fb 72%, #fff4f4)' : 'linear-gradient(110deg, #222833, #171c24)' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ md: 'center' }} spacing={1.5}>
              <Box>
                <Stack direction="row" alignItems="center" spacing={1}>
                  <Typography variant="h6" fontWeight={950}>Trace results</Typography>
                  <Chip size="small" label={`${filteredRows.length} SKUs`} color="primary" sx={{ fontWeight: 900 }} />
                </Stack>
                <Typography variant="body2" color="text.secondary">Configuration status from product setup to site readiness</Typography>
                {resultView === 'all' && (
                  <Stack direction={{ xs: 'column', sm: 'row' }} alignItems={{ sm: 'center' }} spacing={.8} sx={{ mt: .55 }}>
                    <Typography variant="caption" color="primary.main" fontWeight={800}>Select a SKU row to preview its complete Launch, Product Attributes, and Inventory record.</Typography>
                    <Stack direction="row" spacing={.5}>
                      <Tooltip title="Expand all SKU records" arrow><IconButton size="small" color="primary" onClick={() => setExpandedSkus(new Set(filteredRows.map((row) => row.sku)))} aria-label="Expand all SKU records" sx={{ border: 1, borderColor: 'primary.light', borderRadius: 1.5 }}><ExpandMoreRoundedIcon /></IconButton></Tooltip>
                      <Tooltip title="Collapse all SKU records" arrow><IconButton size="small" onClick={() => setExpandedSkus(new Set())} aria-label="Collapse all SKU records" sx={{ border: 1, borderColor: 'divider', borderRadius: 1.5 }}><ExpandLessRoundedIcon /></IconButton></Tooltip>
                    </Stack>
                  </Stack>
                )}
                <Stack direction="row" spacing={.8} sx={{ mt: 1 }} flexWrap="wrap" useFlexGap>
                  <Chip
                    size="small"
                    icon={appliedSearch.type === 'manual' ? <Inventory2OutlinedIcon /> : <CalendarMonthRoundedIcon />}
                    label={appliedSearch.type === 'manual' ? 'Manual SKU selection' : formatDate(appliedSearch.date)}
                    color="primary"
                    sx={{ height: 25, fontWeight: 900 }}
                  />
                  <SummaryChip label="Ready" value={readyCount} color="success" />
                  <SummaryChip label="Needs attention" value={attentionCount} color="warning" />
                  <SummaryChip label="Active" value={filteredRows.filter((row) => row.skuStatus === 'A').length} color="info" />
                </Stack>
              </Box>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ width: { xs: '100%', md: 'auto' } }}>
                <FormControl size="small" sx={{ minWidth: { xs: '100%', sm: 180 } }}>
                  <Select
                    value={resultView}
                    onChange={(event) => { setResultView(event.target.value as ResultView); setColumnFilters({}); setPage(1); }}
                    inputProps={{ 'aria-label': 'Result column view' }}
                    startAdornment={<InputAdornment position="start"><ViewColumnRoundedIcon fontSize="small" /></InputAdornment>}
                    sx={{ borderRadius: 2, bgcolor: alpha(theme.palette.background.default, .65), fontWeight: 850 }}
                  >
                    <MenuItem value="all">All</MenuItem>
                    <MenuItem value="launch">Launch</MenuItem>
                    <MenuItem value="productAttributes">Product Attributes</MenuItem>
                    <MenuItem value="inventory">Inventory</MenuItem>
                  </Select>
                </FormControl>
                <TextField
                  value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} placeholder="Search all columns…" size="small"
                  InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }}
                  sx={{ width: { xs: '100%', md: 320 }, '& .MuiOutlinedInput-root': { borderRadius: 2, bgcolor: alpha(theme.palette.background.default, .65) } }}
                />
                <Button
                  variant="outlined"
                  startIcon={<FileDownloadRoundedIcon />}
                  disabled={!filteredRows.length}
                  onClick={() => void downloadSkuTraceResultsExcel('sku-trace-results.xlsx', filteredRows)}
                  sx={{ whiteSpace: 'nowrap', fontWeight: 900, borderRadius: 2 }}
                >
                  Export results
                </Button>
              </Stack>
            </Stack>
          </Box>
          <LinearProgress variant="determinate" value={100} sx={{ height: 2 }} />
          <TableContainer sx={{ maxHeight: 590, overflowX: 'hidden' }}>
            <Table stickyHeader size="small" aria-label="SKU trace results" sx={(currentTheme) => ({ ...polishedTableSx(currentTheme), width: '100%', tableLayout: 'fixed' })}>
              <TableHead>
                <TableRow>
                  {activeColumns.map((column) => (
                    <TableCell key={column.key} sx={{ width: `${100 / activeColumns.length}%`, color: '#fff', borderBottom: 0, p: 0, overflow: 'hidden' }}>
                      <Button
                        color="inherit" onClick={() => setSortKey(column.key)}
                        endIcon={sort.key === column.key ? (sort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                        sx={{
                          width: '100%',
                          minHeight: 46,
                          px: 1.25,
                          borderRadius: 0,
                          justifyContent: 'flex-start',
                          color: '#fff !important',
                          background: '#2f668f',
                          fontSize: 12,
                          fontWeight: 950,
                          letterSpacing: .35,
                          whiteSpace: 'normal',
                          lineHeight: 1.05,
                          '&:hover': { background: '#255273' }
                        }}
                      >{column.label}</Button>
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  {activeColumns.map((column) => (
                    <TableCell key={column.key} sx={{ bgcolor: theme.palette.mode === 'light' ? '#e8edf3' : '#243446', py: .75, overflow: 'hidden' }}>
                      <TextField
                        size="small" value={columnFilters[column.key] ?? ''} onChange={(event) => { setColumnFilters((current) => ({ ...current, [column.key]: event.target.value })); setPage(1); }}
                        placeholder="Filter…" inputProps={{ 'aria-label': `Filter ${column.label}` }}
                        sx={{ width: '100%', '& .MuiInputBase-root': { height: 32, fontSize: 12, bgcolor: 'background.paper' } }}
                      />
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {visibleRows.map((row) => (
                  <Fragment key={row.sku}>
                    <TableRow
                      hover
                      onClick={resultView === 'all' ? () => setExpandedSkus((current) => {
                        const next = new Set(current);
                        if (next.has(row.sku)) next.delete(row.sku); else next.add(row.sku);
                        return next;
                      }) : undefined}
                      sx={{ cursor: resultView === 'all' ? 'pointer' : 'default', transition: 'background-color .16s ease, box-shadow .16s ease', '&:nth-of-type(even)': { bgcolor: alpha(theme.palette.primary.main, .018) }, '&:hover': { bgcolor: `${alpha(theme.palette.primary.main, .055)} !important`, boxShadow: `inset 3px 0 0 ${theme.palette.primary.main}` } }}
                    >
                      {activeColumns.map((column) => (
                        <TableCell key={column.key} sx={{ overflow: 'hidden' }}>
                          <SkuResultCell
                            row={row}
                            column={column.key}
                            onSkuClick={() => { setSelectedSku(row); setTab(0); }}
                            onlineStatuses={onlineStatuses}
                            checkingOnline={checkingOnline}
                          />
                        </TableCell>
                      ))}
                    </TableRow>
                    {resultView === 'all' && expandedSkus.has(row.sku) && (
                      <TableRow>
                        <TableCell colSpan={activeColumns.length} sx={{ p: { xs: 1, md: 1.25 }, bgcolor: `${alpha(theme.palette.primary.main, .025)} !important` }}>
                          <AllSkuValues row={row} onlineStatuses={onlineStatuses} checkingOnline={checkingOnline} />
                        </TableCell>
                      </TableRow>
                    )}
                  </Fragment>
                ))}
                {!filteredRows.length && (
                  <TableRow><TableCell colSpan={activeColumns.length} align="center" sx={{ py: 7 }}>
                    <SearchRoundedIcon color="disabled" sx={{ fontSize: 42 }} />
                    <Typography fontWeight={900} sx={{ mt: 1 }}>No matching SKUs</Typography>
                    <Typography variant="body2" color="text.secondary">Try clearing one or more filters.</Typography>
                  </TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <Stack direction={{ xs: 'column', md: 'row' }} alignItems={{ md: 'center' }} justifyContent="space-between" spacing={1.5} sx={{ px: 2.25, py: 1.4, borderTop: 1, borderColor: 'divider', bgcolor: alpha(theme.palette.background.default, .5) }}>
            <Typography variant="caption" color="text.secondary">
              Showing {filteredRows.length ? (page - 1) * 5 + 1 : 0}–{Math.min(page * 5, filteredRows.length)} of {filteredRows.length} results · 5 per page
            </Typography>
            <Pagination count={pageCount} page={Math.min(page, pageCount)} onChange={(_, value) => setPage(value)} color="primary" shape="rounded" showFirstButton showLastButton size="small" />
            <Typography variant="caption" color="text.secondary">Tip: select any column heading to sort</Typography>
          </Stack>
        </Paper>
        </motion.div>
      )}

      <SkuDetailDialog row={selectedSku} tab={tab} onTabChange={setTab} onClose={() => setSelectedSku(null)} />
    </Box>
  );
}

function ReadinessBadge({ value }: { value: YesNo | FrenchValue }) {
  if (!value) {
    return <Box component="span" aria-label="Not provided" sx={{ width: 30, height: 30, display: 'inline-block', verticalAlign: 'middle' }} />;
  }
  if (value === 'N/A') {
    return <Tooltip title="Not applicable" arrow><Chip size="small" label="N/A" variant="outlined" sx={{ fontWeight: 900, color: 'text.secondary', borderColor: 'divider', bgcolor: 'action.hover' }} /></Tooltip>;
  }
  const yes = value === 'Yes';
  return (
    <Tooltip title={yes ? 'Yes · Complete' : 'No · Action required'} arrow>
      <Box
        component="span"
        role="img"
        aria-label={yes ? 'Yes' : 'No'}
        sx={{
          width: 30, height: 30, display: 'inline-grid', placeItems: 'center', borderRadius: '50%',
          color: yes ? 'success.main' : 'error.main',
          bgcolor: (theme) => alpha(theme.palette[yes ? 'success' : 'error'].main, .1),
          border: '1px solid', borderColor: yes ? 'success.light' : 'error.light'
        }}
      >
        {yes ? <CheckCircleRoundedIcon sx={{ fontSize: 19 }} /> : <CancelRoundedIcon sx={{ fontSize: 19 }} />}
      </Box>
    </Tooltip>
  );
}

function SummaryChip({ label, value, color }: { label: string; value: number; color: 'success' | 'warning' | 'info' }) {
  return (
    <Chip
      size="small"
      label={`${value} ${label}`}
      color={color}
      variant="outlined"
      sx={{
        height: 25,
        fontWeight: 900,
        bgcolor: (theme) => alpha(theme.palette[color].main, .055),
        '& .MuiChip-label': { px: 1 }
      }}
    />
  );
}

function ApiProgressBar({ value, label, endpoint }: { value: number; label: string; endpoint: string }) {
  return (
    <Paper
      variant="outlined"
      sx={{
        p: 1.4,
        mb: 2,
        borderRadius: 2,
        borderColor: (theme) => alpha(theme.palette.primary.main, .22),
        bgcolor: (theme) => alpha(theme.palette.primary.main, .035)
      }}
    >
      <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1} sx={{ mb: .8 }}>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="body2" fontWeight={950}>{label}</Typography>
          <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>
            {endpoint}
          </Typography>
        </Box>
        <Chip size="small" label={`${value}%`} color="primary" sx={{ fontWeight: 950, minWidth: 52 }} />
      </Stack>
      <LinearProgress
        variant="determinate"
        value={value}
        aria-label={label}
        sx={{
          height: 7,
          borderRadius: 99,
          '& .MuiLinearProgress-bar': {
            borderRadius: 99,
            background: 'linear-gradient(90deg, #b9141a 0%, #ef4b51 65%, #ff7b80 100%)',
            transition: 'transform .18s ease'
          }
        }}
      />
    </Paper>
  );
}

function useApiProgress(active: boolean) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!active) {
      setProgress(0);
      return;
    }
    setProgress(7);
    const interval = window.setInterval(() => {
      setProgress((current) => {
        if (current >= 94) return 94;
        return Math.min(94, current + Math.max(2, Math.round((96 - current) * .17)));
      });
    }, 110);
    return () => window.clearInterval(interval);
  }, [active]);

  return progress;
}

function SkuStatusBadge({ status }: { status: SkuStatus }) {
  if (!status) return <Box component="span" aria-label="Not provided" sx={{ width: 32, height: 30, display: 'inline-block', verticalAlign: 'middle' }} />;
  const config = status === 'A' ? { title: 'Active', color: 'success' as const } : status === 'D' ? { title: 'Deleted', color: 'error' as const } : { title: 'Inactive', color: 'warning' as const };
  return <Tooltip title={config.title} arrow><Chip size="small" label={status} color={config.color} sx={{ width: 32, minWidth: 32, fontWeight: 950, '& .MuiChip-label': { px: .7 } }} /></Tooltip>;
}

function LaunchTypeBadge({ type }: { type: LaunchType }) {
  const config = type === 'Atomic'
    ? { color: 'error' as const, variant: 'filled' as const }
    : type === 'Hot'
      ? { color: 'warning' as const, variant: 'filled' as const }
      : { color: 'info' as const, variant: 'outlined' as const };
  return <Chip size="small" label={type} color={config.color} variant={config.variant} sx={{ minWidth: 68, fontWeight: 950 }} />;
}

function getBannerProductUrl(banner: string, sku: string) {
  const baseUrl: Record<string, string> = {
    CS: 'https://www.champssports.com',
    CHP: 'https://www.champssports.com',
    FL: 'https://www.footlocker.com',
    KFL: 'https://www.kidsfootlocker.com',
    KIDS: 'https://www.kidsfootlocker.com',
    FLCA: 'https://www.footlocker.ca',
    CSCA: 'https://www.champssports.ca'
  };
  const site = baseUrl[banner.trim().toUpperCase()];
  return site ? `${site}/product/~/${encodeURIComponent(sku)}.html` : undefined;
}

function OnlineStatusIcon({ online, checking }: { online: boolean | undefined; checking: boolean }) {
  const isChecking = checking && online === undefined;
  const config = isChecking
    ? { title: 'Checking online availability', color: '#1976d2', background: '#1976d2', icon: <RefreshRoundedIcon sx={{ fontSize: 17, animation: 'sku-trace-spin .8s linear infinite' }} /> }
    : online === true
      ? { title: 'SKU is online', color: '#2e7d32', background: '#2e7d32', icon: <LanguageRoundedIcon sx={{ fontSize: 17 }} /> }
      : online === false
        ? { title: 'SKU is not online', color: '#c62828', background: '#c62828', icon: <CloudOffRoundedIcon sx={{ fontSize: 17 }} /> }
        : { title: 'Online status unavailable', color: '#64748b', background: '#64748b', icon: <CloudOffRoundedIcon sx={{ fontSize: 17 }} /> };
  return (
    <Tooltip title={config.title} arrow>
      <Box component="span" role="img" aria-label={config.title} sx={{ width: 25, height: 25, display: 'inline-grid', placeItems: 'center', flex: '0 0 auto', borderRadius: '50%', color: config.color, bgcolor: (theme) => alpha(theme.palette.mode === 'light' ? config.background : '#fff', theme.palette.mode === 'light' ? .12 : .16), border: '1px solid', borderColor: (theme) => alpha(theme.palette.mode === 'light' ? config.background : '#fff', .28) }}>
        {config.icon}
      </Box>
    </Tooltip>
  );
}

function BannerLinks({ value, sku, onlineStatuses, checkingOnline }: { value: string; sku: string; onlineStatuses: Record<string, boolean>; checkingOnline: boolean }) {
  return (
    <Stack direction="column" spacing={.45} alignItems="flex-start">
      {value.split(',').map((banner) => banner.trim()).filter(Boolean).map((banner) => {
        const online = onlineStatuses[`${sku}:${banner.toUpperCase()}`];
        return (
          <Stack key={banner} direction="row" alignItems="center" spacing={.35}>
            {getBannerProductUrl(banner, sku)
              ? <Box component="a" href={getBannerProductUrl(banner, sku)} target="_blank" rel="noopener noreferrer" onClick={(event) => event.stopPropagation()} sx={{ color: 'primary.main', fontSize: 12, fontWeight: 900, textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer', '&:hover': { color: 'primary.dark' } }}>{banner}</Box>
              : <Typography variant="caption" color="text.secondary" fontWeight={850}>{banner}</Typography>}
            <OnlineStatusIcon online={online} checking={checkingOnline} />
          </Stack>
        );
      })}
    </Stack>
  );
}

function AllValue({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Box sx={{ minWidth: 0 }}>
      <Typography variant="caption" color="text.secondary" fontWeight={850} sx={{ display: 'block', mb: .35, lineHeight: 1.05 }}>{label}</Typography>
      {children}
    </Box>
  );
}

function AllSkuValues({ row, onlineStatuses, checkingOnline }: { row: Row; onlineStatuses: Record<string, boolean>; checkingOnline: boolean }) {
  const panelSx = {
    p: 1.15,
    borderRadius: 1.8,
    border: 1,
    borderColor: 'divider',
    bgcolor: 'background.paper',
    boxShadow: 'inset 0 1px 0 rgba(255,255,255,.45)'
  };
  return (
    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 1.55fr 1fr' }, gap: 1 }}>
      <Box sx={panelSx}>
        <Typography variant="caption" fontWeight={950} color="primary.main" sx={{ display: 'block', mb: .8 }}>LAUNCH</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: .9 }}>
          <AllValue label="Launch date"><Typography variant="body2" fontWeight={700}>{formatDate(row.launchDate)}</Typography></AllValue>
          <AllValue label="Launch res. date"><Typography variant="body2" fontWeight={700}>{formatDate(row.launchReservationDate)}</Typography></AllValue>
          <AllValue label="Launch type"><LaunchTypeBadge type={row.launchType} /></AllValue>
          <Box sx={{ gridColumn: '1 / -1', pt: .75, borderTop: 1, borderColor: 'divider' }}><AllValue label="Launched banners"><BannerLinks value={row.launchedBanners} sku={row.sku} onlineStatuses={onlineStatuses} checkingOnline={checkingOnline} /></AllValue></Box>
        </Box>
      </Box>
      <Box sx={panelSx}>
        <Typography variant="caption" fontWeight={950} color="primary.main" sx={{ display: 'block', mb: .8 }}>PRODUCT ATTRIBUTES</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', sm: 'repeat(4, minmax(0, 1fr))' }, gap: .9 }}>
          <Box sx={{ gridRow: { xs: 'auto', sm: 'span 2' } }}><AllValue label="Banners"><BannerLinks value={row.banners} sku={row.sku} onlineStatuses={onlineStatuses} checkingOnline={checkingOnline} /></AllValue></Box>
          <AllValue label="Image"><ReadinessBadge value={row.image} /></AllValue>
          <AllValue label="Copy"><ReadinessBadge value={row.copy} /></AllValue>
          <AllValue label="Product type"><ReadinessBadge value={row.productType} /></AllValue>
          <AllValue label="Sports attribute"><ReadinessBadge value={row.sportsAttribute} /></AllValue>
          <AllValue label="French name"><ReadinessBadge value={row.frenchName} /></AllValue>
          <AllValue label="French copy"><ReadinessBadge value={row.frenchCopy} /></AllValue>
        </Box>
      </Box>
      <Box sx={panelSx}>
        <Typography variant="caption" fontWeight={950} color="primary.main" sx={{ display: 'block', mb: .8 }}>INVENTORY</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: .9 }}>
          <AllValue label="IEX"><ReadinessBadge value={row.availableInIex} /></AllValue>
          <AllValue label="IEX Store"><ReadinessBadge value={row.avavailableInIexStore} /></AllValue>
          <AllValue label="IEX Warehouse"><ReadinessBadge value={row.avavailbleInIexWhse} /></AllValue>
          <AllValue label="IEX Dropship"><ReadinessBadge value={row.avavailableInIexDropship} /></AllValue>
        </Box>
      </Box>
    </Box>
  );
}

function SkuResultCell({ row, column, onSkuClick, onlineStatuses, checkingOnline }: { row: Row; column: SortKey; onSkuClick: () => void; onlineStatuses: Record<string, boolean>; checkingOnline: boolean }) {
  if (column === 'sku') {
    return (
      <Button endIcon={<OpenInNewRoundedIcon sx={{ fontSize: '14px !important' }} />} onClick={(event) => { event.stopPropagation(); onSkuClick(); }} sx={{ maxWidth: '100%', p: 0, fontWeight: 950, textDecoration: 'underline', textUnderlineOffset: 3, whiteSpace: 'nowrap' }}>
        {row.sku}
      </Button>
    );
  }
  if (column === 'skuStatus') return <SkuStatusBadge status={row.skuStatus} />;
  if (column === 'image' || column === 'copy' || column === 'productType' || column === 'sportsAttribute' || column === 'frenchCopy' || column === 'frenchName') {
    return <ReadinessBadge value={row[column]} />;
  }
  if (column === 'launchType') return <LaunchTypeBadge type={row.launchType} />;
  if (column === 'launchedBanners' || column === 'banners') return <BannerLinks value={row[column]} sku={row.sku} onlineStatuses={onlineStatuses} checkingOnline={checkingOnline} />;

  const value = column === 'launchDate' || column === 'launchReservationDate'
    ? formatDate(row[column])
    : row[column];
  return (
    <Tooltip title={value} arrow>
      <Typography variant="body2" fontWeight={column === 'description' ? 700 : 600} noWrap>
        {value}
      </Typography>
    </Tooltip>
  );
}

function SkuDetailDialog({ row, tab, onTabChange, onClose }: { row: Row | null; tab: number; onTabChange: (value: number) => void; onClose: () => void }) {
  const theme = useTheme();
  const [data, setData] = useState<SkuTraceTabResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [syncDialogOpen, setSyncDialogOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState('');
  const [syncError, setSyncError] = useState('');
  const [availabilityBanner, setAvailabilityBanner] = useState('Foot Locker');
  const tabProgress = useApiProgress(loading);
  const syncProgress = useApiProgress(syncing);
  const tabKey = skuTraceTabKeys[tab];

  const loadTab = useCallback(async (signal?: AbortSignal) => {
    if (!row) return;
    setLoading(true);
    setError('');
    try {
      const response = await skuTraceApi.getTab(
        row.sku,
        tabKey,
        signal,
        tabKey === 'sku-availability' ? availabilityBanner : undefined
      );
      setData(response);
    } catch (requestError) {
      if (requestError instanceof DOMException && requestError.name === 'AbortError') return;
      setError(requestError instanceof Error ? requestError.message : 'Unable to load this SKU trace section.');
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [row, tabKey, availabilityBanner]);

  useEffect(() => {
    if (!row) return;
    const controller = new AbortController();
    setData(null);
    void loadTab(controller.signal);
    return () => controller.abort();
  }, [loadTab, row]);

  useEffect(() => {
    setSyncDialogOpen(false);
    setSyncMessage('');
    setSyncError('');
  }, [row?.sku, tabKey]);

  useEffect(() => {
    setAvailabilityBanner('Foot Locker');
  }, [row?.sku]);

  const handleSyncTraceSection = async () => {
    if (!row) return;
    setSyncing(true);
    setSyncError('');
    try {
      const response = tabKey === 'exclusions'
        ? await skuTraceApi.syncExclusions(row.sku)
        : await skuTraceApi.syncSellingChannels(row.sku);
      setSyncDialogOpen(false);
      setSyncMessage(response.message);
      await loadTab();
    } catch (requestError) {
      setSyncError(requestError instanceof Error ? requestError.message : `Unable to synchronize ${tabKey === 'exclusions' ? 'exclusion mismatches' : 'selling channels'}.`);
    } finally {
      setSyncing(false);
    }
  };

  if (!row) return null;
  const exclusionMismatchCount = data?.exclusions?.filter((exclusion) => exclusion.status === 'active' && exclusion.maoStatus !== 'active').length ?? 0;
  return (
    <Dialog
      open
      fullWidth
      maxWidth={false}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: 'calc(100vw - 20px)', md: 'min(1500px, calc(100vw - 48px))' },
          height: { xs: 'calc(100vh - 20px)', md: 'calc(100vh - 48px)' },
          maxWidth: '1500px !important',
          maxHeight: { xs: 'calc(100vh - 20px) !important', md: 'calc(100vh - 48px) !important' },
          m: { xs: '10px', md: '24px' },
          borderRadius: { xs: 2, md: 3 },
          overflow: 'hidden'
        }
      }}
    >
      <Box sx={{ position: 'relative', p: { xs: 2, md: 2.5 }, color: '#fff', background: 'linear-gradient(115deg, #171b22 0%, #2d333c 55%, #a81218 100%)' }}>
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Avatar sx={{ width: 48, height: 48, bgcolor: '#fff', color: 'primary.main' }}><Inventory2OutlinedIcon /></Avatar>
            <Box>
              <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                <Typography variant="h5" fontWeight={950}>{row.sku}</Typography>
                <SkuStatusBadge status={row.skuStatus} />
              </Stack>
              <Typography sx={{ color: 'rgba(255,255,255,.72)', mt: .25 }}>{row.description}</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close SKU details" onClick={onClose} sx={{ color: '#fff', bgcolor: 'rgba(255,255,255,.1)' }}><CloseRoundedIcon /></IconButton>
        </Stack>
      </Box>
      <Box sx={{ px: 1.25, py: 1, borderBottom: 1, borderColor: 'divider', bgcolor: theme.palette.mode === 'light' ? '#eef1f5' : '#171c24' }}>
        <Tabs
          value={tab}
          onChange={(_, value) => onTabChange(value)}
          variant="scrollable"
          scrollButtons="auto"
          aria-label="SKU detail sections"
          TabIndicatorProps={{ sx: { display: 'none' } }}
          sx={{ minHeight: 42, '& .MuiTabs-flexContainer': { gap: .65 } }}
        >
          {detailTabs.map((label) => (
            <Tab
              key={label}
              label={label}
              sx={{
                minHeight: 42,
                minWidth: 'auto',
                px: 1.6,
                py: .75,
                borderRadius: 1.75,
                border: '1px solid',
                borderColor: 'divider',
                bgcolor: 'background.paper',
                color: 'text.secondary',
                fontWeight: 900,
                transition: 'all .18s ease',
                '&:hover': { color: 'primary.main', borderColor: 'primary.light', bgcolor: (currentTheme) => alpha(currentTheme.palette.primary.main, .05) },
                '&.Mui-selected': {
                  color: '#fff',
                  borderColor: 'primary.main',
                  background: 'linear-gradient(180deg, #e23b41 0%, #bd171e 100%)',
                  boxShadow: `0 7px 18px ${alpha(theme.palette.primary.main, .3)}`
                }
              }}
            />
          ))}
        </Tabs>
      </Box>
      <DialogContent sx={{ p: { xs: 2, md: 3 }, minHeight: 0, flex: 1, overflowY: 'auto' }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} spacing={1} sx={{ mb: 2 }}>
          <Box>
            <Typography variant="h6" fontWeight={950}>{data?.title ?? detailTabs[tab]}</Typography>
            <Typography variant="body2" color="text.secondary">{data?.subtitle ?? 'Loading the latest SKU trace data…'}</Typography>
          </Box>
          <Stack direction="row" alignItems="center" spacing={1}>
            {data?.refreshedAt && (
              <Typography variant="caption" color="text.secondary">
                Updated {new Date(data.refreshedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </Typography>
            )}
            {(tabKey === 'selling-channel' || tabKey === 'exclusions') && (
              <Button
                variant="contained"
                size="small"
                color="primary"
                startIcon={<SyncRoundedIcon />}
                disabled={loading || syncing || (tabKey === 'exclusions' && exclusionMismatchCount === 0)}
                onClick={() => setSyncDialogOpen(true)}
                sx={{ fontWeight: 950, borderRadius: 2, boxShadow: `0 7px 16px ${alpha(theme.palette.primary.main, .24)}` }}
              >
                {tabKey === 'exclusions' ? `Sync mismatches${exclusionMismatchCount ? ` (${exclusionMismatchCount})` : ''}` : 'Sync selling channels'}
              </Button>
            )}
            {tabKey !== 'sku-availability' && (
              <Button
                variant="outlined"
                size="small"
                startIcon={<FileDownloadRoundedIcon />}
                disabled={loading || !data}
                onClick={() => data && void downloadTabExport(row.sku, tabKey, data)}
                sx={{ fontWeight: 900, borderRadius: 2, whiteSpace: 'nowrap' }}
              >
                Export tab
              </Button>
            )}
            <Button
              variant="outlined"
              size="small"
              startIcon={
                <RefreshRoundedIcon
                  sx={{
                    animation: loading ? 'sku-trace-spin .8s linear infinite' : 'none',
                    '@keyframes sku-trace-spin': { to: { transform: 'rotate(360deg)' } }
                  }}
                />
              }
              disabled={loading}
              onClick={() => void loadTab()}
              sx={{ fontWeight: 900, borderRadius: 2 }}
            >
              Refresh {detailTabs[tab]}
            </Button>
          </Stack>
        </Stack>
        {syncMessage && <Alert severity="success" onClose={() => setSyncMessage('')} sx={{ mb: 2 }}>{syncMessage}</Alert>}
        {loading && (
          <ApiProgressBar
            value={tabProgress}
            label={`Loading ${detailTabs[tab]} API`}
            endpoint={`GET /skus/${row.sku}/trace/${tabKey}${tabKey === 'sku-availability' ? `?banner=${encodeURIComponent(availabilityBanner)}` : ''}`}
          />
        )}
        {error && <Alert severity="error" action={<Button color="inherit" size="small" onClick={() => void loadTab()}>Retry</Button>}>{error}</Alert>}
        <AnimatePresence mode="wait">
          {!error && data && (
            <motion.div
              key={`${data.sku}-${data.tab}-${data.refreshedAt}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: .22, ease: 'easeOut' }}
            >
              <DetailTabContent
                data={data}
                resultRow={row}
                availabilityBanner={availabilityBanner}
                onAvailabilityBannerChange={setAvailabilityBanner}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
      <Dialog
        open={syncDialogOpen}
        onClose={syncing ? undefined : () => setSyncDialogOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3, overflow: 'hidden' } }}
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <Box sx={{ width: 40, height: 40, display: 'grid', placeItems: 'center', borderRadius: 2, color: 'warning.dark', bgcolor: (currentTheme) => alpha(currentTheme.palette.warning.main, .14) }}>
              <WarningAmberRoundedIcon />
            </Box>
            <Box>
              <Typography variant="h6" fontWeight={950}>{tabKey === 'exclusions' ? 'Sync exclusion mismatches?' : 'Sync selling channels?'}</Typography>
              <Typography variant="body2" color="text.secondary">SKU {row.sku}</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Typography color="text.secondary">
            {tabKey === 'exclusions'
              ? `This will synchronize ${exclusionMismatchCount} active Foot Locker-side exclusion mismatch${exclusionMismatchCount === 1 ? '' : 'es'} to MAO, then reload the banner comparison.`
              : 'This will synchronize selling-channel banner assignments across MAO, SES, and Common Product, then reload the latest comparison.'}
          </Typography>
          <Alert severity="warning" sx={{ mt: 2 }}>
            Confirm only after reviewing the differences shown in the table.
          </Alert>
          {syncError && <Alert severity="error" sx={{ mt: 2 }}>{syncError}</Alert>}
          {syncing && (
            <Box sx={{ mt: 2 }}>
              <ApiProgressBar
                value={syncProgress}
                label={tabKey === 'exclusions' ? 'Synchronizing exclusion mismatches' : 'Synchronizing selling channels'}
                endpoint={`POST /skus/${row.sku}/trace/${tabKey === 'exclusions' ? 'exclusions' : 'selling-channel'}/sync`}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button color="inherit" disabled={syncing} onClick={() => setSyncDialogOpen(false)}>Cancel</Button>
          <Button
            variant="contained"
            disabled={syncing}
            startIcon={<SyncRoundedIcon sx={{ animation: syncing ? 'sku-trace-spin .8s linear infinite' : 'none' }} />}
            onClick={() => void handleSyncTraceSection()}
            sx={{ fontWeight: 950, borderRadius: 2 }}
          >
            {syncing ? 'Synchronizing…' : 'Confirm sync'}
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
}

function DetailTabContent({
  data,
  resultRow,
  availabilityBanner,
  onAvailabilityBannerChange
}: {
  data: SkuTraceTabResponse;
  resultRow: Row;
  availabilityBanner: string;
  onAvailabilityBannerChange: (banner: string) => void;
}) {
  if (data.tab === 'banners') return <BannerTables banners={data.banners ?? []} />;
  if (data.tab === 'selling-channel') return <SellingChannelTable channels={data.sellingChannels ?? []} />;
  if (data.tab === 'product-attributes') return <ProductAttributesTable rows={data.productAttributes ?? []} sku={resultRow.sku} banners={resultRow.banners} />;
  if (data.tab === 'xref') return <XrefTable rows={data.xrefs ?? []} />;
  if (data.tab === 'exclusions') return <SkuExclusionTable exclusions={data.exclusions ?? []} />;
  if (data.tab === 'sku-availability' && data.availability) {
    return (
      <SkuAvailabilityPanel
        sku={data.sku}
        refreshedAt={data.refreshedAt}
        availability={data.availability}
        selectedBanner={availabilityBanner}
        onBannerChange={onAvailabilityBannerChange}
      />
    );
  }
  return <DetailSection items={(data.items ?? []).map((item) => [item.label, item.value])} />;
}

const availabilityMetricColumns = [
  { key: 'mao', label: 'MAO' },
  { key: 'iexStaging', label: 'IEX staging' },
  { key: 'iex', label: 'IEX' },
  { key: 'iexGuidance', label: 'IEX Guidance' }
] as const;

const availabilityGroupColumns = [
  { key: 'dc', label: 'DC', accent: '#2f668f' },
  { key: 'dropship', label: 'Dropship', accent: '#6b4aa5' },
  { key: 'store', label: 'Store', accent: '#2e7d32' },
  { key: 'total', label: 'Total available', accent: '#9a5a10' }
] as const;

type AvailabilityMetricKey = (typeof availabilityMetricColumns)[number]['key'];
type AvailabilityDisplayMetricKey = AvailabilityMetricKey | 'inventoryProtection';
type AvailabilityGroupKey = (typeof availabilityGroupColumns)[number]['key'];
type SizeSortKey = 'size' | 'globalSizeId' | `${AvailabilityGroupKey}.${AvailabilityDisplayMetricKey}`;

const totalAvailabilityMetricColumns = [
  { key: 'inventoryProtection', label: 'Inventory protection' },
  ...availabilityMetricColumns
] as const;

function getAvailabilityMetricColumns(group: AvailabilityGroupKey) {
  return group === 'total' ? totalAvailabilityMetricColumns : availabilityMetricColumns;
}

function getSizeAvailabilityMetric(row: SkuSizeAvailability, group: AvailabilityGroupKey, metric: AvailabilityDisplayMetricKey) {
  if (metric === 'inventoryProtection') return row.inventoryProtection;
  if (group === 'total') {
    const values = [row.dc[metric], row.dropship[metric], row.store[metric]];
    return typeof values[0] === 'boolean'
      ? values.some((value) => value === true)
      : values.reduce<number>((total, value) => total + Number(value), 0);
  }
  return row[group][metric];
}

const fulfillmentInventoryMetricColumns = [
  { key: 'reserved', label: 'Reserved' },
  { key: 'available', label: 'Available' },
  { key: 'onHandAvailable', label: 'On Hand Available' },
  { key: 'ecomRingFence', label: 'Ecom Ring Fence' },
  { key: 'onHandUnavailable', label: 'On Hand Unavailable' },
  { key: 'onOrder', label: 'On Order' },
  { key: 'inTransit', label: 'In Transit' }
] as const;

const fulfillmentLocationColumns = [
  { key: 'warehouse1', label: 'Camphill', accent: '#2f668f' },
  { key: 'warehouse2', label: 'Reno', accent: '#4f6f3f' },
  { key: 'warehouse3', label: 'JC', accent: '#6b4aa5' },
  { key: 'warehouse4', label: 'Milton', accent: '#9a5a10' },
  { key: 'dropship', label: 'Dropship', accent: '#7b3fc6' },
  { key: 'store', label: 'Store', accent: '#2e7d32' }
] as const;

type FulfillmentInventoryMetricKey = (typeof fulfillmentInventoryMetricColumns)[number]['key'];
type FulfillmentLocationKey = (typeof fulfillmentLocationColumns)[number]['key'];
type WarehouseSortKey = 'size' | 'globalSizeId' | `${FulfillmentLocationKey}.${FulfillmentInventoryMetricKey}`;

function getFulfillmentInventoryValue(row: WarehouseSizeAvailability, location: FulfillmentLocationKey, metric: FulfillmentInventoryMetricKey) {
  return row[location][metric];
}

function SkuAvailabilityPanel({
  sku,
  refreshedAt,
  availability,
  selectedBanner,
  onBannerChange
}: {
  sku: string;
  refreshedAt: string;
  availability: SkuAvailabilityTrace;
  selectedBanner: string;
  onBannerChange: (banner: string) => void;
}) {
  const [availabilitySearch, setAvailabilitySearch] = useState('');
  const [sizeFilters, setSizeFilters] = useState<Record<string, string>>({});
  const [warehouseFilters, setWarehouseFilters] = useState<Record<string, string>>({});
  const [sizeSort, setSizeSort] = useState<{ key: SizeSortKey; direction: 'asc' | 'desc' }>({ key: 'size', direction: 'asc' });
  const [warehouseSort, setWarehouseSort] = useState<{ key: WarehouseSortKey; direction: 'asc' | 'desc' }>({ key: 'size', direction: 'asc' });
  const [sizePage, setSizePage] = useState(1);
  const [warehousePage, setWarehousePage] = useState(1);
  const totals = availability.sizeAvailability.reduce(
    (current, row) => ({ dc: current.dc + row.dc.mao, dropship: current.dropship + row.dropship.mao, store: current.store + row.store.mao }),
    { dc: 0, dropship: 0, store: 0 }
  );
  const globalQuery = availabilitySearch.toLowerCase().trim();
  const sizeValue = (row: SkuSizeAvailability, key: SizeSortKey): string | number => {
    if (key === 'size' || key === 'globalSizeId') return row[key];
    const [group, metric] = key.split('.') as [AvailabilityGroupKey, AvailabilityDisplayMetricKey];
    const value = getSizeAvailabilityMetric(row, group, metric);
    return typeof value === 'boolean' ? value ? 'Yes' : 'No' : value;
  };
  const sizeFilterColumns: Array<{ key: SizeSortKey; label: string }> = [
    { key: 'size', label: 'Size' },
    { key: 'globalSizeId', label: 'Global Size ID' },
    ...availabilityGroupColumns.flatMap((group) => getAvailabilityMetricColumns(group.key).map((metric) => ({ key: `${group.key}.${metric.key}` as SizeSortKey, label: `${group.label} ${metric.label}` })))
  ];
  const warehouseValue = (row: WarehouseSizeAvailability, key: WarehouseSortKey): string | number => {
    if (key === 'size' || key === 'globalSizeId') return row[key];
    const [location, metric] = key.split('.') as [FulfillmentLocationKey, FulfillmentInventoryMetricKey];
    return getFulfillmentInventoryValue(row, location, metric);
  };
  const warehouseFilterColumns: Array<{ key: WarehouseSortKey; label: string }> = [
    { key: 'size', label: 'Size' },
    { key: 'globalSizeId', label: 'Global Size ID' },
    ...fulfillmentLocationColumns.flatMap((location) => fulfillmentInventoryMetricColumns.map((metric) => ({ key: `${location.key}.${metric.key}` as WarehouseSortKey, label: `${location.label} ${metric.label}` })))
  ];
  const sizeRows = useMemo(() => availability.sizeAvailability
    .filter((row) => !globalQuery || sizeFilterColumns.some((column) => String(sizeValue(row, column.key)).toLowerCase().includes(globalQuery)))
    .filter((row) => sizeFilterColumns.every((column) => {
      const filter = sizeFilters[column.key]?.toLowerCase().trim();
      return !filter || String(sizeValue(row, column.key)).toLowerCase().includes(filter);
    }))
    .sort((left, right) => compareAvailabilityValues(sizeValue(left, sizeSort.key), sizeValue(right, sizeSort.key), sizeSort.direction)),
  [availability.sizeAvailability, globalQuery, sizeFilters, sizeSort]);
  const warehouseRows = useMemo(() => availability.warehouseAvailability
    .filter((row) => !globalQuery || warehouseFilterColumns.some((column) => String(warehouseValue(row, column.key)).toLowerCase().includes(globalQuery)))
    .filter((row) => warehouseFilterColumns.every((column) => {
      const filter = warehouseFilters[column.key]?.toLowerCase().trim();
      return !filter || String(warehouseValue(row, column.key)).toLowerCase().includes(filter);
    }))
    .sort((left, right) => compareAvailabilityValues(warehouseValue(left, warehouseSort.key), warehouseValue(right, warehouseSort.key), warehouseSort.direction)),
  [availability.warehouseAvailability, globalQuery, warehouseFilters, warehouseSort]);
  const sizePageCount = Math.max(1, Math.ceil(sizeRows.length / 5));
  const warehousePageCount = Math.max(1, Math.ceil(warehouseRows.length / 5));
  const visibleSizeRows = sizeRows.slice((sizePage - 1) * 5, sizePage * 5);
  const visibleWarehouseRows = warehouseRows.slice((warehousePage - 1) * 5, warehousePage * 5);
  const warehouseTotals = Object.fromEntries(fulfillmentLocationColumns.map((location) => [
    location.key,
    Object.fromEntries(fulfillmentInventoryMetricColumns.map((metric) => [metric.key, warehouseRows.reduce((total, row) => total + getFulfillmentInventoryValue(row, location.key, metric.key), 0)]))
  ])) as Record<FulfillmentLocationKey, Record<FulfillmentInventoryMetricKey, number>>;
  const toggleSizeSort = (key: SizeSortKey) => setSizeSort((current) => current.key === key
    ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
    : { key, direction: 'asc' });
  const toggleWarehouseSort = (key: WarehouseSortKey) => setWarehouseSort((current) => current.key === key
    ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
    : { key, direction: 'asc' });
  const resetAvailabilityFilters = () => {
    setAvailabilitySearch('');
    setSizeFilters({});
    setWarehouseFilters({});
    setSizePage(1);
    setWarehousePage(1);
  };
  const bannerFilename = availability.selectedBanner.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const exportSizeAvailability = () => downloadCsv(
    `${sku}-${bannerFilename}-sku-size-availability.csv`,
    buildSkuSizeAvailabilityExportRows(sizeRows, sku, availability, refreshedAt)
  );
  const exportFulfillmentLocations = () => downloadCsv(
    `${sku}-${bannerFilename}-fulfillment-locations.csv`,
    buildFulfillmentLocationExportRows(warehouseRows, sku, availability, refreshedAt)
  );

  useEffect(() => {
    setSizePage(1);
    setWarehousePage(1);
  }, [selectedBanner]);

  return (
    <Box>
      <Paper
        variant="outlined"
        sx={{
          p: { xs: 1.5, md: 2 },
          mb: 2,
          borderRadius: 2.5,
          background: (theme) => `linear-gradient(115deg, ${alpha(theme.palette.primary.main, .075)}, ${alpha(theme.palette.background.paper, .9)})`
        }}
      >
        <Stack direction={{ xs: 'column', lg: 'row' }} alignItems={{ lg: 'center' }} justifyContent="space-between" spacing={1.5}>
          <Box>
            <Typography fontWeight={950}>Availability controls</Typography>
            <Typography variant="body2" color="text.secondary">Select a banner, search all inventory, or refine individual columns.</Typography>
          </Box>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ width: { xs: '100%', lg: 'auto' } }}>
            <FormControl size="small" sx={{ minWidth: { xs: '100%', sm: 230 } }}>
              <InputLabel id="availability-banner-label">Banner</InputLabel>
              <Select
                labelId="availability-banner-label"
                value={selectedBanner}
                label="Banner"
                onChange={(event) => onBannerChange(String(event.target.value))}
                sx={{ bgcolor: 'background.paper', borderRadius: 2, fontWeight: 900 }}
              >
                {availability.banners.map((banner) => <MenuItem key={banner} value={banner}>{banner}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField
              size="small"
              value={availabilitySearch}
              onChange={(event) => {
                setAvailabilitySearch(event.target.value);
                setSizePage(1);
                setWarehousePage(1);
              }}
              placeholder="Search all availability…"
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }}
              sx={{ width: { xs: '100%', sm: 280 }, '& .MuiOutlinedInput-root': { bgcolor: 'background.paper', borderRadius: 2 } }}
            />
            <Tooltip title="Reset global and column filters">
              <Button variant="outlined" color="inherit" startIcon={<RestartAltRoundedIcon />} onClick={resetAvailabilityFilters} sx={{ borderRadius: 2, fontWeight: 900 }}>
                Reset
              </Button>
            </Tooltip>
          </Stack>
        </Stack>
      </Paper>

      <Box
        sx={{
          p: .85,
          mb: 2,
          borderRadius: 3,
          border: 1,
          borderColor: (theme) => alpha(theme.palette.info.main, .24),
          background: (theme) => theme.palette.mode === 'light'
            ? 'linear-gradient(120deg, #e8f2ff 0%, #f2edff 50%, #eaf8ef 100%)'
            : 'linear-gradient(120deg, #152a40 0%, #27203e 50%, #163326 100%)',
          boxShadow: (theme) => `inset 0 1px 0 ${alpha(theme.palette.common.white, .38)}, 0 8px 22px ${alpha(theme.palette.common.black, .06)}`
        }}
      >
        <Typography variant="overline" color="text.secondary" fontWeight={950} letterSpacing={.9} sx={{ display: 'block', px: .35, pb: .35, lineHeight: 1.2 }}>
          Availability summary
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <AvailabilitySummary label="DC · MAO inventory" value={totals.dc} tone="info" />
          <AvailabilitySummary label="Dropship · MAO inventory" value={totals.dropship} tone="secondary" />
          <AvailabilitySummary label="Store · MAO inventory" value={totals.store} tone="success" />
          <AvailabilityFlagSummary label="Ecom RF flag" value={availability.ecomRfEnabled} />
        </Box>
      </Box>

      <AvailabilitySectionHeader
        title="SKU and size availability"
        subtitle={`${availability.selectedBanner} availability across DC, Dropship, and Store fulfillment levels.`}
        exportLabel="Export size availability"
        onExport={exportSizeAvailability}
        exportDisabled={!sizeRows.length}
      />
      <Paper variant="outlined" sx={{ overflow: 'hidden', mb: 2.5, borderRadius: 2.5 }}>
        <TableContainer>
          <Table size="small" aria-label="SKU size availability by fulfillment level" sx={(currentTheme) => ({ minWidth: 2080, tableLayout: 'fixed', ...polishedTableSx(currentTheme) })}>
            <TableHead>
              <TableRow>
                {([{ key: 'size', label: 'Size', width: 76 }, { key: 'globalSizeId', label: 'Global Size ID', width: 155 }] as const).map((column) => (
                  <TableCell key={column.key} rowSpan={2} sx={{ ...availabilityHeaderSx, p: 0, width: column.width }}>
                    <Button
                      color="inherit"
                      onClick={() => toggleSizeSort(column.key)}
                      endIcon={sizeSort.key === column.key ? (sizeSort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                      sx={{
                        width: '100%',
                        minWidth: 0,
                        minHeight: 92,
                        px: 1.25,
                        borderRadius: 0,
                        justifyContent: 'flex-start',
                        whiteSpace: 'nowrap',
                        fontSize: 12,
                        fontWeight: 950,
                        color: '#fff !important',
                        background: '#2f668f',
                        '&:hover': { background: '#255273' }
                      }}
                    >
                      {column.label}
                    </Button>
                  </TableCell>
                ))}
                {availabilityGroupColumns.map((group) => (
                  <TableCell key={group.key} colSpan={getAvailabilityMetricColumns(group.key).length} align="center" sx={{ px: 1, py: .9, color: '#fff !important', background: `${group.accent} !important`, borderLeft: `3px solid ${alpha('#ffffff', .42)}`, fontSize: 12.5, fontWeight: 950, letterSpacing: .45 }}>
                    {group.label}
                  </TableCell>
                ))}
                <TableCell rowSpan={2} align="center" sx={{ ...availabilityHeaderSx, p: 0, width: 118 }}>
                  <Box sx={{ minHeight: 92, px: 1.25, display: 'grid', placeItems: 'center', color: '#fff', background: '#2f668f', fontSize: 12, fontWeight: 950 }}>Status</Box>
                </TableCell>
              </TableRow>
              <TableRow>
                {availabilityGroupColumns.flatMap((group) => getAvailabilityMetricColumns(group.key).map((metric) => {
                  const sortKey = `${group.key}.${metric.key}` as SizeSortKey;
                  return (
                    <TableCell key={sortKey} align="center" sx={{ p: 0, width: metric.key === 'inventoryProtection' ? 145 : 102, color: `${group.accent} !important`, background: `${alpha(group.accent, metric.key === 'inventoryProtection' ? .22 : .14)} !important`, borderLeft: metric.key === 'mao' || metric.key === 'inventoryProtection' ? `3px solid ${alpha(group.accent, .44)}` : undefined }}>
                      <Button
                        color="inherit"
                        onClick={() => toggleSizeSort(sortKey)}
                        endIcon={sizeSort.key === sortKey ? (sizeSort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                        sx={{ width: '100%', minWidth: 0, minHeight: 46, px: .7, borderRadius: 0, color: `${group.accent} !important`, justifyContent: 'center', whiteSpace: 'normal', lineHeight: 1.1, fontSize: 11, fontWeight: 950, '& .MuiButton-endIcon': { ml: .25 }, '& svg': { fontSize: 15 } }}
                      >
                        {metric.label}
                      </Button>
                    </TableCell>
                  );
                }))}
              </TableRow>
              <TableRow>
                {sizeFilterColumns.map((column) => (
                  <TableCell key={column.key} sx={{ py: .65, px: .45, ...(column.key === 'size' ? { width: 76 } : column.key === 'globalSizeId' ? { width: 155 } : {}) }}>
                    <TextField
                      size="small"
                      value={sizeFilters[column.key] ?? ''}
                      onChange={(event) => {
                        setSizeFilters((current) => ({ ...current, [column.key]: event.target.value }));
                        setSizePage(1);
                      }}
                      placeholder="Filter…"
                      inputProps={{ 'aria-label': `Filter ${column.label}` }}
                      sx={{ width: '100%', minWidth: column.key === 'size' ? 48 : column.key === 'globalSizeId' ? 125 : 76, '& .MuiInputBase-root': { height: 31, fontSize: 11.5 } }}
                    />
                  </TableCell>
                ))}
                <TableCell align="center" sx={{ py: .65 }}>
                  <Chip size="small" label={`${sizeRows.length} rows`} variant="outlined" sx={{ fontWeight: 850 }} />
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {visibleSizeRows.map((row) => {
                const total = getSizeAvailabilityMetric(row, 'total', 'mao') as number;
                return (
                  <TableRow key={row.globalSizeId} hover sx={{ '&:nth-of-type(even)': { bgcolor: 'action.hover' } }}>
                    <TableCell sx={{ width: 72, maxWidth: 72 }}><Chip size="small" label={row.size} variant="outlined" sx={{ minWidth: 42, fontWeight: 950 }} /></TableCell>
                    <TableCell><Typography variant="body2" fontWeight={900}>{row.globalSizeId}</Typography></TableCell>
                    {availabilityGroupColumns.flatMap((group) => getAvailabilityMetricColumns(group.key).map((metric) => (
                      <TableCell key={`${group.key}.${metric.key}`} align={typeof getSizeAvailabilityMetric(row, group.key, metric.key) === 'boolean' ? 'center' : 'right'} sx={{ borderLeft: metric.key === 'mao' || metric.key === 'inventoryProtection' ? `2px solid ${alpha(group.accent, .22)}` : undefined, bgcolor: group.key === 'total' ? alpha(group.accent, metric.key === 'inventoryProtection' ? .085 : .045) : undefined }}>
                        <AvailabilityMetricValue value={getSizeAvailabilityMetric(row, group.key, metric.key)} emphasize={group.key === 'total'} />
                      </TableCell>
                    )))}
                    <TableCell align="center">
                      <Chip size="small" label={total === 0 ? 'Unavailable' : total < 25 ? 'Low stock' : 'Available'} color={total === 0 ? 'error' : total < 25 ? 'warning' : 'success'} sx={{ fontWeight: 900 }} />
                    </TableCell>
                  </TableRow>
                );
              })}
              {!sizeRows.length && (
                <TableRow><TableCell colSpan={20} align="center" sx={{ py: 5 }}>
                  <SearchRoundedIcon color="disabled" />
                  <Typography fontWeight={900} sx={{ mt: .5 }}>No size availability matches these filters</Typography>
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <AvailabilityPagination
          page={sizePage}
          pageCount={sizePageCount}
          total={sizeRows.length}
          onChange={setSizePage}
        />
      </Paper>

      <AvailabilitySectionHeader
        title="Size inventory by Fulfillment locations"
        subtitle="Detailed SKU-size inventory across fulfillment locations, Dropship, and Store."
        exportLabel="Export fulfillment locations"
        onExport={exportFulfillmentLocations}
        exportDisabled={!warehouseRows.length}
      />
      <Paper variant="outlined" sx={{ overflow: 'hidden', borderRadius: 2.5 }}>
        <TableContainer>
          <Table size="small" aria-label="Size availability across fulfillment locations, dropship, and store" sx={(currentTheme) => ({ minWidth: 4720, tableLayout: 'fixed', ...polishedTableSx(currentTheme) })}>
            <TableHead>
              <TableRow>
                {([{ key: 'size', label: 'Size', width: 76 }, { key: 'globalSizeId', label: 'Global Size ID', width: 155 }] as const).map((column) => (
                  <TableCell key={column.key} rowSpan={2} sx={{ ...availabilityHeaderSx, p: 0, width: column.width }}>
                    <Button
                      color="inherit"
                      onClick={() => toggleWarehouseSort(column.key)}
                      endIcon={warehouseSort.key === column.key ? (warehouseSort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                      sx={{
                        width: '100%',
                        minWidth: 0,
                        minHeight: 92,
                        px: 1.25,
                        borderRadius: 0,
                        justifyContent: 'flex-start',
                        whiteSpace: 'nowrap',
                        fontSize: 12,
                        fontWeight: 950,
                        color: '#fff !important',
                        background: '#2f668f',
                        '&:hover': { background: '#255273' }
                      }}
                    >
                      {column.label}
                    </Button>
                  </TableCell>
                ))}
                {fulfillmentLocationColumns.map((location) => (
                  <TableCell key={location.key} colSpan={fulfillmentInventoryMetricColumns.length} align="center" sx={{ px: 1, py: .9, color: '#fff !important', background: `${location.accent} !important`, borderLeft: `3px solid ${alpha('#ffffff', .42)}`, fontSize: 12.5, fontWeight: 950, letterSpacing: .45 }}>
                    {location.label}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                {fulfillmentLocationColumns.flatMap((location) => fulfillmentInventoryMetricColumns.map((metric) => {
                  const sortKey = `${location.key}.${metric.key}` as WarehouseSortKey;
                  return (
                    <TableCell key={sortKey} align="center" sx={{ p: 0, width: metric.key === 'onHandUnavailable' || metric.key === 'onHandAvailable' ? 128 : 105, color: `${location.accent} !important`, background: `${alpha(location.accent, .14)} !important`, borderLeft: metric.key === 'reserved' ? `3px solid ${alpha(location.accent, .44)}` : undefined }}>
                      <Button
                        color="inherit"
                        onClick={() => toggleWarehouseSort(sortKey)}
                        endIcon={warehouseSort.key === sortKey ? (warehouseSort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                        sx={{ width: '100%', minWidth: 0, minHeight: 46, px: .6, borderRadius: 0, color: `${location.accent} !important`, justifyContent: 'center', whiteSpace: 'normal', lineHeight: 1.1, fontSize: 10.8, fontWeight: 950, '& .MuiButton-endIcon': { ml: .2 }, '& svg': { fontSize: 14 } }}
                      >
                        {metric.label}
                      </Button>
                    </TableCell>
                  );
                }))}
              </TableRow>
              <TableRow>
                {warehouseFilterColumns.map((column) => (
                  <TableCell key={column.key} sx={{ py: .65, px: .4, ...(column.key === 'size' ? { width: 76 } : column.key === 'globalSizeId' ? { width: 155 } : {}) }}>
                    <TextField
                      size="small"
                      value={warehouseFilters[column.key] ?? ''}
                      onChange={(event) => {
                        setWarehouseFilters((current) => ({ ...current, [column.key]: event.target.value }));
                        setWarehousePage(1);
                      }}
                      placeholder="Filter…"
                      inputProps={{ 'aria-label': `Filter ${column.label}` }}
                      sx={{ width: '100%', minWidth: column.key === 'size' ? 52 : column.key === 'globalSizeId' ? 125 : 78, '& .MuiInputBase-root': { height: 31, fontSize: 11.5 } }}
                    />
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {visibleWarehouseRows.map((row) => (
                  <TableRow key={row.size} hover sx={{ '&:nth-of-type(even)': { bgcolor: 'action.hover' } }}>
                    <TableCell sx={{ width: 76, maxWidth: 76 }}><Chip size="small" label={row.size} color="primary" variant="outlined" sx={{ minWidth: 42, fontWeight: 950 }} /></TableCell>
                    <TableCell><Typography variant="body2" fontWeight={900}>{row.globalSizeId}</Typography></TableCell>
                    {fulfillmentLocationColumns.flatMap((location) => fulfillmentInventoryMetricColumns.map((metric) => (
                      <TableCell key={`${location.key}.${metric.key}`} align="right" sx={{ borderLeft: metric.key === 'reserved' ? `2px solid ${alpha(location.accent, .22)}` : undefined }}>
                        <AvailabilityCount value={getFulfillmentInventoryValue(row, location.key, metric.key)} />
                      </TableCell>
                    )))}
                  </TableRow>
              ))}
              {!warehouseRows.length && (
                <TableRow><TableCell colSpan={44} align="center" sx={{ py: 5 }}>
                  <SearchRoundedIcon color="disabled" />
                  <Typography fontWeight={900} sx={{ mt: .5 }}>No warehouse availability matches these filters</Typography>
                </TableCell></TableRow>
              )}
              {!!warehouseRows.length && (
                <TableRow
                  sx={{
                    '& .MuiTableCell-root': {
                      py: 1.25,
                      bgcolor: (theme) => theme.palette.mode === 'light' ? '#dceafa' : '#263b51',
                      borderTop: 2,
                      borderTopColor: 'primary.main'
                    }
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" fontWeight={950} color="text.primary">Total</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" fontWeight={800} color="text.secondary">{warehouseRows.length} sizes</Typography>
                  </TableCell>
                  {fulfillmentLocationColumns.flatMap((location) => fulfillmentInventoryMetricColumns.map((metric) => (
                    <TableCell key={`${location.key}.${metric.key}`} align="right" sx={{ borderLeft: metric.key === 'reserved' ? `2px solid ${alpha(location.accent, .34)}` : undefined }}>
                      <Typography fontWeight={950}>{warehouseTotals[location.key][metric.key].toLocaleString()}</Typography>
                    </TableCell>
                  )))}
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <AvailabilityPagination
          page={warehousePage}
          pageCount={warehousePageCount}
          total={warehouseRows.length}
          onChange={setWarehousePage}
        />
      </Paper>
    </Box>
  );
}

const availabilityHeaderSx = {
  fontWeight: 950,
  whiteSpace: 'nowrap',
  background: '#2f668f !important',
  color: '#ffffff !important',
  boxShadow: 'inset 0 3px 0 #92c7e8',
  '& .MuiButton-root': {
    color: '#ffffff !important'
  }
};

function compareAvailabilityValues(left: string | number, right: string | number, direction: 'asc' | 'desc') {
  const comparison = typeof left === 'number' && typeof right === 'number'
    ? left - right
    : String(left).localeCompare(String(right), undefined, { numeric: true, sensitivity: 'base' });
  return direction === 'asc' ? comparison : -comparison;
}

function AvailabilityPagination({ page, pageCount, total, pageSize = 5, onChange }: { page: number; pageCount: number; total: number; pageSize?: number; onChange: (page: number) => void }) {
  return (
    <Stack direction={{ xs: 'column', sm: 'row' }} alignItems={{ sm: 'center' }} justifyContent="space-between" spacing={1} sx={{ px: 1.5, py: 1, borderTop: 1, borderColor: 'divider', bgcolor: 'action.hover' }}>
      <Typography variant="caption" color="text.secondary">
        Showing {total ? (page - 1) * pageSize + 1 : 0}–{Math.min(page * pageSize, total)} of {total} · {pageSize} per page
      </Typography>
      <Pagination count={pageCount} page={Math.min(page, pageCount)} onChange={(_, value) => onChange(value)} color="primary" shape="rounded" size="small" showFirstButton showLastButton />
    </Stack>
  );
}

function AvailabilitySectionHeader({ title, subtitle, exportLabel, onExport, exportDisabled = false }: { title: string; subtitle: string; exportLabel: string; onExport: () => void; exportDisabled?: boolean }) {
  return (
    <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'flex-end' }} spacing={1} sx={{ mb: 1 }}>
      <Box>
        <Typography fontWeight={950}>{title}</Typography>
        <Typography variant="body2" color="text.secondary">{subtitle}</Typography>
      </Box>
      <Button variant="outlined" size="small" startIcon={<FileDownloadRoundedIcon />} disabled={exportDisabled} onClick={onExport} sx={{ borderRadius: 2, fontWeight: 900, whiteSpace: 'nowrap' }}>
        {exportLabel}
      </Button>
    </Stack>
  );
}

function AvailabilitySummary({ label, value, tone }: { label: string; value: number; tone: 'info' | 'secondary' | 'success' }) {
  const accent = tone === 'info' ? '#1976d2' : tone === 'secondary' ? '#7b3fc6' : '#2e7d32';
  return (
    <Paper
      variant="outlined"
      sx={{
        position: 'relative',
        overflow: 'hidden',
        p: 1,
        pt: 1.25,
        borderRadius: 2.25,
        borderColor: alpha(accent, .48),
        background: (theme) => theme.palette.mode === 'light'
          ? `linear-gradient(135deg, ${alpha(accent, .18)} 0%, ${alpha(accent, .07)} 62%, #ffffff 100%)`
          : `linear-gradient(135deg, ${alpha(accent, .3)} 0%, ${alpha(accent, .12)} 70%, ${theme.palette.background.paper} 100%)`,
        boxShadow: `0 9px 24px ${alpha(accent, .13)}`,
        transition: 'transform .18s ease, box-shadow .18s ease',
        '&:before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 3,
          bgcolor: accent
        },
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: `0 13px 30px ${alpha(accent, .2)}`
        }
      }}
    >
      <Typography variant="caption" sx={{ color: accent, fontSize: 10, lineHeight: 1.1 }} fontWeight={950} textTransform="uppercase" letterSpacing={.65}>{label}</Typography>
      <Typography variant="h5" sx={{ color: accent, mt: .1, fontSize: 20, lineHeight: 1.1 }} fontWeight={950}>{value.toLocaleString()}</Typography>
      <Typography variant="caption" color="text.secondary" fontWeight={750} sx={{ fontSize: 10.5, lineHeight: 1.15 }}>units across all sizes</Typography>
    </Paper>
  );
}

function AvailabilityFlagSummary({ label, value }: { label: string; value: boolean | null }) {
  const accent = value == null ? '#64748b' : value ? '#2e7d32' : '#c62828';
  const status = value == null ? 'Not supplied' : value ? 'Enabled' : 'Disabled';
  return (
    <Paper variant="outlined" sx={{ position: 'relative', overflow: 'hidden', p: 1, pt: 1.25, borderRadius: 2.25, borderColor: alpha(accent, .48), background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(135deg, ${alpha(accent, .18)} 0%, ${alpha(accent, .07)} 62%, #ffffff 100%)` : `linear-gradient(135deg, ${alpha(accent, .3)} 0%, ${alpha(accent, .12)} 70%, ${theme.palette.background.paper} 100%)`, boxShadow: `0 9px 24px ${alpha(accent, .13)}`, '&:before': { content: '""', position: 'absolute', top: 0, left: 0, right: 0, height: 3, bgcolor: accent } }}>
      <Typography variant="caption" sx={{ color: accent, fontSize: 10, lineHeight: 1.1 }} fontWeight={950} textTransform="uppercase" letterSpacing={.65}>{label}</Typography>
      <Stack direction="row" spacing={.65} alignItems="center" sx={{ mt: .55 }}>
        <Box sx={{ color: accent, display: 'inline-flex' }}>{value == null ? <Typography fontWeight={950}>—</Typography> : value ? <CheckCircleRoundedIcon fontSize="small" /> : <CancelRoundedIcon fontSize="small" />}</Box>
        <Typography variant="h6" sx={{ color: accent, fontSize: 18, lineHeight: 1.1 }} fontWeight={950}>{status}</Typography>
      </Stack>
      <Typography variant="caption" color="text.secondary" fontWeight={750} sx={{ fontSize: 10.5, lineHeight: 1.15 }}>SKU-level configuration</Typography>
    </Paper>
  );
}

function AvailabilityMetricValue({ value, emphasize = false }: { value: number | boolean; emphasize?: boolean }) {
  if (typeof value === 'boolean') {
    return <Chip size="small" icon={value ? <CheckCircleRoundedIcon /> : <CancelRoundedIcon />} label={value ? 'Yes' : 'No'} color={value ? 'success' : 'error'} variant="outlined" sx={{ height: 23, minWidth: 62, fontWeight: 950, '& .MuiChip-icon': { fontSize: 15 } }} />;
  }
  return <Typography component="span" fontWeight={emphasize ? 950 : 900} color={value === 0 ? 'error.main' : value < 6 ? 'warning.main' : 'text.primary'}>{value.toLocaleString()}</Typography>;
}

function AvailabilityCount({ value }: { value: number }) {
  return (
    <Typography component="span" fontWeight={900} color={value === 0 ? 'error.main' : value < 6 ? 'warning.main' : 'text.primary'}>
      {value}
    </Typography>
  );
}

function SellingChannelTable({ channels }: { channels: SellingChannelTrace[] }) {
  const mismatchCount = channels.filter((channel) => hasSellingChannelMismatch(channel)).length;
  const matchedCount = channels.length - mismatchCount;
  const dropship = channels.find((channel) => channel.sellingChannel.toLowerCase() === 'dropship');
  return (
    <Box>
      <Paper variant="outlined" sx={{ px: 2, py: 1.5, mb: 1.5, borderRadius: 2.5, bgcolor: (theme) => alpha(theme.palette.primary.main, .045) }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} spacing={.75}>
          <Box>
            <Typography fontWeight={950}>Selling-channel banner comparison</Typography>
            <Typography variant="body2" color="text.secondary">Internet compares MAO, SES, and CP; Dropship compares MAO and CP.</Typography>
          </Box>
          <Stack direction="row" spacing={.75}>
            <Chip size="small" label={`${channels.length} channels`} color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
            <Chip
              size="small"
              icon={mismatchCount ? <WarningAmberRoundedIcon /> : <CheckCircleRoundedIcon />}
              label={mismatchCount ? `${mismatchCount} mismatch${mismatchCount === 1 ? '' : 'es'}` : 'All matched'}
              color={mismatchCount ? 'error' : 'success'}
              sx={{ fontWeight: 950 }}
            />
          </Stack>
        </Stack>
      </Paper>

      <Box
        sx={{
          p: .85,
          mb: 1.5,
          borderRadius: 3,
          border: 1,
          borderColor: (theme) => alpha(theme.palette.primary.main, .22),
          background: (theme) => theme.palette.mode === 'light'
            ? 'linear-gradient(120deg, #e8f2ff 0%, #eaf8ef 36%, #fff2e5 68%, #f2edff 100%)'
            : 'linear-gradient(120deg, #152a40 0%, #163326 36%, #3a2818 68%, #27203e 100%)',
          boxShadow: (theme) => `inset 0 1px 0 ${alpha(theme.palette.common.white, .38)}, 0 8px 22px ${alpha(theme.palette.common.black, .06)}`
        }}
      >
        <Typography variant="overline" color="text.secondary" fontWeight={950} letterSpacing={.9} sx={{ display: 'block', px: .35, pb: .35, lineHeight: 1.2 }}>
          Selling channel summary
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <SellingChannelSummaryCard compact label="Total channels" value={String(channels.length)} subtitle="Internet and Dropship" accent="#1976d2" />
          <SellingChannelSummaryCard compact label="Matched" value={String(matchedCount)} subtitle="Aligned across systems" accent="#2e7d32" />
          <SellingChannelSummaryCard compact label="Mismatches" value={String(mismatchCount)} subtitle="Require review" accent={mismatchCount ? '#d84315' : '#2e7d32'} />
          <SellingChannelSummaryCard
            compact
            label="SKU-level Dropship"
            value={dropship?.skuLevelEnabled ? 'Enabled' : 'Disabled'}
            subtitle="Dropship configuration"
            accent={dropship?.skuLevelEnabled ? '#7b3fc6' : '#c62828'}
          />
        </Box>
      </Box>

      {mismatchCount > 0 && (
        <Alert severity="error" sx={{ mb: 1.5 }}>
          {mismatchCount} selling channel{mismatchCount === 1 ? ' has' : 's have'} banner differences. Review the flagged sections before synchronizing.
        </Alert>
      )}

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', xl: 'repeat(2, minmax(0, 1fr))' }, gap: 1.5 }}>
        {channels.map((channel) => {
          const mismatch = hasSellingChannelMismatch(channel);
          const isDropship = channel.sellingChannel.toLowerCase() === 'dropship';
          const expectedBanners = [...new Set([
            ...channel.maoBanners,
            ...(isDropship ? [] : channel.sesBanners),
            ...channel.commonProductBanners
          ])];
          return (
            <Paper
              key={channel.sellingChannel}
              variant="outlined"
              sx={{
                overflow: 'hidden',
                borderRadius: 2.5,
                borderColor: mismatch ? 'error.light' : 'success.light',
                boxShadow: (theme) => mismatch ? `0 10px 26px ${alpha(theme.palette.error.main, .1)}` : 'none'
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                sx={{
                  px: 1.75,
                  py: 1.25,
                  borderBottom: 1,
                  borderColor: mismatch ? 'error.light' : 'success.light',
                  bgcolor: (theme) => alpha(theme.palette[mismatch ? 'error' : 'success'].main, .065)
                }}
              >
                <Stack direction="row" spacing={1} alignItems="center">
                  <Box sx={{ width: 30, height: 30, display: 'grid', placeItems: 'center', borderRadius: 1.5, color: mismatch ? 'error.main' : 'success.main', bgcolor: 'background.paper' }}>
                    <GridViewRoundedIcon fontSize="small" />
                  </Box>
                  <Typography fontWeight={950}>{channel.sellingChannel}</Typography>
                </Stack>
                <Chip
                  size="small"
                  icon={mismatch ? <WarningAmberRoundedIcon /> : <CheckCircleRoundedIcon />}
                  label={mismatch ? 'Mismatch' : 'Matched'}
                  color={mismatch ? 'error' : 'success'}
                  sx={{ fontWeight: 950 }}
                />
              </Stack>
              <TableContainer>
                <Table size="small" aria-label={`${channel.sellingChannel} banner comparison`} sx={(currentTheme) => ({ minWidth: isDropship ? 440 : 600, ...polishedTableSx(currentTheme) })}>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ p: 0 }}>
                        <EnterpriseTableHeader label="Banners MAO" />
                      </TableCell>
                      {!isDropship && (
                        <TableCell sx={{ p: 0 }}>
                          <EnterpriseTableHeader label="Banners SES" />
                        </TableCell>
                      )}
                      <TableCell sx={{ p: 0 }}>
                        <EnterpriseTableHeader label="Banners CP" />
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell><BannerList banners={channel.maoBanners} expectedBanners={expectedBanners} /></TableCell>
                      {!isDropship && <TableCell><BannerList banners={channel.sesBanners} expectedBanners={expectedBanners} /></TableCell>}
                      <TableCell><BannerList banners={channel.commonProductBanners} expectedBanners={expectedBanners} /></TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          );
        })}
      </Box>
    </Box>
  );
}

function SellingChannelSummaryCard({ label, value, subtitle, accent, compact = false }: { label: string; value: string; subtitle: string; accent: string; compact?: boolean }) {
  return (
    <Paper
      variant="outlined"
      sx={{
        position: 'relative',
        overflow: 'hidden',
        p: compact ? 1 : 1.6,
        pt: compact ? 1.25 : 1.9,
        borderRadius: 2.25,
        borderColor: alpha(accent, .48),
        background: (theme) => theme.palette.mode === 'light'
          ? `linear-gradient(135deg, ${alpha(accent, .18)}, #ffffff 92%)`
          : `linear-gradient(135deg, ${alpha(accent, .3)}, ${theme.palette.background.paper} 92%)`,
        boxShadow: `0 9px 24px ${alpha(accent, .12)}`,
        '&:before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: compact ? 3 : 5,
          bgcolor: accent
        }
      }}
    >
      <Typography variant="caption" sx={{ color: accent, fontSize: compact ? 10 : undefined, lineHeight: 1.1 }} fontWeight={950} textTransform="uppercase" letterSpacing={.55}>{label}</Typography>
      <Typography variant="h5" sx={{ color: accent, mt: compact ? .1 : .3, fontSize: compact ? 20 : undefined, lineHeight: compact ? 1.1 : undefined }} fontWeight={950}>{value}</Typography>
      <Typography variant="caption" color="text.secondary" fontWeight={750} sx={{ fontSize: compact ? 10.5 : undefined, lineHeight: 1.15 }}>{subtitle}</Typography>
    </Paper>
  );
}

function EnterpriseTableHeader({ label, align = 'left' }: { label: string; align?: 'left' | 'center' }) {
  return (
    <Box
      sx={{
        minHeight: 46,
        px: 1.5,
        display: 'flex',
        alignItems: 'center',
        justifyContent: align === 'center' ? 'center' : 'flex-start',
        color: '#fff',
        background: '#2f668f',
        boxShadow: 'inset 0 3px 0 #92c7e8',
        fontSize: 12,
        fontWeight: 950,
        letterSpacing: .25
      }}
    >
      {label}
    </Box>
  );
}

function hasSellingChannelMismatch(channel: SellingChannelTrace) {
  const normalize = (banners: string[]) => [...banners].map((banner) => banner.toLowerCase()).sort().join('|');
  const mao = normalize(channel.maoBanners);
  if (channel.sellingChannel.toLowerCase() === 'dropship') {
    return mao !== normalize(channel.commonProductBanners);
  }
  return mao !== normalize(channel.sesBanners) || mao !== normalize(channel.commonProductBanners);
}

function BannerList({ banners, expectedBanners }: { banners: string[]; expectedBanners: string[] }) {
  const normalizedPresent = new Set(banners.map((banner) => banner.toLowerCase()));
  const missingBanners = expectedBanners.filter((banner) => !normalizedPresent.has(banner.toLowerCase()));
  if (!banners.length && !missingBanners.length) return <Chip size="small" label="Not configured" color="error" variant="outlined" sx={{ fontWeight: 850 }} />;
  return (
    <Stack direction="row" spacing={.65} flexWrap="wrap" useFlexGap>
      {banners.map((banner) => (
        <Chip key={banner} size="small" label={banner} icon={<CheckCircleRoundedIcon />} color="success" variant="outlined" sx={{ fontWeight: 850, bgcolor: (theme) => alpha(theme.palette.success.main, .04) }} />
      ))}
      {missingBanners.map((banner) => (
        <Chip
          key={`missing-${banner}`}
          size="small"
          label={`${banner} · Missing`}
          icon={<CancelRoundedIcon />}
          color="error"
          variant="outlined"
          sx={{
            fontWeight: 950,
            color: '#c62828',
            bgcolor: '#ffebee',
            border: 1,
            borderColor: 'error.main',
            '& .MuiChip-icon': { color: '#c62828' },
            animation: 'missing-banner-pulse 2s ease-in-out infinite',
            '@keyframes missing-banner-pulse': {
              '0%, 100%': { boxShadow: '0 0 0 0 rgba(211,47,47,0)' },
              '50%': { boxShadow: '0 0 0 3px rgba(211,47,47,.12)' }
            }
          }}
        />
      ))}
    </Stack>
  );
}

function BannerTables({ banners }: { banners: BannerTrace[] }) {
  const readyCount = banners.filter((banner) => banner.iex && banner.iexStaging && banner.internetChannel && banner.online).length;
  const reviewCount = banners.length - readyCount;
  const onlineCount = banners.filter((banner) => banner.online).length;
  return (
    <Box>
      <Box
        sx={{
          p: .85,
          mb: 1.5,
          borderRadius: 3,
          border: 1,
          borderColor: (theme) => alpha(theme.palette.info.main, .24),
          background: (theme) => theme.palette.mode === 'light'
            ? 'linear-gradient(120deg, #e7f2fb 0%, #eaf8ef 36%, #fff2e5 68%, #f2edff 100%)'
            : 'linear-gradient(120deg, #142b3e 0%, #163326 36%, #3a2818 68%, #27203e 100%)',
          boxShadow: (theme) => `inset 0 1px 0 ${alpha(theme.palette.common.white, .38)}, 0 8px 22px ${alpha(theme.palette.common.black, .06)}`
        }}
      >
        <Typography variant="overline" color="text.secondary" fontWeight={950} letterSpacing={.9} sx={{ display: 'block', px: .35, pb: .35, lineHeight: 1.2 }}>
          Banner summary
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <SellingChannelSummaryCard compact label="Total banners" value={String(banners.length)} subtitle="Configured retail banners" accent="#2f668f" />
          <SellingChannelSummaryCard compact label="Ready" value={String(readyCount)} subtitle="All channels available" accent="#2e7d32" />
          <SellingChannelSummaryCard compact label="Review" value={String(reviewCount)} subtitle="Missing channel readiness" accent={reviewCount ? '#d84315' : '#2e7d32'} />
          <SellingChannelSummaryCard compact label="Online" value={String(onlineCount)} subtitle="Published online" accent="#7b3fc6" />
        </Box>
      </Box>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: 'repeat(2, minmax(0, 1fr))' }, gap: 1.5 }}>
        {banners.map((banner) => (
        <Paper key={banner.banner} variant="outlined" sx={{ overflow: 'hidden', borderRadius: 2.25, transition: 'transform .18s ease, box-shadow .18s ease, border-color .18s ease', '&:hover': { transform: 'translateY(-2px)', borderColor: 'primary.light', boxShadow: (theme) => `0 12px 28px ${alpha(theme.palette.common.black, .1)}` } }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ px: 1.5, py: 1.15, bgcolor: (theme) => alpha(theme.palette.primary.main, .06), borderBottom: 1, borderColor: 'divider' }}>
            <Typography fontWeight={950}>{banner.banner}</Typography>
            <Chip size="small" label={Object.values(banner).slice(1).every(Boolean) ? 'Ready' : 'Review'} color={Object.values(banner).slice(1).every(Boolean) ? 'success' : 'warning'} sx={{ fontWeight: 900 }} />
          </Stack>
          <TableContainer>
            <Table size="small" aria-label={`${banner.banner} channel status`} sx={(currentTheme) => polishedTableSx(currentTheme)}>
              <TableHead>
                <TableRow>
                  <TableCell align="center" sx={{ p: 0 }}><EnterpriseTableHeader label="IEX" align="center" /></TableCell>
                  <TableCell align="center" sx={{ p: 0 }}><EnterpriseTableHeader label="IEX staging" align="center" /></TableCell>
                  <TableCell align="center" sx={{ p: 0 }}><EnterpriseTableHeader label="Internet channel" align="center" /></TableCell>
                  <TableCell align="center" sx={{ p: 0 }}><EnterpriseTableHeader label="Online" align="center" /></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell align="center"><BooleanStatus value={banner.iex} /></TableCell>
                  <TableCell align="center"><BooleanStatus value={banner.iexStaging} /></TableCell>
                  <TableCell align="center"><BooleanStatus value={banner.internetChannel} /></TableCell>
                  <TableCell align="center"><BooleanStatus value={banner.online} /></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
        ))}
      </Box>
    </Box>
  );
}

function BooleanStatus({ value }: { value: boolean }) {
  return (
    <Tooltip title={value ? 'Available' : 'Not available'} arrow>
      <Box component="span" aria-label={value ? 'Available' : 'Not available'} sx={{ display: 'inline-flex', color: value ? 'success.main' : 'error.main' }}>
        {value ? <CheckCircleRoundedIcon fontSize="small" /> : <CancelRoundedIcon fontSize="small" />}
      </Box>
    </Tooltip>
  );
}

const xrefColumns = [
  { key: 'cpid', label: 'CPID', minWidth: 155 },
  { key: 'skuNumber', label: 'SKU Number', minWidth: 150 },
  { key: 'vendorStyle', label: 'Vendor Style', minWidth: 135 },
  { key: 'sizeDesc', label: 'Size Desc', minWidth: 100 },
  { key: 'sizeId', label: 'Size ID', minWidth: 110 },
  { key: 'globalColorId', label: 'Global Color ID', minWidth: 135 },
  { key: 'globalStyleId', label: 'Global Style ID', minWidth: 140 },
  { key: 'globalSizeId', label: 'Global Size ID', minWidth: 150 },
  { key: 'sizeCode', label: 'Size Code', minWidth: 105 },
  { key: 'styleDesc', label: 'Style Desc', minWidth: 190 },
  { key: 'division', label: 'Division', minWidth: 145 },
  { key: 'department', label: 'Department', minWidth: 120 },
  { key: 'countryCode', label: 'Country Code', minWidth: 110 }
] as const;

type XrefSortKey = (typeof xrefColumns)[number]['key'];

function XrefTable({ rows }: { rows: XrefTrace[] }) {
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [sort, setSort] = useState<{ key: XrefSortKey; direction: 'asc' | 'desc' }>({ key: 'cpid', direction: 'asc' });
  const [page, setPage] = useState(1);
  const query = globalSearch.trim().toLowerCase();
  const filteredRows = useMemo(() => rows
    .filter((row) => !query || Object.values(row).some((value) => String(value).toLowerCase().includes(query)))
    .filter((row) => xrefColumns.every((column) => {
      const filter = columnFilters[column.key]?.trim().toLowerCase();
      return !filter || String(row[column.key]).toLowerCase().includes(filter);
    }))
    .sort((left, right) => {
      const comparison = String(left[sort.key]).localeCompare(String(right[sort.key]), undefined, { numeric: true, sensitivity: 'base' });
      return sort.direction === 'asc' ? comparison : -comparison;
    }), [columnFilters, query, rows, sort]);
  const pageCount = Math.max(1, Math.ceil(filteredRows.length / 5));
  const safePage = Math.min(page, pageCount);
  const visibleRows = filteredRows.slice((safePage - 1) * 5, safePage * 5);
  const uniqueSizes = new Set(rows.map((row) => row.globalSizeId)).size;
  const divisions = new Set(rows.map((row) => row.division)).size;
  const countries = new Set(rows.map((row) => row.countryCode)).size;
  const toggleSort = (key: XrefSortKey) => {
    setPage(1);
    setSort((current) => current.key === key
      ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
      : { key, direction: 'asc' });
  };

  return (
    <Box>
      <Box sx={{ p: .85, mb: 1.5, borderRadius: 3, border: 1, borderColor: (theme) => alpha(theme.palette.info.main, .24), background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(120deg, #e8f2ff, #eaf8ef 38%, #fff3e8 70%, #f2edff)' : 'linear-gradient(120deg, #152a40, #163326 38%, #3a2818 70%, #27203e)' }}>
        <Typography variant="overline" color="text.secondary" fontWeight={950} sx={{ display: 'block', px: .35, pb: .35 }}>Xref summary</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <SellingChannelSummaryCard compact label="Xref records" value={String(rows.length)} subtitle="Linked CP records" accent="#2f668f" />
          <SellingChannelSummaryCard compact label="Global sizes" value={String(uniqueSizes)} subtitle="Unique size identifiers" accent="#2e7d32" />
          <SellingChannelSummaryCard compact label="Divisions" value={String(divisions)} subtitle="Product divisions" accent="#9a5a10" />
          <SellingChannelSummaryCard compact label="Countries" value={String(countries)} subtitle="Country codes" accent="#6b4aa5" />
        </Box>
      </Box>

      <Paper variant="outlined" sx={{ p: 1.25, mb: 1.25, borderRadius: 2.5, bgcolor: (theme) => alpha(theme.palette.info.main, .04) }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} spacing={1}>
          <Box>
            <Typography fontWeight={950}>Cross-reference records</Typography>
            <Typography variant="body2" color="text.secondary">Search across every field or refine a specific column.</Typography>
          </Box>
          <TextField size="small" value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} placeholder="Search all Xref columns…" InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} sx={{ width: { xs: '100%', sm: 310 } }} />
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ overflow: 'hidden', borderRadius: 2.5 }}>
        <TableContainer>
          <Table className="sku-trace-table-style" size="small" aria-label="SKU cross-reference records" sx={{ minWidth: 1760 }}>
            <TableHead>
              <TableRow>
                {xrefColumns.map((column) => (
                  <TableCell key={column.key} sx={{ p: 0, minWidth: column.minWidth }}>
                    <Button color="inherit" onClick={() => toggleSort(column.key)} endIcon={sort.key === column.key ? (sort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />} sx={{ width: '100%', minHeight: 46, px: 1, borderRadius: 0, justifyContent: 'flex-start', whiteSpace: 'nowrap', color: '#fff !important', bgcolor: '#2f668f', fontSize: 11.5, fontWeight: 950, '&:hover': { bgcolor: '#255273' }, '& svg': { fontSize: 15 } }}>
                      {column.label}
                    </Button>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                {xrefColumns.map((column) => (
                  <TableCell key={column.key} sx={{ px: .45, py: .6, minWidth: column.minWidth }}>
                    <TextField size="small" value={columnFilters[column.key] ?? ''} onChange={(event) => { setColumnFilters((current) => ({ ...current, [column.key]: event.target.value })); setPage(1); }} placeholder="Filter…" inputProps={{ 'aria-label': `Filter ${column.label}` }} sx={{ width: '100%', '& .MuiInputBase-root': { height: 31, fontSize: 11.5 } }} />
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {visibleRows.map((row) => (
                <TableRow key={`${row.cpid}-${row.globalSizeId}`} hover>
                  {xrefColumns.map((column) => <TableCell key={column.key} sx={{ whiteSpace: column.key === 'styleDesc' ? 'normal' : 'nowrap', fontWeight: column.key === 'cpid' || column.key === 'skuNumber' ? 900 : 700 }}>{row[column.key]}</TableCell>)}
                </TableRow>
              ))}
              {!filteredRows.length && <TableRow><TableCell colSpan={xrefColumns.length} align="center" sx={{ py: 5 }}><SearchRoundedIcon color="disabled" /><Typography fontWeight={900} sx={{ mt: .5 }}>No Xref records match these filters</Typography></TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
        <AvailabilityPagination page={safePage} pageCount={pageCount} total={filteredRows.length} onChange={setPage} />
      </Paper>
    </Box>
  );
}

const productAttributeTextKeys = ['LEGACY_SKU', 'LEGACY_SIZE_DESC', 'GLOBAL_SIZE_ID', 'VENDORSTYLE'] as const;
const productAttributeTextKeySet = new Set<string>(productAttributeTextKeys);
const productAttributeFlagKeys = productAttributeColumnKeys.filter((key) => !productAttributeTextKeySet.has(key));
type FlagStateFilter = 'all' | 'enabled' | 'mixed' | 'disabled' | 'blank';
type FlagSortMode = 'group' | 'az' | 'za' | 'status';

const productFlagGroupOrder = [
  { id: 'core', label: 'Core commerce', accent: '#2f668f' },
  { id: 'digital', label: 'Digital eligibility', accent: '#7b3fc6' },
  { id: 'cf-inclusion', label: 'CF inclusion & inventory', accent: '#2e7d32' },
  { id: 'cf-exclusion', label: 'CF cross-banner exclusions', accent: '#c62828' },
  { id: 'store-ship', label: 'Store inventory · Ship', accent: '#1976d2' },
  { id: 'store-pickup', label: 'Store inventory · Pickup', accent: '#d77a12' },
  { id: 'dropship', label: 'Dropship inclusion', accent: '#536f78' }
] as const;
type FlagCategoryFilter = 'all' | (typeof productFlagGroupOrder)[number]['id'];

function getProductFlagGroup(flag: ProductAttributeColumnKey) {
  if (flag.startsWith('ISDIGITALELIGIBLE')) return productFlagGroupOrder[1];
  if (flag.includes('CFINCLUSION') || flag.includes('CFINCLUDEINV')) return productFlagGroupOrder[2];
  if (flag.includes('CFEXCLUDE') || flag.includes('CFEXCLUSION')) return productFlagGroupOrder[3];
  if (flag.includes('INCLUDESTOREINVSHIP')) return productFlagGroupOrder[4];
  if (flag.includes('INCLUDESTOREINVPICK')) return productFlagGroupOrder[5];
  if (flag.startsWith('INCLUDEDROPSHIP')) return productFlagGroupOrder[6];
  return productFlagGroupOrder[0];
}

function ProductOnlineAvailability({ sku, banners }: { sku: string; banners: string }) {
  const bannerList = useMemo(() => [...new Set(banners.split(',').map((banner) => banner.trim()).filter(Boolean))], [banners]);
  const [statuses, setStatuses] = useState<Record<string, boolean>>({});
  const [checking, setChecking] = useState(false);
  const [checkedAt, setCheckedAt] = useState('');

  const checkAvailability = useCallback(async () => {
    setChecking(true);
    try {
      const response = await skuTraceApi.checkOnlineAvailability([{ sku, banners: bannerList }]);
      setStatuses(Object.fromEntries(response.results.map((result) => [result.banner.toUpperCase(), result.online])));
      setCheckedAt(response.checkedAt);
    } catch {
      setStatuses({});
      setCheckedAt('');
    } finally {
      setChecking(false);
    }
  }, [bannerList, sku]);

  useEffect(() => { void checkAvailability(); }, [checkAvailability]);

  const onlineCount = bannerList.filter((banner) => statuses[banner.toUpperCase()] === true).length;
  const offlineCount = bannerList.filter((banner) => statuses[banner.toUpperCase()] === false).length;
  return (
    <Paper variant="outlined" sx={{ p: { xs: 1.4, md: 1.6 }, mb: 1.5, borderRadius: 2.5, borderColor: (theme) => alpha(theme.palette.success.main, .26), background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(115deg, #edf8f0 0%, #f8fbfd 52%, #eef5fb 100%)' : 'linear-gradient(115deg, #173024 0%, #18212b 52%, #152b3c 100%)' }}>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} spacing={1} sx={{ mb: 1.15 }}>
        <Box>
          <Stack direction="row" spacing={.8} alignItems="center">
            <CheckCircleRoundedIcon color="success" />
            <Typography fontWeight={950}>Online availability</Typography>
            <Chip size="small" label={`${onlineCount} online`} color="success" variant="outlined" sx={{ fontWeight: 900 }} />
            <Chip size="small" label={`${offlineCount} not live`} color="error" variant="outlined" sx={{ fontWeight: 900 }} />
          </Stack>
          <Typography variant="body2" color="text.secondary">Live product-page status by banner for SKU {sku}.</Typography>
        </Box>
        <Stack direction="row" spacing={1} alignItems="center">
          {checkedAt && <Typography variant="caption" color="text.secondary">Checked {new Date(checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</Typography>}
          <Button size="small" variant="outlined" startIcon={<RefreshRoundedIcon sx={{ animation: checking ? 'sku-trace-spin .8s linear infinite' : 'none' }} />} disabled={checking} onClick={() => void checkAvailability()} sx={{ fontWeight: 900, borderRadius: 2 }}>Refresh</Button>
        </Stack>
      </Stack>
      {checking && <LinearProgress sx={{ mb: 1.15, height: 5, borderRadius: 99 }} />}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: .8 }}>
        {bannerList.map((banner) => {
          const online = statuses[banner.toUpperCase()];
          const href = getBannerProductUrl(banner, sku);
          const accent = online === true ? '#2e7d32' : online === false ? '#c62828' : '#64748b';
          return (
            <Box key={banner} sx={{ p: 1, borderRadius: 1.8, border: 1, borderColor: alpha(accent, .35), bgcolor: 'background.paper', boxShadow: `inset 3px 0 0 ${accent}` }}>
              <Stack direction="column" alignItems="flex-start" spacing={.55}>
                <OnlineStatusIcon online={online} checking={checking} />
                {href ? <Box component="a" href={href} target="_blank" rel="noopener noreferrer" sx={{ color: 'primary.main', fontWeight: 950, textDecoration: 'underline', textUnderlineOffset: 3 }}>{banner}</Box> : <Typography fontWeight={950}>{banner}</Typography>}
              </Stack>
              <Typography variant="caption" color="text.secondary">Product-page availability at this banner</Typography>
            </Box>
          );
        })}
      </Box>
    </Paper>
  );
}

function ProductAttributesTable({ rows, sku, banners }: { rows: ProductAttributeTrace[]; sku: string; banners: string }) {
  const productAttributePageSize = 10;
  const [flagSearch, setFlagSearch] = useState('');
  const [stateFilter, setStateFilter] = useState<FlagStateFilter>('all');
  const [categoryFilter, setCategoryFilter] = useState<FlagCategoryFilter>('all');
  const [sortMode, setSortMode] = useState<FlagSortMode>('group');
  const [page, setPage] = useState(1);
  const selectedAttributes = rows[0];

  useEffect(() => setPage(1), [categoryFilter, flagSearch, sortMode, stateFilter]);

  const allFlags = useMemo(() => selectedAttributes ? productAttributeFlagKeys.map((flag) => {
    const sizeValues = rows.map((attributes) => ({
      size: String(attributes.LEGACY_SIZE_DESC ?? '—'),
      globalSizeId: String(attributes.GLOBAL_SIZE_ID ?? ''),
      value: attributes[flag]
    }));
    const values = sizeValues.map((item) => item.value);
    const state: Exclude<FlagStateFilter, 'all'> = values.every((value) => value === true)
      ? 'enabled'
      : values.every((value) => value === false)
        ? 'disabled'
        : values.every((value) => value == null)
          ? 'blank'
          : 'mixed';
    return { flag, value: sizeValues[0]?.value ?? null, sizeValues, state, group: getProductFlagGroup(flag) };
  }) : [], [rows, selectedAttributes]);
  const allFlagValues = allFlags.flatMap((item) => item.sizeValues.map((sizeValue) => sizeValue.value));
  const enabledCount = allFlagValues.filter((value) => value === true).length;
  const disabledCount = allFlagValues.filter((value) => value === false).length;
  const blankCount = allFlagValues.length - enabledCount - disabledCount;
  const enabledFlagCount = allFlags.filter((item) => item.state === 'enabled').length;
  const disabledFlagCount = allFlags.filter((item) => item.state === 'disabled').length;
  const blankFlagCount = allFlags.filter((item) => item.state === 'blank').length;
  const mixedFlagCount = allFlags.filter((item) => item.state === 'mixed').length;
  const query = flagSearch.trim().toLowerCase();
  const filteredFlags = useMemo(() => allFlags
    .filter((item) => !query || item.flag.toLowerCase().includes(query) || item.group.label.toLowerCase().includes(query))
    .filter((item) => categoryFilter === 'all' || item.group.id === categoryFilter)
    .filter((item) => stateFilter === 'all'
      || item.state === stateFilter)
    .sort((left, right) => {
      if (sortMode === 'az') return left.flag.localeCompare(right.flag);
      if (sortMode === 'za') return right.flag.localeCompare(left.flag);
      if (sortMode === 'status') {
        const rank = (state: Exclude<FlagStateFilter, 'all'>) => state === 'enabled' ? 0 : state === 'mixed' ? 1 : state === 'disabled' ? 2 : 3;
        return rank(left.state) - rank(right.state) || left.flag.localeCompare(right.flag);
      }
      return productFlagGroupOrder.findIndex((group) => group.id === left.group.id) - productFlagGroupOrder.findIndex((group) => group.id === right.group.id) || left.flag.localeCompare(right.flag);
    }), [allFlags, categoryFilter, query, sortMode, stateFilter]);
  const pageCount = Math.max(1, Math.ceil(filteredFlags.length / productAttributePageSize));
  const safePage = Math.min(page, pageCount);
  const visibleFlags = filteredFlags.slice((safePage - 1) * productAttributePageSize, safePage * productAttributePageSize);

  if (!selectedAttributes) return <Alert severity="info">No product attributes are available for this SKU.</Alert>;

  return (
    <Box>
      <Paper variant="outlined" sx={{ p: { xs: 1.4, md: 1.75 }, mb: 1.5, borderRadius: 2.5, background: (theme) => `linear-gradient(115deg, ${alpha(theme.palette.info.main, .08)}, ${alpha(theme.palette.background.paper, .94)})` }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} justifyContent="space-between" alignItems={{ lg: 'center' }} spacing={1.25}>
          <Box>
            <Typography fontWeight={950}>Product flag workspace</Typography>
            <Typography variant="body2" color="text.secondary">Review every SKU size together, organized by operational category.</Typography>
          </Box>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ sm: 'center' }}>
            <Chip label={`${rows.length} sizes included`} color="info" variant="outlined" sx={{ fontWeight: 900 }} />
            <TextField size="small" value={flagSearch} onChange={(event) => setFlagSearch(event.target.value)} placeholder="Search flags or groups…" InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} sx={{ width: { xs: '100%', sm: 275 } }} />
            <TextField select size="small" label="Sort flags" value={sortMode} onChange={(event) => setSortMode(event.target.value as FlagSortMode)} sx={{ minWidth: 145 }}>
              <MenuItem value="group">By group</MenuItem><MenuItem value="az">A–Z</MenuItem><MenuItem value="za">Z–A</MenuItem><MenuItem value="status">By status</MenuItem>
            </TextField>
          </Stack>
        </Stack>
      </Paper>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: .8, mb: 1.5 }}>
        <ProductIdentifierCard label="LEGACY_SKU" value={String(selectedAttributes.LEGACY_SKU ?? '')} />
        <ProductIdentifierCard label="SIZE_COVERAGE" value={`${rows.length} sizes`} />
        <ProductIdentifierCard label="GLOBAL_SIZE_IDS" value={`${rows.length} IDs`} />
        <ProductIdentifierCard label="VENDORSTYLE" value={String(selectedAttributes.VENDORSTYLE ?? '')} />
      </Box>

      <ProductOnlineAvailability sku={sku} banners={banners} />

      <Box sx={{ p: .85, mb: 1.5, borderRadius: 3, border: 1, borderColor: (theme) => alpha(theme.palette.info.main, .24), background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(120deg, #e7f2fb, #eaf8ef 40%, #fff0f0 72%, #f3f0f7)' : 'linear-gradient(120deg, #142b3e, #163326 40%, #3b1f24 72%, #272b31)' }}>
        <Typography variant="overline" color="text.secondary" fontWeight={950} sx={{ display: 'block', px: .35, pb: .35 }}>Flag summary</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <SellingChannelSummaryCard compact label="Total checks" value={String(allFlagValues.length)} subtitle={`${allFlags.length} flags across ${rows.length} sizes`} accent="#2f668f" />
          <SellingChannelSummaryCard compact label="Enabled" value={String(enabledCount)} subtitle="Size-level checks" accent="#2e7d32" />
          <SellingChannelSummaryCard compact label="Disabled" value={String(disabledCount)} subtitle="Size-level checks" accent="#c62828" />
          <SellingChannelSummaryCard compact label="Blank" value={String(blankCount)} subtitle="Not supplied" accent="#64748b" />
        </Box>
      </Box>

      <Paper variant="outlined" sx={{ p: 1.25, borderRadius: 2.5 }}>
        <Stack spacing={1.05} sx={{ mb: 1.4 }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={.8} alignItems={{ sm: 'center' }}>
            <Typography variant="overline" color="text.secondary" fontWeight={950} sx={{ width: 72, flex: '0 0 auto', lineHeight: 1.2 }}>Status</Typography>
            <Stack direction="row" spacing={.65} flexWrap="wrap" useFlexGap>
              {(['all', 'enabled', 'mixed', 'disabled', 'blank'] as FlagStateFilter[]).map((filter) => {
                const count = filter === 'all' ? allFlags.length : filter === 'enabled' ? enabledFlagCount : filter === 'mixed' ? mixedFlagCount : filter === 'disabled' ? disabledFlagCount : blankFlagCount;
                const label = filter === 'enabled' ? 'All enabled' : filter === 'disabled' ? 'All disabled' : filter === 'blank' ? 'All blank' : filter.charAt(0).toUpperCase() + filter.slice(1);
                return <Chip key={filter} clickable onClick={() => setStateFilter(filter)} color={stateFilter === filter ? filter === 'enabled' ? 'success' : filter === 'disabled' ? 'error' : filter === 'mixed' ? 'warning' : 'primary' : 'default'} variant={stateFilter === filter ? 'filled' : 'outlined'} label={`${label} · ${count}`} sx={{ fontWeight: 900 }} />;
              })}
            </Stack>
          </Stack>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={.8} alignItems={{ sm: 'flex-start' }}>
            <Typography variant="overline" color="text.secondary" fontWeight={950} sx={{ width: 72, flex: '0 0 auto', lineHeight: 2.4 }}>Category</Typography>
            <Stack direction="row" spacing={.65} flexWrap="wrap" useFlexGap sx={{ flex: 1 }}>
              <Chip
                clickable
                onClick={() => setCategoryFilter('all')}
                color={categoryFilter === 'all' ? 'primary' : 'default'}
                variant={categoryFilter === 'all' ? 'filled' : 'outlined'}
                label={`All categories · ${allFlags.length}`}
                sx={{ fontWeight: 900 }}
              />
              {productFlagGroupOrder.map((group) => {
                const selected = categoryFilter === group.id;
                const count = allFlags.filter((item) => item.group.id === group.id).length;
                return (
                  <Chip
                    key={group.id}
                    clickable
                    onClick={() => setCategoryFilter(group.id)}
                    variant={selected ? 'filled' : 'outlined'}
                    label={`${group.label} · ${count}`}
                    sx={{
                      fontWeight: 900,
                      borderColor: alpha(group.accent, selected ? 1 : .42),
                      color: selected ? '#fff' : 'text.primary',
                      bgcolor: selected ? group.accent : 'transparent',
                      '&:hover': { bgcolor: selected ? alpha(group.accent, .88) : alpha(group.accent, .08) }
                    }}
                  />
                );
              })}
            </Stack>
          </Stack>

          <Typography variant="caption" color="text.secondary" sx={{ alignSelf: { sm: 'flex-end' } }}>Showing {filteredFlags.length} matching flags · 10 per page</Typography>
        </Stack>

        {productFlagGroupOrder.map((group) => {
          const groupFlags = visibleFlags.filter((item) => item.group.id === group.id);
          if (!groupFlags.length) return null;
          return (
            <Box key={group.id} sx={{ mb: 1.5, '&:last-of-type': { mb: 0 } }}>
              <Stack
                direction="row"
                spacing={.8}
                alignItems="center"
                sx={{
                  mb: .75,
                  px: 1,
                  py: .7,
                  borderRadius: 1.6,
                  border: 1,
                  borderColor: alpha(group.accent, .32),
                  bgcolor: alpha(group.accent, .11),
                  boxShadow: `inset 4px 0 0 ${group.accent}`
                }}
              >
                <Typography fontWeight={950} sx={{ color: group.accent }}>{group.label}</Typography>
                <Chip size="small" label={`${groupFlags.length} flags · ${rows.length} sizes`} variant="outlined" sx={{ ml: 'auto !important', fontWeight: 900, color: group.accent, borderColor: alpha(group.accent, .45), bgcolor: 'background.paper' }} />
              </Stack>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: 'repeat(2, minmax(0, 1fr))' }, gap: .85 }}>
                {groupFlags.map((item) => <ProductFlagCard key={item.flag} flag={item.flag} accent={group.accent} sizeValues={item.sizeValues} />)}
              </Box>
            </Box>
          );
        })}
        {!filteredFlags.length && <Box sx={{ py: 5, textAlign: 'center' }}><SearchRoundedIcon color="disabled" /><Typography fontWeight={900} sx={{ mt: .5 }}>No flags match the selected search and filters</Typography></Box>}
        <AvailabilityPagination page={safePage} pageCount={pageCount} total={filteredFlags.length} pageSize={productAttributePageSize} onChange={setPage} />
      </Paper>
    </Box>
  );
}

function ProductIdentifierCard({ label, value }: { label: string; value: string }) {
  return <Paper variant="outlined" sx={{ px: 1.25, py: 1, borderRadius: 2, borderColor: (theme) => alpha(theme.palette.info.main, .28), bgcolor: (theme) => alpha(theme.palette.info.main, .045), boxShadow: (theme) => `inset 3px 0 0 ${theme.palette.info.main}` }}><Typography variant="caption" color="text.secondary" fontWeight={900}>{label}</Typography><Typography variant="body2" fontWeight={950} color="primary.main" sx={{ mt: .2 }}>{value || '—'}</Typography></Paper>;
}

function ProductFlagCard({ flag, accent, sizeValues }: { flag: ProductAttributeColumnKey; accent: string; sizeValues: Array<{ size: string; globalSizeId: string; value: string | boolean | null }> }) {
  const enabledCount = sizeValues.filter((item) => item.value === true).length;
  const disabledCount = sizeValues.filter((item) => item.value === false).length;
  const blankCount = sizeValues.length - enabledCount - disabledCount;
  const hasIssue = disabledCount > 0 || blankCount > 0;
  const statusColor = disabledCount > 0 ? '#c62828' : blankCount > 0 ? '#d77a12' : '#2e7d32';
  return (
    <Paper variant="outlined" sx={{ p: 0, overflow: 'hidden', borderRadius: 2, borderColor: alpha(accent, .34), bgcolor: alpha(statusColor, .035), boxShadow: `inset 3px 0 0 ${accent}`, transition: 'transform .16s ease, box-shadow .16s ease', '&:hover': { transform: 'translateY(-1px)', boxShadow: `inset 3px 0 0 ${accent}, 0 7px 18px ${alpha(statusColor, .12)}` } }}>
      <Stack direction="row" spacing={1} justifyContent="space-between" alignItems="center" sx={{ pl: 1.35, pr: 1, py: .75, bgcolor: alpha(accent, .14), borderBottom: 1, borderColor: alpha(accent, .25) }}>
        <Typography variant="body2" fontWeight={950} sx={{ color: accent, overflowWrap: 'anywhere', lineHeight: 1.2, letterSpacing: .1 }}>{flag}</Typography>
        <Chip size="small" label={hasIssue ? `${enabledCount}/${sizeValues.length} enabled` : 'All sizes enabled'} sx={{ flex: '0 0 auto', height: 24, fontWeight: 900, color: statusColor, bgcolor: alpha(statusColor, .1), border: `1px solid ${alpha(statusColor, .24)}` }} />
      </Stack>
      <Box sx={{ px: 1.1, pb: 1.05, pt: .7 }}>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
          {disabledCount ? `${disabledCount} disabled` : 'No disabled sizes'}{blankCount ? ` · ${blankCount} blank` : ''}
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(92px, 1fr))', gap: .5, mt: .75 }}>
          {sizeValues.map((item) => {
            const itemEnabled = item.value === true;
            const itemDisabled = item.value === false;
            const itemColor = itemEnabled ? '#2e7d32' : itemDisabled ? '#c62828' : '#64748b';
            const itemStatus = itemEnabled ? 'Enabled' : itemDisabled ? 'Disabled' : 'Blank';
            return (
              <Tooltip key={`${item.globalSizeId}-${item.size}`} title={`${item.globalSizeId || 'No global size ID'} · ${itemStatus}`} arrow>
                <Box sx={{ px: .7, py: .55, borderRadius: 1.25, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: .45, border: 1, borderColor: alpha(itemColor, .24), bgcolor: alpha(itemColor, .075) }}>
                  <Typography variant="caption" fontWeight={900}>Size {item.size}</Typography>
                  <Box component="span" aria-label={`${item.size} ${itemStatus}`} sx={{ display: 'inline-flex', color: itemColor }}>
                    {itemEnabled ? <CheckCircleRoundedIcon sx={{ fontSize: 16 }} /> : itemDisabled ? <CancelRoundedIcon sx={{ fontSize: 16 }} /> : <Typography component="span" fontWeight={950} lineHeight={1}>—</Typography>}
                  </Box>
                </Box>
              </Tooltip>
            );
          })}
        </Box>
      </Box>
    </Paper>
  );
}

const exclusionColumns = [
  { key: 'banner', label: 'Banner', minWidth: 170 },
  { key: 'styleId', label: 'Style ID', minWidth: 130 },
  { key: 'colorId', label: 'Color ID', minWidth: 105 },
  { key: 'type', label: 'Type', minWidth: 95 },
  { key: 'status', label: 'Status', minWidth: 120 },
  { key: 'maoStatus', label: 'MAO Status', minWidth: 125 },
  { key: 'startDate', label: 'Start date', minWidth: 125 },
  { key: 'endDate', label: 'End date', minWidth: 125 }
] as const;

type ExclusionSortKey = (typeof exclusionColumns)[number]['key'];

function SkuExclusionTable({ exclusions }: { exclusions: SkuExclusionTrace[] }) {
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [sort, setSort] = useState<{ key: ExclusionSortKey; direction: 'asc' | 'desc' }>({ key: 'startDate', direction: 'desc' });
  const [page, setPage] = useState(1);
  const query = globalSearch.trim().toLowerCase();
  const filteredRows = useMemo(() => exclusions
    .filter((row) => row.status === 'active')
    .filter((row) => !query || Object.values(row).some((value) => String(value).toLowerCase().includes(query)))
    .filter((row) => exclusionColumns.every((column) => {
      const filter = columnFilters[column.key]?.trim().toLowerCase();
      return !filter || String(row[column.key]).toLowerCase().includes(filter);
    }))
    .sort((left, right) => {
      const comparison = String(left[sort.key]).localeCompare(String(right[sort.key]), undefined, { numeric: true, sensitivity: 'base' });
      return sort.direction === 'asc' ? comparison : -comparison;
    }), [columnFilters, exclusions, query, sort]);
  const pageCount = Math.max(1, Math.ceil(filteredRows.length / 5));
  const safePage = Math.min(page, pageCount);
  const visibleRows = filteredRows.slice((safePage - 1) * 5, safePage * 5);
  const mismatchCount = filteredRows.filter((row) => row.maoStatus !== row.status).length;
  const maoInactiveCount = filteredRows.filter((row) => row.maoStatus === 'inactive').length;
  const toggleSort = (key: ExclusionSortKey) => {
    setPage(1);
    setSort((current) => current.key === key
      ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
      : { key, direction: 'asc' });
  };

  return (
    <Box>
      <Paper variant="outlined" sx={{ p: 1.5, mb: 1.5, borderRadius: 2.5, bgcolor: (theme) => alpha(theme.palette.info.main, .045) }}>
        <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ md: 'center' }} spacing={1.25}>
          <Box>
            <Typography fontWeight={950}>SKU exclusion search</Typography>
            <Typography variant="body2" color="text.secondary">Search and review banner-level fulfillment exclusions for this SKU.</Typography>
          </Box>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ sm: 'center' }}>
            <Stack direction="row" spacing={.6} flexWrap="wrap" useFlexGap>
              <Chip size="small" color="success" variant="outlined" label={`${filteredRows.filter((row) => row.status === 'active').length} active`} sx={{ fontWeight: 900 }} />
              <Chip size="small" color={mismatchCount ? 'error' : 'success'} label={mismatchCount ? `${mismatchCount} MAO mismatch${mismatchCount === 1 ? '' : 'es'}` : 'MAO aligned'} sx={{ fontWeight: 950 }} />
            </Stack>
            <TextField
              size="small"
              value={globalSearch}
              onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }}
              placeholder="Search all exclusions…"
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }}
              sx={{ width: { xs: '100%', sm: 280 }, '& .MuiInputBase-root': { bgcolor: 'background.paper' } }}
            />
          </Stack>
        </Stack>
      </Paper>

      <Box
        sx={{
          p: .85,
          mb: 1.5,
          borderRadius: 3,
          border: 1,
          borderColor: (theme) => alpha(theme.palette.info.main, .24),
          background: (theme) => theme.palette.mode === 'light'
            ? 'linear-gradient(120deg, #e7f2fb 0%, #eaf8ef 36%, #fff0f0 68%, #f2edff 100%)'
            : 'linear-gradient(120deg, #142b3e 0%, #163326 36%, #3b1f24 68%, #27203e 100%)',
          boxShadow: (theme) => `inset 0 1px 0 ${alpha(theme.palette.common.white, .38)}, 0 8px 22px ${alpha(theme.palette.common.black, .06)}`
        }}
      >
        <Typography variant="overline" color="text.secondary" fontWeight={950} letterSpacing={.9} sx={{ display: 'block', px: .35, pb: .35, lineHeight: 1.2 }}>
          Exclusion summary
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: .75 }}>
          <SellingChannelSummaryCard compact label="Active exclusions" value={String(filteredRows.length)} subtitle="Current search and filters" accent="#2f668f" />
          <SellingChannelSummaryCard compact label="MAO aligned" value={String(filteredRows.length - mismatchCount)} subtitle="Active on both sides" accent="#2e7d32" />
          <SellingChannelSummaryCard compact label="MAO mismatches" value={String(mismatchCount)} subtitle="Require synchronization" accent={mismatchCount ? '#c62828' : '#2e7d32'} />
          <SellingChannelSummaryCard compact label="MAO inactive" value={String(maoInactiveCount)} subtitle="Active on FL side" accent={maoInactiveCount ? '#d84315' : '#2e7d32'} />
        </Box>
      </Box>

      {mismatchCount > 0 && (
        <Alert severity="error" icon={<WarningAmberRoundedIcon />} sx={{ mb: 1.5 }}>
          {mismatchCount} active exclusion{mismatchCount === 1 ? ' is' : 's are'} not active in MAO. Use Sync mismatches after reviewing the flagged banners.
        </Alert>
      )}

      <Paper variant="outlined" sx={{ overflow: 'hidden', borderRadius: 2.5 }}>
        <TableContainer>
          <Table size="small" aria-label="SKU exclusion search results" sx={(currentTheme) => ({ minWidth: 900, ...polishedTableSx(currentTheme) })}>
            <TableHead>
              <TableRow>
                {exclusionColumns.map((column) => (
                  <TableCell key={column.key} sx={{ minWidth: column.minWidth, p: 0 }}>
                    <Button
                      color="inherit"
                      onClick={() => toggleSort(column.key)}
                      endIcon={sort.key === column.key ? (sort.direction === 'asc' ? <ArrowUpwardRoundedIcon /> : <ArrowDownwardRoundedIcon />) : <SwapVertRoundedIcon />}
                      sx={{ width: '100%', minHeight: 46, px: 1.25, borderRadius: 0, justifyContent: 'flex-start', color: '#fff !important', background: '#2f668f', fontSize: 12, fontWeight: 950, whiteSpace: 'nowrap', '&:hover': { background: '#255273' } }}
                    >
                      {column.label}
                    </Button>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                {exclusionColumns.map((column) => (
                  <TableCell key={column.key} sx={{ py: .65 }}>
                    <TextField
                      size="small"
                      value={columnFilters[column.key] ?? ''}
                      onChange={(event) => { setColumnFilters((current) => ({ ...current, [column.key]: event.target.value })); setPage(1); }}
                      placeholder="Filter…"
                      inputProps={{ 'aria-label': `Filter ${column.label}` }}
                      sx={{ minWidth: column.key === 'banner' ? 140 : 78, '& .MuiInputBase-root': { height: 31, fontSize: 12, bgcolor: 'background.paper' } }}
                    />
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {visibleRows.map((exclusion) => {
                const mismatch = exclusion.maoStatus !== exclusion.status;
                return (
                <TableRow key={`${exclusion.banner}-${exclusion.styleId}-${exclusion.colorId}-${exclusion.type}`} hover sx={mismatch ? { '& .MuiTableCell-root': { bgcolor: (theme) => `${alpha(theme.palette.error.main, .055)} !important` }, '& .MuiTableCell-root:first-of-type': { boxShadow: (theme) => `inset 4px 0 0 ${theme.palette.error.main}` } } : undefined}>
                  <TableCell><Typography variant="body2" fontWeight={900}>{exclusion.banner}</Typography></TableCell>
                  <TableCell><Typography variant="body2" fontWeight={950} color="primary.main">{exclusion.styleId}</Typography></TableCell>
                  <TableCell><Typography variant="body2" fontWeight={850}>{exclusion.colorId}</Typography></TableCell>
                  <TableCell><Chip size="small" label={exclusion.type} color="secondary" variant="outlined" sx={{ minWidth: 62, fontWeight: 950 }} /></TableCell>
                  <TableCell><ExclusionStatus status={exclusion.status} /></TableCell>
                  <TableCell sx={mismatch ? { bgcolor: '#ffebee !important' } : undefined}>
                    <Stack direction="row" spacing={.6} alignItems="center">
                      <ExclusionStatus status={exclusion.maoStatus} />
                      {mismatch && <WarningAmberRoundedIcon color="error" fontSize="small" />}
                    </Stack>
                  </TableCell>
                  <TableCell><Typography variant="body2" sx={{ whiteSpace: 'nowrap' }}>{formatDate(exclusion.startDate)}</Typography></TableCell>
                  <TableCell><Typography variant="body2" sx={{ whiteSpace: 'nowrap' }}>{formatDate(exclusion.endDate)}</Typography></TableCell>
                </TableRow>
                );
              })}
              {!filteredRows.length && (
                <TableRow><TableCell colSpan={8} align="center" sx={{ py: 5 }}>
                  <SearchRoundedIcon color="disabled" />
                  <Typography fontWeight={900} sx={{ mt: .5 }}>No exclusions match these filters</Typography>
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <AvailabilityPagination page={safePage} pageCount={pageCount} total={filteredRows.length} onChange={setPage} />
      </Paper>
    </Box>
  );
}

function ExclusionStatus({ status }: { status?: SkuExclusionTrace['status'] | NonNullable<SkuExclusionTrace['maoStatus']> }) {
  if (!status) return null;
  const color = status === 'active' ? 'success' : status === 'scheduled' ? 'info' : status === 'failed' || status === 'inactive' ? 'error' : 'warning';
  return <Chip size="small" label={status.charAt(0).toUpperCase() + status.slice(1)} color={color} sx={{ minWidth: 86, fontWeight: 950 }} />;
}

function DetailSection({ items }: { items: [string, string][] }) {
  return <Box>
    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' }, gap: 1.5 }}>
      {items.map(([label, value]) => (
        <Paper key={label} variant="outlined" sx={{ p: 2, borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.default, .55), transition: 'transform .18s ease, border-color .18s ease, box-shadow .18s ease', '&:hover': { transform: 'translateY(-2px)', borderColor: 'primary.light', boxShadow: (theme) => `0 10px 24px ${alpha(theme.palette.common.black, .08)}` } }}>
          <Typography variant="caption" color="text.secondary" fontWeight={800} textTransform="uppercase" letterSpacing={.7}>{label}</Typography>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mt: .65 }}>
            <GridViewRoundedIcon color="primary" fontSize="small" />
            <Typography fontWeight={900}>{value}</Typography>
          </Stack>
        </Paper>
      ))}
    </Box>
    <Alert severity="info" sx={{ mt: 2.5 }}>This section was fetched independently from its SKU trace endpoint.</Alert>
  </Box>;
}

type CsvValue = string | number | boolean | null | undefined;
type CsvRow = Record<string, CsvValue>;

function buildSkuSizeAvailabilityExportRows(rows: SkuSizeAvailability[], sku: string, availability: SkuAvailabilityTrace, refreshedAt: string): CsvRow[] {
  return rows.map((size) => {
    const row: CsvRow = {
      Section: 'SKU and size availability',
      SKU: sku,
      Banner: availability.selectedBanner,
      'Ecom RF Flag': availability.ecomRfEnabled == null ? '' : availability.ecomRfEnabled ? 'Enabled' : 'Disabled',
      Size: size.size,
      'Global Size ID': size.globalSizeId
    };
    availabilityGroupColumns.forEach((group) => getAvailabilityMetricColumns(group.key).forEach((metric) => {
      const value = getSizeAvailabilityMetric(size, group.key, metric.key);
      row[`${group.label} · ${metric.label}`] = typeof value === 'boolean' ? value ? 'Yes' : 'No' : value;
    }));
    row['Refreshed At'] = refreshedAt;
    return row;
  });
}

function buildFulfillmentLocationExportRows(rows: WarehouseSizeAvailability[], sku: string, availability: SkuAvailabilityTrace, refreshedAt: string): CsvRow[] {
  return rows.map((size) => {
    const row: CsvRow = {
      Section: 'Fulfillment locations',
      SKU: sku,
      Banner: availability.selectedBanner,
      Size: size.size,
      'Global Size ID': size.globalSizeId
    };
    fulfillmentLocationColumns.forEach((location) => fulfillmentInventoryMetricColumns.forEach((metric) => {
      row[`${location.label} · ${metric.label}`] = getFulfillmentInventoryValue(size, location.key, metric.key);
    }));
    row['Refreshed At'] = refreshedAt;
    return row;
  });
}

function buildTabExportRows(data: SkuTraceTabResponse): CsvRow[] {
  if (data.tab === 'banners') {
    return (data.banners ?? []).map((banner) => ({
      SKU: data.sku,
      Banner: banner.banner,
      IEX: banner.iex ? 'Yes' : 'No',
      'IEX Staging': banner.iexStaging ? 'Yes' : 'No',
      'Internet Channel': banner.internetChannel ? 'Yes' : 'No',
      Online: banner.online ? 'Yes' : 'No',
      'Refreshed At': data.refreshedAt
    }));
  }

  if (data.tab === 'selling-channel') {
    return (data.sellingChannels ?? []).map((channel) => ({
      SKU: data.sku,
      Channel: channel.sellingChannel,
      'SKU Level Enabled': channel.skuLevelEnabled == null ? '' : channel.skuLevelEnabled ? 'Yes' : 'No',
      'Banners in MAO': channel.maoBanners.join('; '),
      'Banners in SES': channel.sesBanners.join('; '),
      'Banners in Common Product': channel.commonProductBanners.join('; '),
      'Refreshed At': data.refreshedAt
    }));
  }

  if (data.tab === 'sku-availability' && data.availability) {
    const availability = data.availability;
    const sizeRows = buildSkuSizeAvailabilityExportRows(availability.sizeAvailability, data.sku, availability, data.refreshedAt);
    const fulfillmentRows = buildFulfillmentLocationExportRows(availability.warehouseAvailability, data.sku, availability, data.refreshedAt);
    return [...sizeRows, ...fulfillmentRows];
  }

  if (data.tab === 'xref') {
    return (data.xrefs ?? []).map((xref) => ({
      CPID: xref.cpid,
      'SKU Number': xref.skuNumber,
      'Vendor Style': xref.vendorStyle,
      'Size Desc': xref.sizeDesc,
      'Size ID': xref.sizeId,
      'Global Color ID': xref.globalColorId,
      'Global Style ID': xref.globalStyleId,
      'Global Size ID': xref.globalSizeId,
      'Size Code': xref.sizeCode,
      'Style Desc': xref.styleDesc,
      Division: xref.division,
      Department: xref.department,
      'Country Code': xref.countryCode,
      'Refreshed At': data.refreshedAt
    }));
  }

  if (data.tab === 'exclusions') {
    return (data.exclusions ?? []).map((exclusion) => ({
      SKU: data.sku,
      Banner: exclusion.banner,
      'Style ID': exclusion.styleId,
      'Color ID': exclusion.colorId,
      Type: exclusion.type,
      Status: exclusion.status,
      'MAO Status': exclusion.maoStatus,
      'Start Date': exclusion.startDate,
      'End Date': exclusion.endDate,
      'Refreshed At': data.refreshedAt
    }));
  }

  if (data.tab === 'product-attributes') {
    const attributesBySize = data.productAttributes ?? [];
    const exportFlagValue = (value: CsvValue) => value == null ? '' : typeof value === 'boolean' ? value ? 'Yes' : 'No' : value;
    const groupedFlags = productFlagGroupOrder.flatMap((group) => productAttributeFlagKeys
      .filter((flag) => getProductFlagGroup(flag).id === group.id)
      .map((flag) => ({ flag, header: `${group.label} · ${flag}` })));

    return attributesBySize.map((attributes) => {
      const row: CsvRow = {
        SKU: data.sku,
        'Vendor Style': attributes.VENDORSTYLE,
        Size: attributes.LEGACY_SIZE_DESC,
        'Global Size ID': attributes.GLOBAL_SIZE_ID
      };
      groupedFlags.forEach(({ flag, header }) => {
        row[header] = exportFlagValue(attributes[flag]);
      });
      row['Refreshed At'] = data.refreshedAt;
      return row;
    });
  }

  return (data.items ?? []).map((item) => ({
    SKU: data.sku,
    Attribute: item.label,
    Value: item.value,
    'Refreshed At': data.refreshedAt
  }));
}

async function downloadTabExport(sku: string, tabKey: string, data: SkuTraceTabResponse) {
  if (data.tab === 'product-attributes') {
    await downloadProductAttributesExcel(`${sku}-${tabKey}.xlsx`, data);
    return;
  }
  downloadCsv(`${sku}-${tabKey}.csv`, buildTabExportRows(data));
}

async function downloadProductAttributesExcel(filename: string, data: SkuTraceTabResponse) {
  const attributesBySize = data.productAttributes ?? [];
  if (!attributesBySize.length) return;

  const XLSX = await import('xlsx-js-style');
  const groupedFlags = productFlagGroupOrder.map((group) => ({
    ...group,
    flags: productAttributeFlagKeys.filter((flag) => getProductFlagGroup(flag).id === group.id)
  }));
  const categoryHeaderRow: CsvValue[] = ['Identification', '', '', ''];
  const flagHeaderRow: CsvValue[] = ['SKU', 'Vendor Style', 'Size', 'Global Size ID'];
  const merges = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 3 } }];
  let nextColumn = 4;

  groupedFlags.forEach((group) => {
    group.flags.forEach((flag, index) => {
      categoryHeaderRow.push(index === 0 ? group.label : '');
      flagHeaderRow.push(flag);
    });
    if (group.flags.length > 1) {
      merges.push({ s: { r: 0, c: nextColumn }, e: { r: 0, c: nextColumn + group.flags.length - 1 } });
    }
    nextColumn += group.flags.length;
  });
  categoryHeaderRow.push('Audit');
  flagHeaderRow.push('Refreshed At');

  const dataRows = attributesBySize.map((attributes) => {
    const row: CsvValue[] = [data.sku, attributes.VENDORSTYLE, attributes.LEGACY_SIZE_DESC, attributes.GLOBAL_SIZE_ID];
    groupedFlags.forEach((group) => group.flags.forEach((flag) => {
      const value = attributes[flag];
      row.push(value == null ? '' : typeof value === 'boolean' ? value ? 'Yes' : 'No' : value);
    }));
    row.push(data.refreshedAt);
    return row;
  });

  const worksheet = XLSX.utils.aoa_to_sheet([categoryHeaderRow, flagHeaderRow, ...dataRows]);
  worksheet['!merges'] = merges;
  worksheet['!rows'] = [{ hpt: 25 }, { hpt: 52 }];
  worksheet['!cols'] = [
    { wch: 17 },
    { wch: 17 },
    { wch: 10 },
    { wch: 20 },
    ...groupedFlags.flatMap((group) => group.flags.map(() => ({ wch: 25 }))),
    { wch: 24 }
  ];
  worksheet['!autofilter'] = { ref: `A2:${XLSX.utils.encode_col(flagHeaderRow.length - 1)}${dataRows.length + 2}` };

  const excelColor = (hex: string) => hex.replace('#', '').toUpperCase();
  const lightenExcelColor = (hex: string, ratio = .82) => {
    const color = excelColor(hex);
    const channels = [0, 2, 4].map((offset) => Number.parseInt(color.slice(offset, offset + 2), 16));
    return channels.map((channel) => Math.round(channel + (255 - channel) * ratio).toString(16).padStart(2, '0')).join('').toUpperCase();
  };
  const headerBorder = {
    top: { style: 'thin', color: { rgb: 'CBD5E1' } },
    bottom: { style: 'thin', color: { rgb: '94A3B8' } },
    left: { style: 'thin', color: { rgb: 'CBD5E1' } },
    right: { style: 'thin', color: { rgb: 'CBD5E1' } }
  };
  const categoryStyle = (accent: string) => ({
    fill: { patternType: 'solid', fgColor: { rgb: excelColor(accent) } },
    font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 12 },
    alignment: { horizontal: 'center', vertical: 'center' },
    border: headerBorder
  });
  const flagStyle = (accent: string) => ({
    fill: { patternType: 'solid', fgColor: { rgb: lightenExcelColor(accent) } },
    font: { bold: true, color: { rgb: excelColor(accent) }, sz: 10 },
    alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
    border: headerBorder
  });
  const applyCellStyle = (row: number, column: number, style: object) => {
    const address = XLSX.utils.encode_cell({ r: row, c: column });
    if (worksheet[address]) worksheet[address].s = style;
  };

  for (let column = 0; column < 4; column += 1) {
    applyCellStyle(0, column, categoryStyle('#2f3b4a'));
    applyCellStyle(1, column, flagStyle('#2f3b4a'));
  }
  let categoryStartColumn = 4;
  groupedFlags.forEach((group) => {
    group.flags.forEach((_, index) => {
      applyCellStyle(0, categoryStartColumn + index, categoryStyle(group.accent));
      applyCellStyle(1, categoryStartColumn + index, flagStyle(group.accent));
    });
    categoryStartColumn += group.flags.length;
  });
  applyCellStyle(0, flagHeaderRow.length - 1, categoryStyle('#53616f'));
  applyCellStyle(1, flagHeaderRow.length - 1, flagStyle('#53616f'));

  const workbook = XLSX.utils.book_new();
  workbook.Props = { Title: `Product attributes for ${data.sku}`, Subject: 'SKU Trace product attribute flags' };
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Product Attributes');
  XLSX.writeFile(workbook, filename, { compression: true });
}

async function downloadSkuTraceResultsExcel(filename: string, rowsToExport: Row[]) {
  if (!rowsToExport.length) return;
  const XLSX = await import('xlsx-js-style');
  const headers = [
    'SKU', 'Status', 'Description', 'Launch Date', 'Launch Reservation Date', 'Launch Type', 'Launched Banners', 'Banners',
    'Image', 'Copy', 'Product Type', 'Sports Attribute', 'French Name', 'French Copy',
    'Available in IEX', 'Available in IEX Store', 'Available in IEX Warehouse', 'Available in IEX Dropship'
  ];
  const exportRows = rowsToExport.map((row) => [
    row.sku, row.skuStatus, row.description, formatDate(row.launchDate), formatDate(row.launchReservationDate), row.launchType, row.launchedBanners, row.banners,
    row.image, row.copy, row.productType, row.sportsAttribute, row.frenchName, row.frenchCopy,
    row.availableInIex, row.avavailableInIexStore, row.avavailbleInIexWhse, row.avavailableInIexDropship
  ]);
  const worksheet = XLSX.utils.aoa_to_sheet([headers, ...exportRows]);
  worksheet['!autofilter'] = { ref: `A1:${XLSX.utils.encode_col(headers.length - 1)}${exportRows.length + 1}` };
  worksheet['!freeze'] = { xSplit: 0, ySplit: 1 };
  worksheet['!cols'] = headers.map((header) => ({ wch: header === 'Description' ? 42 : header.includes('Banners') ? 24 : Math.max(14, header.length + 2) }));
  worksheet['!rows'] = [{ hpt: 27 }];
  const headerStyle = {
    fill: { patternType: 'solid', fgColor: { rgb: '2F668F' } },
    font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 10 },
    alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
    border: {
      top: { style: 'thin', color: { rgb: 'B8D8EA' } }, bottom: { style: 'thin', color: { rgb: 'B8D8EA' } },
      left: { style: 'thin', color: { rgb: 'B8D8EA' } }, right: { style: 'thin', color: { rgb: 'B8D8EA' } }
    }
  };
  headers.forEach((_, column) => {
    const address = XLSX.utils.encode_cell({ r: 0, c: column });
    if (worksheet[address]) worksheet[address].s = headerStyle;
  });
  const workbook = XLSX.utils.book_new();
  workbook.Props = { Title: 'SKU Trace Results', Subject: 'SKU Trace search export' };
  XLSX.utils.book_append_sheet(workbook, worksheet, 'SKU Trace Results');
  XLSX.writeFile(workbook, filename, { compression: true });
}

function downloadCsv(filename: string, rowsToExport: CsvRow[]) {
  if (!rowsToExport.length) return;
  const headers = [...new Set(rowsToExport.flatMap((row) => Object.keys(row)))];
  const escapeValue = (value: CsvValue) => {
    const text = String(value ?? '');
    return `"${text.replace(/"/g, '""')}"`;
  };
  const csv = [
    headers.map(escapeValue).join(','),
    ...rowsToExport.map((row) => headers.map((header) => escapeValue(row[header])).join(','))
  ].join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function formatDate(value: string) {
  const dateOnly = value.slice(0, 10);
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: '2-digit', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${dateOnly}T00:00:00Z`));
}

function LaunchCalendar({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const theme = useTheme();
  const initialDate = value ? new Date(`${value}T00:00:00`) : new Date();
  const [visibleMonth, setVisibleMonth] = useState(new Date(initialDate.getFullYear(), initialDate.getMonth(), 1));
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay();
  const cells: Array<number | null> = [
    ...Array.from({ length: firstDay }, () => null),
    ...Array.from({ length: daysInMonth }, (_, index) => index + 1)
  ];
  while (cells.length % 7) cells.push(null);

  const toDateValue = (day: number) =>
    `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const launchDays = new Set([4, 8, 11, 14, 18, 22, 25, 29]);

  return (
    <Paper
      variant="outlined"
      sx={{
        overflow: 'hidden',
        borderRadius: 2.25,
        bgcolor: 'background.paper',
        boxShadow: `0 8px 24px ${alpha('#18202b', .07)}`
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={{
          px: 1.25,
          py: 1,
          color: '#fff',
          background: 'linear-gradient(110deg, #b71117 0%, #e0373d 55%, #ef5a5f 100%)'
        }}
      >
        <IconButton
          size="small"
          aria-label="Previous month"
          onClick={() => setVisibleMonth(new Date(year, month - 1, 1))}
          sx={{ color: '#fff', bgcolor: 'rgba(255,255,255,.12)', '&:hover': { bgcolor: 'rgba(255,255,255,.22)' } }}
        >
          <ChevronLeftRoundedIcon />
        </IconButton>
        <Box sx={{ textAlign: 'center' }}>
          <Typography fontWeight={950} lineHeight={1.1}>
            {visibleMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </Typography>
          <Typography variant="caption" sx={{ color: 'rgba(255,255,255,.78)' }}>Launch calendar</Typography>
        </Box>
        <IconButton
          size="small"
          aria-label="Next month"
          onClick={() => setVisibleMonth(new Date(year, month + 1, 1))}
          sx={{ color: '#fff', bgcolor: 'rgba(255,255,255,.12)', '&:hover': { bgcolor: 'rgba(255,255,255,.22)' } }}
        >
          <ChevronRightRoundedIcon />
        </IconButton>
      </Stack>

      <Box sx={{ p: 1.25 }}>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', mb: .35 }}>
          {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
            <Typography key={day} variant="caption" align="center" color="text.secondary" fontWeight={900} sx={{ py: .45 }}>
              {day}
            </Typography>
          ))}
        </Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: .35 }}>
          {cells.map((day, index) => {
            if (!day) return <Box key={`blank-${index}`} sx={{ aspectRatio: '1.15' }} />;
            const dateValue = toDateValue(day);
            const selected = value === dateValue;
            const hasLaunch = launchDays.has(day);
            return (
              <Box key={dateValue} sx={{ position: 'relative', aspectRatio: '1.15' }}>
                <Button
                  aria-label={`Select ${visibleMonth.toLocaleDateString('en-US', { month: 'long' })} ${day}, ${year}`}
                  aria-pressed={selected}
                  onClick={() => onChange(dateValue)}
                  sx={{
                    width: '100%',
                    height: '100%',
                    minWidth: 0,
                    p: 0,
                    borderRadius: 1.5,
                    fontWeight: selected ? 950 : 750,
                    color: selected ? '#fff' : 'text.primary',
                    bgcolor: selected ? 'primary.main' : 'transparent',
                    border: '1px solid',
                    borderColor: selected ? 'primary.main' : 'transparent',
                    boxShadow: selected ? `0 5px 14px ${alpha(theme.palette.primary.main, .34)}` : 'none',
                    '&:hover': {
                      bgcolor: selected ? 'primary.dark' : alpha(theme.palette.primary.main, .08),
                      borderColor: alpha(theme.palette.primary.main, .28)
                    }
                  }}
                >
                  {day}
                </Button>
                {hasLaunch && (
                  <Box
                    aria-hidden
                    sx={{
                      position: 'absolute',
                      left: '50%',
                      bottom: 3,
                      transform: 'translateX(-50%)',
                      width: 4,
                      height: 4,
                      borderRadius: '50%',
                      bgcolor: selected ? '#fff' : 'primary.main'
                    }}
                  />
                )}
              </Box>
            );
          })}
        </Box>
      </Box>

      <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1} sx={{ px: 1.5, py: 1, borderTop: 1, borderColor: 'divider', bgcolor: alpha(theme.palette.background.default, .55) }}>
        <Stack direction="row" alignItems="center" spacing={.65}>
          <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: 'primary.main' }} />
          <Typography variant="caption" color="text.secondary">Scheduled launch</Typography>
        </Stack>
        <Typography variant="caption" fontWeight={900} color={value ? 'primary.main' : 'text.secondary'}>
          {value ? formatDate(value) : 'Select a date'}
        </Typography>
      </Stack>
    </Paper>
  );
}
