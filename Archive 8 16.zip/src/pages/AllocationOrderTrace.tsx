import { useMemo, useState, type ReactNode } from 'react';
import {
  Alert,
  Box,
  Button,
  ButtonBase,
  Chip,
  Dialog,
  DialogContent,
  InputAdornment,
  LinearProgress,
  Pagination,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import SearchIcon from '@mui/icons-material/Search';
import SyncIcon from '@mui/icons-material/Sync';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi, type AllocationTraceMismatchRow, type AllocationTraceResponse, type AllocationTraceSummaryRow } from '../services/omsApi';

type SortKey = keyof AllocationTraceMismatchRow;
type AgentFinding = {
  label: string;
  value: number;
  detail: string;
  action: string;
  tone: 'error' | 'warning' | 'info';
};

const emptySummaryRows: AllocationTraceSummaryRow[] = [];
const emptyMismatchRows: AllocationTraceMismatchRow[] = [];

const number = new Intl.NumberFormat('en-US');

export default function AllocationOrderTrace() {
  const [journey, setJourney] = useState<'allocation-submission' | 'allocation-fulfillment'>('allocation-submission');
  const [reportDate, setReportDate] = useState('2026-07-12');
  const [reportHour, setReportHour] = useState('14');
  const [submittedCriteria, setSubmittedCriteria] = useState<{ journey: 'allocation-submission' | 'allocation-fulfillment'; reportDate: string; reportHour: string } | null>(null);
  const [traceData, setTraceData] = useState<AllocationTraceResponse | null>(null);
  const [fetchError, setFetchError] = useState('');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState<Record<string, string>>({});
  const [sortKey, setSortKey] = useState<SortKey>('lastEvent');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const pageSize = 15;
  const summaryRows = traceData?.summary ?? emptySummaryRows;
  const mismatchRows = traceData?.mismatches ?? emptyMismatchRows;

  const totals = useMemo(() => summaryRows.reduce((total, row) => ({
    allocationOrders: total.allocationOrders + row.allocationOrders,
    allocationQty: total.allocationQty + row.allocationQty,
    maoOrders: total.maoOrders + row.maoOrders,
    maoQty: total.maoQty + row.maoQty,
    maoCancelledOrders: total.maoCancelledOrders + row.maoCancelledOrders,
    maoCancelledQty: total.maoCancelledQty + row.maoCancelledQty,
    whseOrders: total.whseOrders + row.whseOrders,
    whseQty: total.whseQty + row.whseQty
  }), { allocationOrders: 0, allocationQty: 0, maoOrders: 0, maoQty: 0, maoCancelledOrders: 0, maoCancelledQty: 0, whseOrders: 0, whseQty: 0 }), [summaryRows]);

  const filteredMismatches = useMemo(() => {
    const global = globalSearch.trim().toLowerCase();
    return mismatchRows
      .filter((row) => {
        if (selectedWarehouse && row.fulfillmentWhse !== selectedWarehouse) return false;
        const record = Object.values(row).join(' ').toLowerCase();
        if (global && !record.includes(global)) return false;
        return Object.entries(columnSearch).every(([key, value]) => !value.trim() || String(row[key as SortKey]).toLowerCase().includes(value.trim().toLowerCase()));
      })
      .sort((a, b) => {
        const left = a[sortKey];
        const right = b[sortKey];
        const comparison = typeof left === 'number' && typeof right === 'number' ? left - right : String(left).localeCompare(String(right));
        return sortDirection === 'asc' ? comparison : -comparison;
      });
  }, [columnSearch, globalSearch, mismatchRows, selectedWarehouse, sortDirection, sortKey]);
  const pageCount = Math.max(1, Math.ceil(filteredMismatches.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const paginatedMismatches = filteredMismatches.slice((safePage - 1) * pageSize, safePage * pageSize);
  const mismatchSummary = useMemo(() => ({
    count: filteredMismatches.length,
    quantityVariance: filteredMismatches.reduce((sum, row) => sum + Math.abs(row.variance), 0),
    affectedNodes: new Set(filteredMismatches.map((row) => row.fulfillmentWhse)).size,
    unresolved: filteredMismatches.filter((row) => row.maoStatus !== 'Created' || row.whseStatus !== 'Received').length
  }), [filteredMismatches]);
  const agentFindings = useMemo(() => {
    const missingMao = mismatchRows.filter((row) => row.maoStatus === 'Missing').length;
    const missingWarehouse = mismatchRows.filter((row) => row.whseStatus === 'Not received' || row.whseStatus === 'Rejected' || row.whseStatus === 'Pending').length;
    const quantityVariance = mismatchRows.filter((row) => row.variance !== 0).length;
    const fulfillmentJourney = submittedCriteria?.journey === 'allocation-fulfillment';
    return [
      {
        label: fulfillmentJourney ? 'Warehouse handoff missing' : 'MAO order creation missing',
        value: fulfillmentJourney ? missingWarehouse : missingMao,
        detail: fulfillmentJourney ? 'Allocation orders have not reached a receiving warehouse state.' : 'Allocation submissions do not yet have a correlated MAO store SO.',
        action: fulfillmentJourney ? 'Inspect warehouse ingest event' : 'Validate MAO creation event',
        tone: 'error' as const
      },
      {
        label: 'Quantity reconciliation',
        value: quantityVariance,
        detail: 'Allocation, MAO, and warehouse quantities are not aligned.',
        action: 'Compare source quantities and propose correction',
        tone: 'warning' as const
      },
      {
        label: 'Operational exceptions',
        value: mismatchSummary.unresolved,
        detail: 'Records remain pending, rejected, or otherwise unresolved.',
        action: 'Queue owner follow-up with event evidence',
        tone: 'info' as const
      }
    ];
  }, [mismatchRows, mismatchSummary.unresolved, submittedCriteria?.journey]);

  const submitTrace = async () => {
    if (!reportDate) return;
    setLoading(true);
    setProgress(10);
    setFetchError('');
    setPage(1);
    const timer = window.setInterval(() => setProgress((current) => Math.min(current + 16, 92)), 170);
    try {
      const response = await omsApi.getAllocationOrderTrace({ journey, reportDate, reportHour, timezone: 'America/Chicago' });
      window.clearInterval(timer);
      setProgress(100);
      setTraceData(response);
      setSubmittedCriteria(response.criteria ?? { journey, reportDate, reportHour });
      setGlobalSearch('');
      setColumnSearch({});
      setSelectedWarehouse('');
    } catch (requestError) {
      window.clearInterval(timer);
      setTraceData(null);
      setSubmittedCriteria(null);
      setFetchError(requestError instanceof Error ? requestError.message : 'Unable to load allocation trace data.');
    } finally {
      window.setTimeout(() => {
        setLoading(false);
        setProgress(0);
      }, 320);
    }
  };

  const changeSort = (key: SortKey) => {
    setPage(1);
    if (sortKey === key) setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  return (
    <Box>
      <PageHeader title="Allocation Order Trace" subtitle="Trace allocation orders created for destination stores and fulfilled from JC, Camp Hill, Reno, or Milton warehouses." badge="STORE ALLOCATION" />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
          <TextField select SelectProps={{ native: true }} size="small" label="Trace journey" value={journey} onChange={(event) => setJourney(event.target.value as 'allocation-submission' | 'allocation-fulfillment')} sx={{ minWidth: 240 }}>
            <option value="allocation-submission">Allocation order submission</option>
            <option value="allocation-fulfillment">Allocation order fulfillment</option>
          </TextField>
          <TextField size="small" type="date" label="Report date" value={reportDate} onChange={(event) => setReportDate(event.target.value)} InputLabelProps={{ shrink: true }} sx={{ minWidth: 190 }} />
          <TextField select SelectProps={{ native: true }} size="small" label="Report hour (Central Time)" value={reportHour} onChange={(event) => setReportHour(event.target.value)} sx={{ minWidth: 205 }}>
            {Array.from({ length: 24 }, (_, hour) => <option key={hour} value={String(hour).padStart(2, '0')}>{String(hour).padStart(2, '0')}:00 CT</option>)}
          </TextField>
          <Button variant="contained" startIcon={<AccountTreeIcon />} onClick={submitTrace} disabled={!reportDate} sx={{ minHeight: 40, px: 2.5 }}>Analyze allocation trace</Button>
          <Typography variant="caption" color="text.secondary" sx={{ ml: { md: 'auto !important' } }}>One journey snapshot · Central Time</Typography>
        </Stack>
        {fetchError && <Alert severity="error" sx={{ mt: 1.25 }} onClose={() => setFetchError('')}>{fetchError}</Alert>}
      </GlassCard>

      {!submittedCriteria && (
        <GlassCard sx={{ p: 3, textAlign: 'center' }}>
          <CalendarMonthIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h6" fontWeight={950} sx={{ mt: 1 }}>Choose a journey snapshot to begin</Typography>
          <Typography color="text.secondary">Select the allocation journey, report date, and Central Time hour for an AI-assisted reconciliation review.</Typography>
        </GlassCard>
      )}

      {submittedCriteria && (
        <Stack spacing={2}>
          <AgenticReview journey={submittedCriteria.journey} reportDate={submittedCriteria.reportDate} reportHour={submittedCriteria.reportHour} findings={agentFindings} mismatchRows={mismatchRows} />
          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="01" title="Reconciliation Summary" subtitle={`${submittedCriteria.journey === 'allocation-submission' ? 'Allocation order submission' : 'Allocation order fulfillment'} · ${submittedCriteria.reportDate} · ${submittedCriteria.reportHour}:00 CT`} />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Grid container spacing={1.25} sx={{ mb: 1.75 }}>
                <SummaryKpi label="Store allocations submitted" orders={totals.allocationOrders} quantity={totals.allocationQty} tone="primary" />
                <SummaryKpi label="MAO store SO created" orders={totals.maoOrders} quantity={totals.maoQty} tone="success" />
                <SummaryKpi label="Cancelled in MAO" orders={totals.maoCancelledOrders} quantity={totals.maoCancelledQty} tone="warning" />
                <SummaryKpi label="WHSE fulfillment received" orders={totals.whseOrders} quantity={totals.whseQty} tone="info" />
                <SummaryKpi label="Actual mismatches" orders={mismatchRows.length} quantity={mismatchRows.reduce((sum, row) => sum + Math.abs(row.variance), 0)} tone="error" mismatch />
              </Grid>
              <Alert severity="info" sx={{ mb: 1.5 }}>
                MAO-cancelled store SOs are intentionally stopped before warehouse release. They remain visible in the summary but are excluded from the actionable warehouse mismatch count.
              </Alert>
              <Box sx={{ mb: 1.5 }}>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ sm: 'center' }} sx={{ mb: 1 }}>
                  <Box>
                    <Typography fontWeight={950}>Warehouse reconciliation flow</Typography>
                    <Typography variant="caption" color="text.secondary">Select a warehouse lane to focus the mismatch table.</Typography>
                  </Box>
                  {selectedWarehouse && <Chip size="small" label={`${selectedWarehouse} selected`} color="primary" onDelete={() => { setSelectedWarehouse(''); setPage(1); }} />}
                </Stack>
                <Grid container spacing={1}>
                  {summaryRows.map((row) => (
                    <Grid item xs={12} lg={6} key={`flow-${row.node}`}>
                      <WarehouseFlowLane
                        row={row}
                        selected={selectedWarehouse === row.node}
                        onSelect={() => {
                          setSelectedWarehouse((current) => current === row.node ? '' : row.node);
                          setPage(1);
                        }}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Box>
              <Stack spacing={1.25}>
                <ReconciliationTableLabel title="Operational order flow" detail="Order and order-line correlations from Allocation through MAO and the fulfilling warehouse." />
                <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1.75, overflow: 'hidden' }}>
                  <Table className="sku-trace-table-style allocation-summary-table" size="small" sx={{ width: '100%', tableLayout: 'fixed', '& .MuiTableCell-root': { px: { xs: .45, md: .8 }, py: .8, whiteSpace: 'normal', fontSize: { xs: '.7rem', md: '.78rem' } } }}>
                    <TableHead>
                      <TableRow>
                        <TableCell rowSpan={2} className="summary-group summary-group-warehouse" sx={{ width: '16%' }}>Fulfilling WHSE</TableCell>
                        <TableCell colSpan={5} align="center" className="summary-group summary-group-orders">Orders</TableCell>
                        <TableCell colSpan={3} align="center" className="summary-group summary-group-lines">Order lines</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell align="right" className="summary-subhead summary-subhead-orders">Allocation</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-orders">MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-orders">WHSE</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-orders">Alc vs MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-orders">MAO vs WHSE</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-lines">Allocation</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-lines">MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-lines">Alc vs MAO</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>{summaryRows.map((row) => <OperationalReconciliationRow key={row.node} row={row} />)}</TableBody>
                  </Table>
                </Box>
                <ReconciliationTableLabel title="Release & quantity reconciliation" detail="Release completion and unit movement, including MAO cancellations that did not produce a release." />
                <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1.75, overflow: 'hidden' }}>
                  <Table className="sku-trace-table-style allocation-summary-table" size="small" sx={{ width: '100%', tableLayout: 'fixed', '& .MuiTableCell-root': { px: { xs: .45, md: .8 }, py: .8, whiteSpace: 'normal', fontSize: { xs: '.7rem', md: '.78rem' } } }}>
                    <TableHead>
                      <TableRow>
                        <TableCell rowSpan={2} className="summary-group summary-group-warehouse" sx={{ width: '16%' }}>Fulfilling WHSE</TableCell>
                        <TableCell colSpan={3} align="center" className="summary-group summary-group-releases">Releases</TableCell>
                        <TableCell colSpan={6} align="center" className="summary-group summary-group-quantity">Quantity analysis</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell align="right" className="summary-subhead summary-subhead-releases">MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-releases">WHSE</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-releases">MAO vs WHSE</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">Allocation</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">Total MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">MAO cancelled<br />(No release)</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">WHSE</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">Alc vs Total MAO</TableCell>
                        <TableCell align="right" className="summary-subhead summary-subhead-quantity">MAO vs WHSE</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>{summaryRows.map((row) => <QuantityReconciliationRow key={row.node} row={row} />)}</TableBody>
                  </Table>
                </Box>
              </Stack>
            </Box>
          </GlassCard>

          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="02" title="Actual Mismatches" subtitle="Store SO-level exceptions with Allocation, MAO, and fulfilling-warehouse details side by side" />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: 1, mb: 1.5 }}>
                <MismatchSummaryCard label="Matching mismatches" value={mismatchSummary.count} detail="Current search and filters" tone="error" />
                <MismatchSummaryCard label="Quantity variance" value={mismatchSummary.quantityVariance} detail="Absolute unit variance" tone="warning" />
                <MismatchSummaryCard label="Affected nodes" value={mismatchSummary.affectedNodes} detail="Fulfillment locations" tone="info" />
                <MismatchSummaryCard label="Missing / unresolved" value={mismatchSummary.unresolved} detail="Needs operational review" tone="primary" />
              </Box>
              <Alert severity="info" icon={<SyncIcon />} sx={{ mb: 1.5 }}>
                <Typography fontWeight={900}>How actual mismatches are fetched</Typography>
                <Typography variant="body2">The trace joins each store allocation to its MAO SO by SO order number, identifies the assigned fulfillment warehouse, and compares that warehouse's acknowledgement and quantity. Only missing records or unequal quantities appear below.</Typography>
              </Alert>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between" sx={{ mb: 1.25 }}>
                <TextField size="small" label="Global search" placeholder="Search any mismatch detail" value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} sx={{ minWidth: { md: 360 } }} InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
                <Stack direction="row" spacing={1} alignItems="center"><Chip color="error" label={`${filteredMismatches.length} mismatches`} /><Typography variant="caption" color="text.secondary">Click any column heading to sort</Typography></Stack>
              </Stack>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table className="sku-trace-table-style allocation-mismatch-table" size="small" sx={{ minWidth: 1540 }}>
                  <TableHead>
                    <TableRow>
                      <SortableHead label="SO order" field="soOrder" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Destination store" field="store" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Fulfilling WHSE" field="fulfillmentWhse" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Allocation status" field="allocationStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Alloc qty" field="allocationQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO status" field="maoStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO qty" field="maoQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="WHSE / Store status" field="whseStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Node qty" field="whseQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Variance" field="variance" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Mismatch reason" field="mismatch" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Last event" field="lastEvent" active={sortKey} direction={sortDirection} onSort={changeSort} />
                    </TableRow>
                    <TableRow>
                      {(['soOrder', 'store', 'fulfillmentWhse', 'allocationStatus', 'allocationQty', 'maoStatus', 'maoQty', 'whseStatus', 'whseQty', 'variance', 'mismatch', 'lastEvent'] as SortKey[]).map((field) => (
                        <TableCell key={field} sx={{ py: 0.7 }}><TextField variant="standard" size="small" placeholder="Filter" value={columnSearch[field] ?? ''} onChange={(event) => { setColumnSearch((current) => ({ ...current, [field]: event.target.value })); setPage(1); }} InputProps={{ disableUnderline: true }} sx={{ minWidth: field === 'mismatch' ? 170 : 90, '& input': { fontSize: '.75rem', py: 0.4 } }} /></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedMismatches.map((row) => (
                      <TableRow key={row.soOrder} hover>
                        <TableCell><Typography fontWeight={950} color="primary.main">{row.soOrder}</Typography></TableCell>
                        <TableCell><Typography fontWeight={850}>{row.store}</Typography></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" color="action" /><Typography fontWeight={850}>{row.fulfillmentWhse}</Typography></Stack></TableCell>
                        <TableCell><Status value={row.allocationStatus} /></TableCell><TableCell align="right">{row.allocationQty}</TableCell>
                        <TableCell><Status value={row.maoStatus} /></TableCell><TableCell align="right">{row.maoQty}</TableCell>
                        <TableCell><Status value={row.whseStatus} /></TableCell><TableCell align="right">{row.whseQty}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" label={row.variance > 0 ? `+${row.variance}` : row.variance} /></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><ErrorOutlineIcon color="error" fontSize="small" /><Typography variant="body2" fontWeight={800}>{row.mismatch}</Typography></Stack></TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.lastEvent}</TableCell>
                      </TableRow>
                    ))}
                    {!filteredMismatches.length && <TableRow><TableCell colSpan={12}><Alert severity="success">No mismatches match the current search and column filters.</Alert></TableCell></TableRow>}
                  </TableBody>
                </Table>
              </Box>
              {filteredMismatches.length > 0 && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems="center" sx={{ mt: 1.4 }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {number.format((safePage - 1) * pageSize + 1)}–{number.format(Math.min(safePage * pageSize, filteredMismatches.length))} of {number.format(filteredMismatches.length)} orders · 15 per page
                  </Typography>
                  <Pagination page={safePage} count={pageCount} onChange={(_, value) => setPage(value)} color="primary" size="small" showFirstButton showLastButton />
                </Stack>
              )}
            </Box>
          </GlassCard>
        </Stack>
      )}

      <Dialog open={loading} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 2.25 } }}>
        <DialogContent sx={{ p: 2.4 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Box><Typography variant="overline" color="primary.main" fontWeight={950}>Live reconciliation</Typography><Typography variant="h6" fontWeight={950}>{progress === 100 ? 'Trace ready' : 'Fetching order layers'}</Typography></Box>
            <Typography fontWeight={950} color="primary.main">{progress}%</Typography>
          </Stack>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 999, '& .MuiLinearProgress-bar': { borderRadius: 999 } }} />
          <Stack spacing={0.8} sx={{ mt: 1.5 }}>
            <ProgressStep done={progress >= 25} label="Allocation submissions loaded" />
            <ProgressStep done={progress >= 55} label="MAO SO orders correlated" />
            <ProgressStep done={progress >= 85} label="Store and warehouse actuals compared" />
          </Stack>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function AgenticReview({ journey, reportDate, reportHour, findings, mismatchRows }: { journey: 'allocation-submission' | 'allocation-fulfillment'; reportDate: string; reportHour: string; findings: AgentFinding[]; mismatchRows: AllocationTraceMismatchRow[] }) {
  const exceptionBars = [
    { label: 'MAO creation', value: mismatchRows.filter((row) => row.maoStatus === 'Missing').length, tone: 'error' as const },
    { label: 'Warehouse handoff', value: mismatchRows.filter((row) => row.whseStatus === 'Not received' || row.whseStatus === 'Rejected' || row.whseStatus === 'Pending').length, tone: 'warning' as const },
    { label: 'Quantity variance', value: mismatchRows.filter((row) => row.variance !== 0).length, tone: 'info' as const }
  ];
  const maxValue = Math.max(...exceptionBars.map((bar) => bar.value), 1);
  const journeyLabel = journey === 'allocation-submission' ? 'Allocation order submission' : 'Allocation order fulfillment';
  return (
    <GlassCard sx={{ overflow: 'hidden' }}>
      <SectionHeader number="AI" title="Agentic AI Review" subtitle={`${journeyLabel} · ${reportDate} · ${reportHour}:00 CT · Prioritized missing-data analysis`} />
      <Box sx={{ p: { xs: 1.4, md: 2 } }}>
        <Alert severity="info" icon={<AccountTreeIcon />} sx={{ mb: 1.5 }}>The agent compares Allocation, MAO, and warehouse events, identifies what is missing, and creates evidence-backed next actions for operations review.</Alert>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1.35fr .9fr' }, gap: 1.25, mb: 1.5 }}>
          <Box sx={{ p: 1.25, border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette.primary.main, .025) }}>
            <Typography variant="overline" color="primary.main" fontWeight={950}>Agent workflow</Typography>
            <Stack direction={{ xs: 'column', md: 'row' }} alignItems={{ xs: 'stretch', md: 'center' }} spacing={.65} sx={{ mt: .6 }}>
              <AgentWorkflowStage step="01" label="Observe" detail="Load journey events" icon={<SearchIcon fontSize="small" />} />
              <ArrowForwardIcon color="action" sx={{ transform: { xs: 'rotate(90deg)', md: 'none' }, alignSelf: 'center' }} />
              <AgentWorkflowStage step="02" label="Diagnose" detail="Correlate missing records" icon={<ErrorOutlineIcon fontSize="small" />} />
              <ArrowForwardIcon color="action" sx={{ transform: { xs: 'rotate(90deg)', md: 'none' }, alignSelf: 'center' }} />
              <AgentWorkflowStage step="03" label="Plan" detail="Prioritize corrective action" icon={<AccountTreeIcon fontSize="small" />} />
              <ArrowForwardIcon color="action" sx={{ transform: { xs: 'rotate(90deg)', md: 'none' }, alignSelf: 'center' }} />
              <AgentWorkflowStage step="04" label="Handoff" detail="Create owner-ready evidence" icon={<CheckCircleIcon fontSize="small" />} />
            </Stack>
          </Box>
          <Box sx={{ p: 1.25, border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
            <Typography variant="overline" color="text.secondary" fontWeight={950}>Exception distribution</Typography>
            <Stack spacing={.8} sx={{ mt: .65 }}>
              {exceptionBars.map((bar) => <Box key={bar.label}><Stack direction="row" justifyContent="space-between" alignItems="baseline"><Typography variant="caption" fontWeight={850}>{bar.label}</Typography><Typography variant="caption" fontWeight={950}>{bar.value}</Typography></Stack><Box sx={{ height: 8, mt: .35, overflow: 'hidden', borderRadius: 99, bgcolor: 'action.hover' }}><Box sx={{ width: `${(bar.value / maxValue) * 100}%`, height: '100%', borderRadius: 99, bgcolor: `${bar.tone}.main`, transition: 'width .35s ease' }} /></Box></Box>)}
            </Stack>
          </Box>
        </Box>
        <Typography variant="overline" color="text.secondary" fontWeight={950}>What the agent found and how it would act</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, minmax(0, 1fr))' }, gap: 1, mt: .45 }}>
          {findings.map((finding) => <Box key={finding.label} sx={{ p: 1.25, border: 1, borderColor: (theme) => alpha(theme.palette[finding.tone].main, .3), borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette[finding.tone].main, .05) }}><Stack direction="row" justifyContent="space-between" spacing={1} alignItems="flex-start"><Typography fontWeight={950}>{finding.label}</Typography><Chip size="small" color={finding.tone} label={number.format(finding.value)} sx={{ fontWeight: 950 }} /></Stack><Typography variant="body2" color="text.secondary" sx={{ mt: .65 }}>{finding.detail}</Typography><Box sx={{ mt: 1, pt: .85, borderTop: 1, borderColor: (theme) => alpha(theme.palette[finding.tone].main, .2) }}><Typography variant="caption" color={`${finding.tone}.main`} fontWeight={950}>Agent action</Typography><Typography variant="body2" fontWeight={800}>{finding.action}</Typography></Box></Box>)}
        </Box>
      </Box>
    </GlassCard>
  );
}

function AgentWorkflowStage({ step, label, detail, icon }: { step: string; label: string; detail: string; icon: ReactNode }) {
  return <Box sx={{ flex: 1, minWidth: 0, p: 1, border: 1, borderColor: 'divider', borderRadius: 1.35, bgcolor: 'background.paper' }}><Stack direction="row" spacing={.7} alignItems="center"><Chip size="small" label={step} color="primary" sx={{ fontWeight: 950 }} />{icon}</Stack><Typography fontWeight={950} sx={{ mt: .65 }}>{label}</Typography><Typography variant="caption" color="text.secondary">{detail}</Typography></Box>;
}

function SectionHeader({ number: sectionNumber, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return <Box sx={{ px: 2, py: 1.45, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}><Stack direction="row" spacing={1.2} alignItems="center"><Box sx={{ width: 36, height: 36, borderRadius: 1.3, display: 'grid', placeItems: 'center', bgcolor: 'primary.main', color: 'primary.contrastText', fontWeight: 950 }}>{sectionNumber}</Box><Box><Typography variant="h6" fontWeight={950}>{title}</Typography><Typography variant="body2" color="text.secondary">{subtitle}</Typography></Box></Stack></Box>;
}

function SummaryKpi({ label, orders, quantity, tone, mismatch = false }: { label: string; orders: number; quantity: number; tone: 'primary' | 'success' | 'info' | 'warning' | 'error'; mismatch?: boolean }) {
  return <Grid item xs={12} sm={6} lg={3}><Box sx={{ p: 1.4, height: '100%', border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.055) }}><Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography><Typography variant="h5" fontWeight={950}>{number.format(orders)}</Typography><Typography variant="body2" color="text.secondary">{mismatch ? `${number.format(quantity)} quantity variance` : `${number.format(quantity)} units · SO order level`}</Typography></Box></Grid>;
}

function ReconciliationTableLabel({ title, detail }: { title: string; detail: string }) {
  return <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: .25, sm: 1 }} justifyContent="space-between" alignItems={{ sm: 'baseline' }}><Typography fontWeight={950}>{title}</Typography><Typography variant="caption" color="text.secondary">{detail}</Typography></Stack>;
}

function OperationalReconciliationRow({ row }: { row: AllocationTraceSummaryRow }) {
  const eligibleMaoOrders = Math.max(row.maoOrders - row.maoCancelledOrders, 0);
  const orderAllocationVsMao = row.allocationOrders - row.maoOrders;
  const orderMaoVsWhse = eligibleMaoOrders - row.whseOrders;
  const lineAllocationVsMao = row.allocationLines - row.maoLines;

  return <TableRow hover>
    <TableCell className="summary-cell-warehouse"><Stack direction="row" spacing={1} alignItems="center"><WarehouseIcon color="action" fontSize="small" /><Typography fontWeight={900}>{row.node}</Typography></Stack></TableCell>
    <TableCell align="right" className="summary-cell-orders">{number.format(row.allocationOrders)}</TableCell>
    <TableCell align="right" className="summary-cell-orders">{number.format(row.maoOrders)}</TableCell>
    <TableCell align="right" className="summary-cell-orders">{number.format(row.whseOrders)}</TableCell>
    <TableCell align="right" className="summary-cell-orders"><ComparisonValue value={orderAllocationVsMao} /></TableCell>
    <TableCell align="right" className="summary-cell-orders"><ComparisonValue value={orderMaoVsWhse} /></TableCell>
    <TableCell align="right" className="summary-cell-lines">{number.format(row.allocationLines)}</TableCell>
    <TableCell align="right" className="summary-cell-lines">{number.format(row.maoLines)}</TableCell>
    <TableCell align="right" className="summary-cell-lines"><ComparisonValue value={lineAllocationVsMao} /></TableCell>
  </TableRow>;
}

function QuantityReconciliationRow({ row }: { row: AllocationTraceSummaryRow }) {
  const eligibleMaoQuantity = Math.max(row.maoQty - row.maoCancelledQty, 0);
  const releaseMaoVsWhse = row.maoReleases - row.whseReleases;
  const quantityAllocationVsMao = row.allocationQty - row.maoQty;
  const quantityMaoVsWhse = eligibleMaoQuantity - row.whseQty;

  return <TableRow hover>
    <TableCell className="summary-cell-warehouse"><Stack direction="row" spacing={1} alignItems="center"><WarehouseIcon color="action" fontSize="small" /><Typography fontWeight={900}>{row.node}</Typography></Stack></TableCell>
    <TableCell align="right" className="summary-cell-releases">{number.format(row.maoReleases)}</TableCell>
    <TableCell align="right" className="summary-cell-releases">{number.format(row.whseReleases)}</TableCell>
    <TableCell align="right" className="summary-cell-releases"><ComparisonValue value={releaseMaoVsWhse} /></TableCell>
    <TableCell align="right" className="summary-cell-quantity">{number.format(row.allocationQty)}</TableCell>
    <TableCell align="right" className="summary-cell-quantity">{number.format(row.maoQty)}</TableCell>
    <TableCell align="right" className="summary-cell-quantity"><Chip size="small" color="warning" variant="outlined" label={number.format(row.maoCancelledQty)} sx={{ fontWeight: 850 }} /></TableCell>
    <TableCell align="right" className="summary-cell-quantity">{number.format(row.whseQty)}</TableCell>
    <TableCell align="right" className="summary-cell-quantity"><ComparisonValue value={quantityAllocationVsMao} /></TableCell>
    <TableCell align="right" className="summary-cell-quantity"><ComparisonValue value={quantityMaoVsWhse} /></TableCell>
  </TableRow>;
}

function ComparisonValue({ value }: { value: number }) {
  const matches = value === 0;
  return <Chip size="small" color={matches ? 'success' : 'error'} variant={matches ? 'outlined' : 'filled'} label={matches ? 'Match' : `${value > 0 ? '+' : ''}${number.format(value)}`} sx={{ minWidth: 64, fontWeight: 950 }} />;
}

function MismatchSummaryCard({ label, value, detail, tone }: { label: string; value: number; detail: string; tone: 'primary' | 'info' | 'warning' | 'error' }) {
  return (
    <Box sx={{ px: 1.35, py: 1.15, border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.28), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.065), boxShadow: (theme) => `inset 4px 0 0 ${theme.palette[tone].main}` }}>
      <Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography>
      <Typography variant="h5" fontWeight={950}>{number.format(value)}</Typography>
      <Typography variant="caption" color="text.secondary">{detail}</Typography>
    </Box>
  );
}

function WarehouseFlowLane({ row, selected, onSelect }: { row: AllocationTraceSummaryRow; selected: boolean; onSelect: () => void }) {
  const eligibleMaoOrders = Math.max(row.maoOrders - row.maoCancelledOrders, 0);
  const maoGap = Math.max(row.allocationOrders - row.maoOrders, 0);
  const warehouseGap = Math.max(eligibleMaoOrders - row.whseOrders, 0);
  return (
    <ButtonBase
      onClick={onSelect}
      aria-pressed={selected}
      sx={{
        width: '100%', p: 0, overflow: 'hidden', border: 1, borderColor: selected ? 'primary.main' : 'divider', borderRadius: 1.6,
        bgcolor: (theme) => selected ? alpha(theme.palette.primary.main, 0.08) : alpha(theme.palette.background.paper, 0.72),
        textAlign: 'left', display: 'block'
      }}
    >
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ px: 1.15, py: 0.85, color: '#fff', background: selected ? 'linear-gradient(135deg, #244f70, #2f668f)' : 'linear-gradient(135deg, #376f96, #2f668f)' }}
      >
        <Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" sx={{ color: '#fff' }} /><Typography fontWeight={950}>{row.node}</Typography></Stack>
        <Chip size="small" label={`${warehouseGap} actionable gap`} sx={{ fontWeight: 900, color: warehouseGap ? '#a0161d' : '#17633c', bgcolor: warehouseGap ? '#fde8e9' : '#e1f4e9', border: '1px solid', borderColor: warehouseGap ? '#f3b5b9' : '#abd8bc' }} />
      </Stack>
      <Stack direction="row" spacing={0.65} alignItems="stretch" sx={{ p: 1.15 }}>
        <FlowStage label="Allocation → Store" value={row.allocationOrders} detail={`${maoGap} not created`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="MAO eligible" value={eligibleMaoOrders} detail={`${row.maoCancelledOrders} cancelled`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="WHSE received" value={row.whseOrders} detail={`${number.format(row.whseQty)} units`} />
      </Stack>
    </ButtonBase>
  );
}

function FlowStage({ label, value, detail }: { label: string; value: number; detail: string }) {
  return <Box sx={{ flex: 1, minWidth: 0, px: 0.8, py: 0.65, borderRadius: 1.1, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.055) }}><Typography variant="caption" color="text.secondary" noWrap>{label}</Typography><Typography fontWeight={950}>{number.format(value)}</Typography><Typography variant="caption" color="text.secondary" noWrap>{detail}</Typography></Box>;
}

function SortableHead({ label, field, active, direction, onSort }: { label: string; field: SortKey; active: SortKey; direction: 'asc' | 'desc'; onSort: (field: SortKey) => void }) {
  const isActive = active === field;
  return <TableCell sortDirection={isActive ? direction : false} sx={{ whiteSpace: 'nowrap' }}><TableSortLabel active={isActive} direction={isActive ? direction : 'asc'} hideSortIcon={false} onClick={() => onSort(field)} sx={{ width: '100%', '& .MuiTableSortLabel-icon': { opacity: isActive ? 1 : 0.55 } }}>{label}</TableSortLabel></TableCell>;
}

function Status({ value }: { value: string }) {
  const good = ['Submitted', 'Created', 'Received'].includes(value);
  const pending = value === 'Pending';
  return <Chip size="small" variant={good ? 'outlined' : 'filled'} color={good ? 'success' : pending ? 'warning' : 'error'} label={value} />;
}

function ProgressStep({ done, label }: { done: boolean; label: string }) {
  return <Stack direction="row" spacing={0.8} alignItems="center"><CheckCircleIcon color={done ? 'success' : 'disabled'} fontSize="small" /><Typography variant="body2" fontWeight={done ? 850 : 650} color={done ? 'text.primary' : 'text.secondary'}>{label}</Typography></Stack>;
}
