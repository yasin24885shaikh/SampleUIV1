export type AllocationTraceRequest = {
  journey: 'allocation-submission' | 'allocation-fulfillment';
  reportDate: string;
  reportHour: string;
  timezone: string;
};

export type AllocationTraceSummaryRow = {
  node: string;
  allocationOrders: number;
  allocationLines: number;
  allocationQty: number;
  maoOrders: number;
  maoLines: number;
  maoQty: number;
  maoCancelledOrders: number;
  maoCancelledQty: number;
  whseOrders: number;
  maoReleases: number;
  whseReleases: number;
  whseQty: number;
};

export type AllocationTraceMismatchRow = {
  soOrder: string;
  store: string;
  fulfillmentWhse: string;
  allocationStatus: string;
  allocationQty: number;
  maoStatus: string;
  maoQty: number;
  whseStatus: string;
  whseQty: number;
  variance: number;
  mismatch: string;
  lastEvent: string;
};

export type AllocationTraceResponse = {
  range: {
    fromDate: string;
    toDate: string;
    timezone: string;
  };
  criteria?: Pick<AllocationTraceRequest, 'journey' | 'reportDate' | 'reportHour'>;
  summary: AllocationTraceSummaryRow[];
  mismatches: AllocationTraceMismatchRow[];
  generatedAt: string;
};
