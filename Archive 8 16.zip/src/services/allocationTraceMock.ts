import type { AllocationTraceRequest, AllocationTraceResponse } from './allocationTraceTypes';

const summary: AllocationTraceResponse['summary'] = [
  { node: 'JC', allocationOrders: 2934, allocationLines: 3762, allocationQty: 3762, maoOrders: 2921, maoLines: 3744, maoQty: 3744, maoCancelledOrders: 9, maoCancelledQty: 12, whseOrders: 2908, maoReleases: 2912, whseReleases: 2908, whseQty: 3725 },
  { node: 'Camp Hill', allocationOrders: 2418, allocationLines: 3015, allocationQty: 3015, maoOrders: 2406, maoLines: 2998, maoQty: 2998, maoCancelledOrders: 5, maoCancelledQty: 7, whseOrders: 2399, maoReleases: 2401, whseReleases: 2399, whseQty: 2986 },
  { node: 'Reno', allocationOrders: 2187, allocationLines: 2741, allocationQty: 2741, maoOrders: 2179, maoLines: 2729, maoQty: 2729, maoCancelledOrders: 7, maoCancelledQty: 9, whseOrders: 2168, maoReleases: 2172, whseReleases: 2168, whseQty: 2711 },
  { node: 'Milton', allocationOrders: 1964, allocationLines: 2488, allocationQty: 2488, maoOrders: 1952, maoLines: 2472, maoQty: 2472, maoCancelledOrders: 5, maoCancelledQty: 6, whseOrders: 1944, maoReleases: 1947, whseReleases: 1944, whseQty: 2457 }
];

const mismatches: AllocationTraceResponse['mismatches'] = [
  { soOrder: 'SO-61820471', store: 'Store 1093', fulfillmentWhse: 'JC', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 2, whseStatus: 'Received', whseQty: 1, variance: 1, mismatch: 'Warehouse quantity short', lastEvent: '2026-07-12 14:22 CT' },
  { soOrder: 'SO-61820508', store: 'Store 1842', fulfillmentWhse: 'JC', allocationStatus: 'Submitted', allocationQty: 3, maoStatus: 'Created', maoQty: 2, whseStatus: 'Received', whseQty: 2, variance: 1, mismatch: 'MAO store SO quantity mismatch', lastEvent: '2026-07-12 13:58 CT' },
  { soOrder: 'SO-61820641', store: 'Store 4501', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 1, maoStatus: 'Missing', maoQty: 0, whseStatus: 'Not received', whseQty: 0, variance: 1, mismatch: 'Store SO not created in MAO', lastEvent: '2026-07-12 13:41 CT' },
  { soOrder: 'SO-61820713', store: 'Store 2031', fulfillmentWhse: 'Reno', allocationStatus: 'Submitted', allocationQty: 4, maoStatus: 'Created', maoQty: 4, whseStatus: 'Not received', whseQty: 0, variance: 4, mismatch: 'Warehouse ingestion missing', lastEvent: '2026-07-12 12:55 CT' },
  { soOrder: 'SO-61820789', store: 'Store 1178', fulfillmentWhse: 'Milton', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 3, whseStatus: 'Received', whseQty: 3, variance: -1, mismatch: 'MAO quantity exceeds allocation', lastEvent: '2026-07-12 12:31 CT' },
  { soOrder: 'SO-61820802', store: 'Store 2044', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 1, maoStatus: 'Created', maoQty: 1, whseStatus: 'Pending', whseQty: 0, variance: 1, mismatch: 'Warehouse acknowledgement pending', lastEvent: '2026-07-12 11:47 CT' },
  { soOrder: 'SO-61820917', store: 'Store 1266', fulfillmentWhse: 'Camp Hill', allocationStatus: 'Submitted', allocationQty: 5, maoStatus: 'Created', maoQty: 5, whseStatus: 'Received', whseQty: 4, variance: 1, mismatch: 'Warehouse quantity short', lastEvent: '2026-07-12 09:52 CT' },
  { soOrder: 'SO-61821003', store: 'Store 4170', fulfillmentWhse: 'Reno', allocationStatus: 'Submitted', allocationQty: 2, maoStatus: 'Created', maoQty: 2, whseStatus: 'Rejected', whseQty: 0, variance: 2, mismatch: 'Warehouse payload rejected', lastEvent: '2026-07-12 09:18 CT' }
];

export function buildAllocationTraceMock(request: AllocationTraceRequest): AllocationTraceResponse {
  return {
    range: { fromDate: request.reportDate, toDate: request.reportDate, timezone: request.timezone },
    criteria: { journey: request.journey, reportDate: request.reportDate, reportHour: request.reportHour },
    summary,
    mismatches,
    generatedAt: new Date().toISOString()
  };
}
