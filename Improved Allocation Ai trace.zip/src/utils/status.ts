import type { ChipProps } from '@mui/material';

export type OrderStatus =
  | 'Open'
  | 'Back Ordered'
  | 'Allocated'
  | 'Released'
  | 'DC Created'
  | 'In Process'
  | 'Picked'
  | 'Packed'
  | 'Fulfilled'
  | 'Delivered'
  | 'Pending Return'
  | 'Returned'
  | 'Cancelled'
  | 'Pending Return (extended)'
  | 'Pending Approval'
  | 'Carrier Scanned'
  | 'Received Return'
  | 'Returned (extended)'
  | 'Return Canceled';

export const orderStatuses: OrderStatus[] = [
  'Open',
  'Back Ordered',
  'Allocated',
  'Released',
  'DC Created',
  'In Process',
  'Picked',
  'Packed',
  'Fulfilled',
  'Delivered',
  'Pending Return',
  'Returned',
  'Cancelled',
  'Pending Return (extended)',
  'Pending Approval',
  'Carrier Scanned',
  'Received Return',
  'Returned (extended)',
  'Return Canceled'
];

export const statusColor: Record<OrderStatus | string, ChipProps['color']> = {
  Open: 'info',
  'Back Ordered': 'error',
  Allocated: 'secondary',
  Released: 'warning',
  'DC Created': 'info',
  'In Process': 'secondary',
  Picked: 'secondary',
  Packed: 'secondary',
  Fulfilled: 'success',
  Delivered: 'success',
  'Pending Return': 'warning',
  Returned: 'default',
  Cancelled: 'error',
  'Pending Return (extended)': 'warning',
  'Pending Approval': 'warning',
  'Carrier Scanned': 'info',
  'Received Return': 'secondary',
  'Returned (extended)': 'default',
  'Return Canceled': 'error'
};
