import { useMemo, useState } from 'react';
import {
  Box,
  Chip,
  FormControl,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import StorefrontIcon from '@mui/icons-material/Storefront';
import TuneIcon from '@mui/icons-material/Tune';
import RuleIcon from '@mui/icons-material/Rule';
import HubIcon from '@mui/icons-material/Hub';
import SearchIcon from '@mui/icons-material/Search';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi } from '../services/omsApi';

const regions = ['North America', 'EMEA'];
const shipStatuses = ['Enabled', 'Disabled', 'Capacity Hold'];
const pickStatuses = ['Enabled', 'Disabled', 'Capacity Hold'];
const utilityCards = [
  {
    key: 'store-config',
    title: 'Store Configuration',
    subtitle: 'Validate store fulfillment, pickup, ship-from-store, and node controls.',
    icon: <StorefrontIcon />,
    tone: '#1769e0',
    recordLabel: 'Store nodes'
  },
  {
    key: 'routing',
    title: 'Node Routing Rules',
    subtitle: 'Review how orders are routed across warehouse, store, supplier, and dropship nodes.',
    icon: <HubIcon />,
    tone: '#117c8b',
    recordLabel: 'Routing policies'
  },
  {
    key: 'feature-flags',
    title: 'Feature Flags',
    subtitle: 'Check business toggles for returns, split sourcing, substitutions, and release retry.',
    icon: <TuneIcon />,
    tone: '#7c3aed',
    recordLabel: 'Feature controls'
  },
  {
    key: 'eligibility',
    title: 'Eligibility Rules',
    subtitle: 'Inspect fulfillment eligibility by banner, channel, product class, and store capability.',
    icon: <RuleIcon />,
    tone: '#b45309',
    recordLabel: 'Rule sets'
  }
];

const storeConfigs = [
  { region: 'North America', store: 'ST-1093', name: 'Foot Locker North Michigan', banner: 'Foot Locker', market: 'Chicago, IL', fulfillment: 'Ship + Pickup', shipStatus: 'Enabled', pickStatus: 'Enabled', node: 'Active', pickSla: '45 min', carrier: 'UPS Ground', returns: 'Enabled' },
  { region: 'North America', store: 'ST-1842', name: 'Foot Locker Lenox Square', banner: 'Foot Locker', market: 'Atlanta, GA', fulfillment: 'Pickup Only', shipStatus: 'Disabled', pickStatus: 'Enabled', node: 'Active', pickSla: '60 min', carrier: 'Store Pickup', returns: 'Enabled' },
  { region: 'North America', store: 'ST-2268', name: 'Foot Locker Glendale Galleria', banner: 'Foot Locker', market: 'Glendale, CA', fulfillment: 'Ship + Pickup', shipStatus: 'Enabled', pickStatus: 'Enabled', node: 'Active', pickSla: '45 min', carrier: 'FedEx Home', returns: 'Enabled' },
  { region: 'North America', store: 'ST-4501', name: 'Kids Foot Locker Queens Center', banner: 'Kids Foot Locker', market: 'Queens, NY', fulfillment: 'Pickup Only', shipStatus: 'Capacity Hold', pickStatus: 'Enabled', node: 'Capacity Hold', pickSla: '90 min', carrier: 'Store Pickup', returns: 'Enabled' },
  { region: 'North America', store: 'ST-7810', name: 'Champs Sports Mall of America', banner: 'Champs Sports', market: 'Bloomington, MN', fulfillment: 'Ship Only', shipStatus: 'Enabled', pickStatus: 'Disabled', node: 'Active', pickSla: '50 min', carrier: 'UPS SurePost', returns: 'Disabled' },
  { region: 'EMEA', store: 'EU-2042', name: 'Foot Locker Oxford Street', banner: 'Foot Locker EU', market: 'London, UK', fulfillment: 'Ship + Pickup', shipStatus: 'Enabled', pickStatus: 'Enabled', node: 'Active', pickSla: '60 min', carrier: 'DHL Parcel', returns: 'Enabled' },
  { region: 'EMEA', store: 'EU-3190', name: 'Foot Locker Les Halles', banner: 'Foot Locker EU', market: 'Paris, FR', fulfillment: 'Pickup Only', shipStatus: 'Disabled', pickStatus: 'Enabled', node: 'Active', pickSla: '75 min', carrier: 'Store Pickup', returns: 'Enabled' },
  { region: 'EMEA', store: 'EU-4488', name: 'Foot Locker Centro Madrid', banner: 'Foot Locker EU', market: 'Madrid, ES', fulfillment: 'Ship Only', shipStatus: 'Capacity Hold', pickStatus: 'Disabled', node: 'Capacity Hold', pickSla: '90 min', carrier: 'Correos Express', returns: 'Enabled' },
  { region: 'EMEA', store: 'EU-5127', name: 'Foot Locker Alexanderplatz', banner: 'Foot Locker EU', market: 'Berlin, DE', fulfillment: 'Ship + Pickup', shipStatus: 'Enabled', pickStatus: 'Enabled', node: 'Active', pickSla: '60 min', carrier: 'DHL Paket', returns: 'Enabled' }
];

export default function CustomUtilities() {
  const [search, setSearch] = useState('');
  const [region, setRegion] = useState(regions[0]);
  const [activeUtility, setActiveUtility] = useState(utilityCards[0].key);
  const [stores, setStores] = useState(storeConfigs);
  const [statusMessage, setStatusMessage] = useState('');
  const activeUtilityCard = utilityCards.find((utility) => utility.key === activeUtility) ?? utilityCards[0];
  const filteredStores = useMemo(() => {
    const query = search.trim().toLowerCase();
    const regionalStores = stores.filter((store) => store.region === region);
    if (!query) return regionalStores;
    return regionalStores.filter((store) => Object.values(store).join(' ').toLowerCase().includes(query));
  }, [region, search, stores]);

  const updateStoreStatus = async (storeId: string, field: 'shipStatus' | 'pickStatus', value: string) => {
    const store = stores.find((item) => item.store === storeId);
    if (!store) return;
    try {
      await omsApi.updateStoreConfiguration(storeId, {
        region: store.region,
        shipStatus: field === 'shipStatus' ? value : store.shipStatus,
        pickStatus: field === 'pickStatus' ? value : store.pickStatus
      });
      setStores((current) => current.map((item) => item.store === storeId ? { ...item, [field]: value } : item));
      setStatusMessage(`${storeId} ${field === 'shipStatus' ? 'ship' : 'pick'} status updated to ${value}.`);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : 'Store configuration update could not be submitted.');
    }
  };

  return (
    <Box>
      <PageHeader title="Custom Utilities" subtitle="Business-friendly tools for validating store setup, routing controls, feature flags, and fulfillment eligibility." badge="Utilities" />

      <GlassCard sx={{ p: 1.4, mb: 2 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} justifyContent="space-between" alignItems={{ xs: 'stretch', md: 'center' }}>
          <Box>
            <Typography variant="subtitle1" fontWeight={950}>Utility Region Context</Typography>
            <Typography variant="body2" color="text.secondary">All utilities below use the selected region for business configuration lookup.</Typography>
          </Box>
          <FormControl size="small" sx={{ minWidth: { xs: '100%', md: 220 } }}>
            <InputLabel>Customer Region</InputLabel>
            <Select label="Customer Region" value={region} onChange={(event) => setRegion(event.target.value)}>
              {regions.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
            </Select>
          </FormControl>
        </Stack>
      </GlassCard>

      <Grid container spacing={2} sx={{ minWidth: 0 }}>
        <Grid item xs={12} lg={3} sx={{ minWidth: 0 }}>
          <GlassCard sx={{ p: 1.2, height: '100%' }}>
            <Typography variant="subtitle2" fontWeight={950} sx={{ px: 0.6, mb: 1 }}>Utility Navigator</Typography>
            <Stack spacing={0.8}>
              {utilityCards.map((utility) => {
                const active = utility.key === activeUtility;
                return (
                  <Box
                    component="button"
                    key={utility.key}
                    onClick={() => setActiveUtility(utility.key)}
                    style={{ border: 0, textAlign: 'left', cursor: 'pointer', background: 'transparent', font: 'inherit' }}
                    sx={{
                      width: '100%',
                      minWidth: 0,
                      p: 1.15,
                      borderRadius: 1.6,
                      color: 'text.primary',
                      bgcolor: active ? alpha(utility.tone, 0.12) : 'transparent',
                      boxShadow: active ? `inset 3px 0 0 ${utility.tone}` : 'none',
                      '&:hover': { bgcolor: alpha(utility.tone, 0.08) }
                    }}
                  >
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Box sx={{ width: 34, height: 34, borderRadius: 1.2, display: 'grid', placeItems: 'center', color: utility.tone, bgcolor: alpha(utility.tone, 0.1) }}>{utility.icon}</Box>
                      <Box sx={{ minWidth: 0 }}>
                        <Typography variant="body2" fontWeight={950}>{utility.title}</Typography>
                        <Typography variant="caption" color="text.secondary">{utility.recordLabel}</Typography>
                      </Box>
                    </Stack>
                  </Box>
                );
              })}
            </Stack>
          </GlassCard>
        </Grid>

        <Grid item xs={12} lg={9} sx={{ minWidth: 0 }}>
          <GlassCard sx={{ overflow: 'hidden', minWidth: 0 }}>
            <Box sx={{ px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: alpha(activeUtilityCard.tone, 0.06) }}>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} justifyContent="space-between" alignItems={{ xs: 'stretch', md: 'center' }}>
                <Stack direction="row" spacing={1.2} alignItems="center">
                  <Box sx={{ width: 42, height: 42, borderRadius: 1.5, display: 'grid', placeItems: 'center', color: activeUtilityCard.tone, bgcolor: alpha(activeUtilityCard.tone, 0.1), border: `1px solid ${alpha(activeUtilityCard.tone, 0.22)}` }}>
                    {activeUtilityCard.icon}
                  </Box>
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="h6" fontWeight={950}>{activeUtilityCard.title}</Typography>
                    <Typography variant="body2" color="text.secondary">{activeUtilityCard.subtitle}</Typography>
                  </Box>
                </Stack>
                <Chip label={region} color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
              </Stack>
            </Box>

            {activeUtility === 'store-config' ? (
              <StoreConfigUtility search={search} setSearch={setSearch} stores={filteredStores} statusMessage={statusMessage} onUpdateStoreStatus={updateStoreStatus} />
            ) : (
              <PlaceholderUtility utility={activeUtilityCard} region={region} />
            )}
          </GlassCard>
        </Grid>
      </Grid>
    </Box>
  );
}

function StoreConfigUtility({
  search,
  setSearch,
  stores,
  statusMessage,
  onUpdateStoreStatus
}: {
  search: string;
  setSearch: (value: string) => void;
  stores: typeof storeConfigs;
  statusMessage: string;
  onUpdateStoreStatus: (storeId: string, field: 'shipStatus' | 'pickStatus', value: string) => void;
}) {
  return (
    <>
      <Box sx={{ px: 2, py: 1.35, borderBottom: 1, borderColor: 'divider' }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between">
          <TextField
            size="small"
            label="Search stores"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Store, banner, market, status"
            sx={{ minWidth: { xs: '100%', md: 320 } }}
            InputProps={{
              startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
            }}
          />
          {statusMessage && <Chip label={statusMessage} color="success" variant="outlined" sx={{ fontWeight: 850, justifyContent: 'flex-start' }} />}
        </Stack>
      </Box>
      <Box sx={{ overflowX: 'auto', maxWidth: '100%' }}>
        <Table
          size="small"
          sx={{
            minWidth: { xs: 980, md: 1120 },
            '& th, & td': {
              px: { xs: 0.75, md: 1 },
              py: 0.85,
              whiteSpace: 'normal',
              overflowWrap: 'anywhere'
            },
            '& th': {
              whiteSpace: 'nowrap'
            }
          }}
        >
          <TableHead>
            <TableRow>
              <TableCell>Store</TableCell>
              <TableCell>Store Name</TableCell>
              <TableCell>Banner</TableCell>
              <TableCell>Market</TableCell>
              <TableCell>Fulfillment</TableCell>
              <TableCell>Ship Status</TableCell>
              <TableCell>Pick Status</TableCell>
              <TableCell>Node Status</TableCell>
              <TableCell>Pick SLA</TableCell>
              <TableCell>Carrier</TableCell>
              <TableCell>Returns</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {stores.map((store) => (
              <TableRow hover key={store.store}>
                <TableCell sx={{ fontWeight: 950 }}>{store.store}</TableCell>
                <TableCell sx={{ fontWeight: 850, maxWidth: 170 }}>{store.name}</TableCell>
                <TableCell>{store.banner}</TableCell>
                <TableCell sx={{ maxWidth: 120 }}>{store.market}</TableCell>
                <TableCell><Chip size="small" label={store.fulfillment} color="primary" variant="outlined" /></TableCell>
                <TableCell>
                  <StatusSelect value={store.shipStatus} onChange={(value) => onUpdateStoreStatus(store.store, 'shipStatus', value)} />
                </TableCell>
                <TableCell>
                  <StatusSelect value={store.pickStatus} onChange={(value) => onUpdateStoreStatus(store.store, 'pickStatus', value)} />
                </TableCell>
                <TableCell><Chip size="small" label={store.node} color={store.node === 'Active' ? 'success' : 'warning'} /></TableCell>
                <TableCell sx={{ fontWeight: 850 }}>{store.pickSla}</TableCell>
                <TableCell>{store.carrier}</TableCell>
                <TableCell><Chip size="small" label={store.returns} color={store.returns === 'Enabled' ? 'success' : 'default'} variant="outlined" /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Box>
    </>
  );
}

function PlaceholderUtility({ utility, region }: { utility: (typeof utilityCards)[number]; region: string }) {
  return (
    <Box sx={{ p: 2 }}>
      <Grid container spacing={1.5}>
        {['Current Configuration', 'Last Refreshed', 'Business Owner'].map((label, index) => (
          <Grid item xs={12} md={4} key={label} sx={{ minWidth: 0 }}>
            <Box sx={{ p: 1.4, border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: alpha(utility.tone, 0.055) }}>
              <Typography variant="caption" color="text.secondary">{label}</Typography>
              <Typography fontWeight={950}>{index === 0 ? region : index === 1 ? 'Today 09:30 CT' : 'Business Operations'}</Typography>
            </Box>
          </Grid>
        ))}
      </Grid>
      <Typography sx={{ mt: 2 }} color="text.secondary">
        {utility.title} is part of the Custom Utilities hub. This panel is ready for backend data and business-specific controls.
      </Typography>
    </Box>
  );
}

function StatusSelect({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <Select
      size="small"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      sx={{
        minWidth: { xs: 112, sm: 124 },
        maxWidth: '100%',
        fontWeight: 900,
        '& .MuiSelect-select': { py: 0.55 }
      }}
    >
      {[...shipStatuses, ...pickStatuses]
        .filter((option, index, options) => options.indexOf(option) === index)
        .map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
    </Select>
  );
}
