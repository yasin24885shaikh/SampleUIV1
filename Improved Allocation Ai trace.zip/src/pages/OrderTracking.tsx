import { useMemo, useState, type MouseEvent as ReactMouseEvent, type ReactNode } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  ButtonBase,
  Checkbox,
  Chip,
  Collapse,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  ListItemText,
  ListItemIcon,
  LinearProgress,
  Menu,
  MenuItem,
  OutlinedInput,
  Pagination,
  Radio,
  RadioGroup,
  Select,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Tooltip,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchIcon from '@mui/icons-material/Search';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import StorefrontIcon from '@mui/icons-material/Storefront';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import TuneIcon from '@mui/icons-material/Tune';
import PauseCircleFilledIcon from '@mui/icons-material/PauseCircleFilled';
import AssignmentReturnIcon from '@mui/icons-material/AssignmentReturn';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import CloseIcon from '@mui/icons-material/Close';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AltRouteIcon from '@mui/icons-material/AltRoute';
import BlockIcon from '@mui/icons-material/Block';
import SyncIcon from '@mui/icons-material/Sync';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import { motion } from 'framer-motion';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import StatusChip from '../components/StatusChip';
import { ApiErrorState } from '../components/ApiFeedback';
import { type Fulfillment, type Order, type OrderLine, type Release } from '../services/mockData';
import { omsApi } from '../services/omsApi';
import { orderStatuses, type OrderStatus } from '../utils/status';

const fulfillmentTypes: Order['fulfillmentType'][] = ['Store', 'Supplier', 'DC'];
const banners = ['FL-US', 'CH-US', 'KFL-US', 'FL-CA', 'CH-CA'];
const businessOrderTypes = ['Web', 'SaveTheSale', 'CallCenter', 'Launch', 'EnterpriseBulk', 'StoreTransfer', 'Replenishment'];
const pageSize = 15;
const popupPageSize = 5;
const nonCustomerPageSize = 5;
const showFulfillmentNodeAi = false;

type OrderPopulation = '' | 'customer' | 'nonCustomer';

type SubmittedSearchCriteria = {
  orderPopulation: Exclude<OrderPopulation, ''>;
  orderNumbers: string[];
  sku: string;
  statuses: OrderStatus[];
  businessOrderType: string;
  fromDate: string;
  toDate: string;
  fulfillmentType: string;
  banner: string;
};

function getOrderAccent(status: OrderStatus) {
  const accents: Partial<Record<OrderStatus, string>> = {
    Released: '#e77718',
    Fulfilled: '#168a51',
    Delivered: '#168a51',
    'Back Ordered': '#c62828',
    Cancelled: '#64748b',
    'Pending Return': '#9a6700',
    'Pending Return (extended)': '#9a6700',
    Returned: '#596475',
    'Returned (extended)': '#596475',
    'Return Canceled': '#64748b'
  };
  return accents[status] ?? '#1769e0';
}

function getFulfillmentAccent(type: Fulfillment['type']) {
  return type === 'Warehouse' ? '#1769e0' : type === 'Store' ? '#16a064' : '#8b5cf6';
}

function getOrderLines(order: Order): OrderLine[] {
  const linesByNumber = new Map<string, OrderLine>();
  order.releases.forEach((release) => {
    if (!linesByNumber.has(release.orderLineId)) {
      linesByNumber.set(release.orderLineId, {
        lineNumber: release.lineNumber,
        sku: release.sku,
        productName: release.productName,
        orderedQty: release.orderedQty,
        lineTotal: release.lineTotal,
        cancelledTotal: release.cancelledTotal,
        currentStatus: release.currentStatus
      });
    }
  });
  return Array.from(linesByNumber.values());
}

function isNonCustomerOrder(order: Order) {
  const normalizedCustomer = order.customerName.toLowerCase();
  const normalizedOrderType = order.orderType.toLowerCase();
  return normalizedCustomer.includes('enterprise bulk')
    || normalizedCustomer.includes('enterprise')
    || normalizedOrderType.includes('enterprise')
    || normalizedOrderType.includes('bulk')
    || normalizedOrderType.includes('transfer')
    || normalizedOrderType.includes('replenishment');
}

function dedupeOrdersByOrderNumber(orderList: Order[]) {
  const seen = new Set<string>();
  return orderList.filter((order) => {
    const key = order.orderNumber.trim().toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function formatCurrency(value: number) {
  return value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

function compactDateTime(value?: string) {
  if (!value) return '-';
  const normalizedValue = value.includes(':') ? value : `${value} 00:00 CT`;
  const [datePart, timePart] = normalizedValue.split(' ');
  const compactDate = datePart?.slice(5) || value;
  return timePart ? `${compactDate} ${timePart}` : compactDate;
}

function fullTimestamp(value?: string) {
  if (!value) return '-';
  return value.includes(':') ? value : `${value} 00:00 CT`;
}

function buildExportCsv(exportOrders: Order[]) {
  const header = ['Order ID', 'Banner', 'Customer', 'Email', 'Order Status', 'On Hold', 'Hold Reason', 'Return Order ID', 'Payment Status', 'Order Total', 'Order Line ID', 'Item ID', 'Item Description', 'Line Status', 'Ordered Qty', 'Line Total', 'Release ID', 'Rel Line Id', 'Release Quantity', 'Fulfilled Qty', 'Cancelled Qty', 'Assigned Node', 'Assigned Node Type', 'Release Updated Date', 'Delivery Method', 'Fulfillment ID', 'Fulfillment Type', 'Fulfillment Node Name', 'Fulfillment Status', 'Package ID', 'Package Detail ID', 'Shipment ID', 'Fulfillment Quantity', 'Ship Via', 'Tracking Number'];
  const rows = exportOrders.flatMap((order) => getOrderLines(order).flatMap((line) => {
    const releases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return (releases.length ? releases : [undefined]).flatMap((release) => {
      const fulfillments = release
        ? order.fulfillments.filter((fulfillment) => fulfillment.releaseLineId === release.releaseLineId)
        : [];
      return (fulfillments.length ? fulfillments : [undefined]).map((fulfillment) => [
        order.orderNumber, order.organization, order.customerName, order.customerEmail, order.status,
        order.onHold ? 'Yes' : 'No', order.holdReason ?? '', order.returnOrderId ?? '', order.paymentStatus, order.totalAmount.toFixed(2),
        line.lineNumber, line.sku, line.productName, line.currentStatus, line.orderedQty, line.lineTotal.toFixed(2),
        release?.releaseNumber ?? '', release?.releaseLineId ?? '',
        release?.quantity ?? '', release?.fulfilledQty ?? '',
        release?.cancelledQty ?? '', release?.assignedNode ?? '', release?.assignedNodeType ?? '', release?.updatedDate ?? '',
        release?.fulfillmentMethod ?? '', fulfillment?.fulfillmentId ?? '', fulfillment?.type ?? '',
        fulfillment?.nodeName ?? '', fulfillment?.status ?? '',
        fulfillment?.packageId ?? '', fulfillment?.packageDetailId ?? '', fulfillment?.shipmentId ?? '',
        fulfillment?.quantity ?? '', fulfillment?.shipVia ?? '', fulfillment?.trackingNumber ?? ''
      ]);
    });
  }));
  return [header, ...rows].map((row) => row.map(csvCell).join(',')).join('\n');
}

function OrderSearchProgress({ open, orderCount, population }: { open: boolean; orderCount: number; population: Exclude<OrderPopulation, ''> }) {
  return (
    <Dialog
      open={open}
      maxWidth={false}
      fullWidth
      aria-labelledby="order-search-progress-title"
      PaperProps={{
        sx: {
          width: { xs: 'calc(100vw - 32px)', sm: 560 },
          overflow: 'hidden',
          borderRadius: 3,
          border: 1,
          borderColor: 'rgba(255,255,255,.5)',
          bgcolor: 'background.paper',
          backgroundImage: 'linear-gradient(145deg, rgba(255,255,255,.98), rgba(239,243,248,.96) 48%, rgba(255,255,255,.98))',
          boxShadow: '0 32px 100px rgba(15,23,42,.38), inset 0 1px 0 rgba(255,255,255,.85)'
        }
      }}
      >
      <motion.div initial={{ opacity: 0, scale: 0.98, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 0.25 }}>
        <Box
          sx={{
            px: { xs: 1.75, md: 2.15 },
            py: 1.7,
            color: 'common.white',
            background: 'linear-gradient(120deg, #111827 0%, #2f3b4a 30%, #697586 56%, #8f1f2d 100%)',
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,.24), inset 0 -1px 0 rgba(0,0,0,.28)'
          }}
        >
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.1} justifyContent="space-between" alignItems={{ xs: 'flex-start', sm: 'center' }}>
            <Stack direction="row" spacing={1} alignItems="center">
              <Box sx={{ width: 42, height: 42, borderRadius: 1.6, display: 'grid', placeItems: 'center', bgcolor: 'rgba(255,255,255,.14)', border: '1px solid rgba(255,255,255,.24)', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.28)' }}>
                <SearchIcon fontSize="small" />
              </Box>
              <Box>
                <Typography id="order-search-progress-title" variant="h6" fontWeight={950} sx={{ lineHeight: 1.1 }}>Searching order details</Typography>
                <Typography variant="caption" sx={{ color: 'rgba(255,255,255,.72)' }}>
                  OMS is validating orders, releases, and fulfillment node status.
                </Typography>
              </Box>
            </Stack>
            <Chip
              size="small"
              label={`${population === 'nonCustomer' ? 'Non-customer' : 'Customer'} search · ${orderCount || 'All'} order ID${orderCount === 1 ? '' : 's'}`}
              sx={{ color: 'common.white', borderColor: 'rgba(255,255,255,.26)', bgcolor: 'rgba(255,255,255,.09)', fontWeight: 850 }}
              variant="outlined"
            />
          </Stack>
        </Box>
        <Box sx={{ px: { xs: 1.75, md: 2.15 }, py: 1.75 }}>
          <Stack direction="row" spacing={0.8} flexWrap="wrap" useFlexGap sx={{ mb: 1.45 }}>
            {['Payload validated', 'OMS lookup running', 'Preparing table view'].map((label) => (
              <Chip
                key={label}
                size="small"
                label={label}
                sx={{
                  height: 24,
                  fontWeight: 900,
                  color: '#111827',
                  bgcolor: 'rgba(255,255,255,.86)',
                  border: '1px solid rgba(100,116,139,.22)',
                  boxShadow: '0 6px 16px rgba(15,23,42,.07)'
                }}
              />
            ))}
          </Stack>
          <LinearProgress
            sx={{
              height: 11,
              borderRadius: 999,
              bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
              overflow: 'hidden',
              boxShadow: 'inset 0 1px 2px rgba(15,23,42,.16)',
              '& .MuiLinearProgress-bar': {
                borderRadius: 999,
                background: 'linear-gradient(90deg, #d71920 0%, #f4b43f 42%, #117c8b 72%, #1769e0 100%)'
              }
            }}
          />
          <Typography variant="caption" color="text.secondary" fontWeight={850} sx={{ display: 'block', mt: 1.15 }}>
            Validating request payload and fetching backend response
          </Typography>
        </Box>
      </motion.div>
    </Dialog>
  );
}

export default function OrderTracking() {
  const [searchedOrders, setSearchedOrders] = useState<Order[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<Error>();
  const [orderPopulation, setOrderPopulation] = useState<OrderPopulation>('');
  const [orderNumbers, setOrderNumbers] = useState('');
  const [sku, setSku] = useState('');
  const [statuses, setStatuses] = useState<OrderStatus[]>([]);
  const [businessOrderType, setBusinessOrderType] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [fulfillmentType, setFulfillmentType] = useState('');
  const [banner, setBanner] = useState('');
  const [searched, setSearched] = useState(false);
  const [submittedCriteria, setSubmittedCriteria] = useState<SubmittedSearchCriteria | null>(null);
  const [resultSearch, setResultSearch] = useState('');
  const [page, setPage] = useState(1);
  const [exportNotice, setExportNotice] = useState(false);
  const orders = searched ? searchedOrders : [];

  const orderNumberList = useMemo(
    () => orderNumbers.split(/\n|,|\s/).map((value) => value.trim()).filter(Boolean),
    [orderNumbers]
  );
  const maxSearchOrderNumbers = orderPopulation === 'nonCustomer' ? 100 : 400;
  const hasTooManyOrders = orderNumberList.length > maxSearchOrderNumbers;
  const hasNoOrderNumbers = orderNumberList.length === 0;

  const filteredOrders = useMemo(() => {
    if (!searched || !submittedCriteria) return [];
    const query = resultSearch.trim().toLowerCase();

    return orders
      .filter((order) => submittedCriteria.orderPopulation === 'nonCustomer' ? isNonCustomerOrder(order) : !isNonCustomerOrder(order))
      .filter((order) => !submittedCriteria.orderNumbers.length || submittedCriteria.orderNumbers.includes(order.orderNumber))
      .filter((order) => !submittedCriteria.sku || order.releases.some((release) => release.sku.toLowerCase().includes(submittedCriteria.sku.toLowerCase())))
      .filter((order) => !submittedCriteria.statuses.length || submittedCriteria.statuses.includes(order.status))
      .filter((order) => !submittedCriteria.businessOrderType || order.orderType === submittedCriteria.businessOrderType)
      .filter((order) => !submittedCriteria.fromDate || order.orderDate >= submittedCriteria.fromDate)
      .filter((order) => !submittedCriteria.toDate || order.orderDate <= submittedCriteria.toDate)
      .filter((order) => !submittedCriteria.fulfillmentType || order.fulfillmentType === submittedCriteria.fulfillmentType)
      .filter((order) => !submittedCriteria.banner || order.organization === submittedCriteria.banner)
      .filter((order) => {
        if (!query) return true;
        const haystack = [
          order.orderNumber,
          order.customerName,
          order.customerEmail,
          order.status,
          order.organization,
          order.onHold ? 'on hold' : '',
          order.holdReason ?? '',
          order.returnOrderId ?? '',
          order.fulfillmentTypeSummary,
          ...order.releases.map((release) => `${release.lineNumber} ${release.sku} ${release.productName} ${release.currentStatus}`),
          ...order.releases.map((release) => `${release.releaseNumber} ${release.releaseLineId} ${release.assignedNode} ${release.assignedNodeType}`),
          ...order.fulfillments.map((fulfillment) => `${fulfillment.fulfillmentId} ${fulfillment.type} ${fulfillment.nodeName} ${fulfillment.packageId} ${fulfillment.shipmentId} ${fulfillment.trackingNumber}`),
          ...order.communications.map((communication) => `${communication.channel} ${communication.agent} ${communication.direction} ${communication.summary} ${communication.caseId}`)
        ].join(' ').toLowerCase();
        return haystack.includes(query);
      });
  }, [orders, resultSearch, searched, submittedCriteria]);

  const isNonCustomerMode = submittedCriteria?.orderPopulation === 'nonCustomer';
  const exportHref = useMemo(
    () => filteredOrders.length ? `data:text/csv;charset=utf-8,${encodeURIComponent(buildExportCsv(filteredOrders))}` : undefined,
    [filteredOrders]
  );

  const handleReset = () => {
    setOrderPopulation('');
    setOrderNumbers('');
    setSku('');
    setStatuses([]);
    setBusinessOrderType('');
    setFromDate('');
    setToDate('');
    setFulfillmentType('');
    setBanner('');
    setSearched(false);
    setSubmittedCriteria(null);
    setSearchedOrders([]);
    setSearchError(undefined);
    setResultSearch('');
    setPage(1);
  };

  const handleSearch = async () => {
    if (!orderPopulation || hasNoOrderNumbers || hasTooManyOrders) return;
    const nextCriteria = {
      orderPopulation,
      orderNumbers: orderNumberList,
      sku,
      statuses,
      businessOrderType,
      fromDate,
      toDate,
      fulfillmentType,
      banner
    };
    setSearched(false);
    setSubmittedCriteria(null);
    setSearchedOrders([]);
    setResultSearch('');
    setPage(1);
    setSearchLoading(true);
    setSearchError(undefined);
    try {
      const response = await omsApi.getOrders(undefined, {
        page: 1,
        pageSize: orderPopulation === 'nonCustomer' ? 100 : 1000,
        orderType: orderPopulation,
        orderNumbers: orderNumberList,
        sku,
        statuses,
        orderDateFrom: fromDate,
        orderDateTo: toDate,
        fulfillmentType,
        banner
      });
      setSearchedOrders(dedupeOrdersByOrderNumber(response.items));
      setSubmittedCriteria(nextCriteria);
      setSearched(true);
      setResultSearch('');
      setPage(1);
    } catch (requestError) {
      setSearchError(requestError instanceof Error ? requestError : new Error('Unable to search orders'));
    } finally {
      setSearchLoading(false);
    }
  };

  return (
    <Box
      className="order-live-tracking-page"
      sx={{
        fontSize: 'clamp(.9rem, .82rem + .18vw, 1.02rem)',
        '& .MuiTypography-caption': { fontSize: 'clamp(.73rem, .67rem + .13vw, .83rem)' },
        '& .MuiTypography-body2': { fontSize: 'clamp(.84rem, .76rem + .16vw, .96rem)' },
        '& .MuiTypography-subtitle2': { fontSize: 'clamp(.94rem, .84rem + .18vw, 1.04rem)' },
        '& .MuiTypography-subtitle1': { fontSize: 'clamp(1rem, .91rem + .18vw, 1.12rem)' },
        '& .MuiInputBase-input, & .MuiSelect-select': { fontSize: 'clamp(.84rem, .76rem + .15vw, .96rem)' },
        '& .MuiInputLabel-root': { fontSize: 'clamp(.81rem, .73rem + .15vw, .93rem)' },
        '& .MuiButton-root': { fontSize: 'clamp(.79rem, .73rem + .12vw, .91rem)' },
        '& .MuiChip-label': { fontSize: 'clamp(.69rem, .63rem + .12vw, .79rem)' },
        '& .MuiTableCell-root': { fontSize: 'clamp(.76rem, .7rem + .12vw, .88rem)' },
        '& .MuiTableHead-root .MuiTableCell-root': { fontSize: 'clamp(.75rem, .69rem + .11vw, .86rem)' },
        '@media (max-width:1180px)': {
          '& .MuiCard-root, & .MuiAccordion-root': { borderRadius: 1.5 },
          '& .MuiButton-root': { minHeight: 30, px: 1 },
          '& .MuiChip-root': { height: 20 },
          '& .MuiTableCell-root': { px: 0.55, py: 0.5 }
        }
      }}
    >
      <PageHeader
        title="Order Live Tracking"
        subtitle="Search, trace, and inspect order journeys across every Foot Locker fulfillment channel."
        badge="Live Operations"
      />

      {searchError && <ApiErrorState message={searchError.message} onRetry={handleSearch} />}
      {orderPopulation && <OrderSearchProgress open={searchLoading} orderCount={orderNumberList.length} population={orderPopulation} />}

      <GlassCard sx={{ p: 0, mb: { xs: 1.5, md: 1.8 }, overflow: 'hidden', bgcolor: 'transparent' }}>
        <Box sx={{ px: { xs: 1.5, md: 2.25 }, py: { xs: 1.35, md: 1.55 }, background: 'linear-gradient(115deg, #151b23 0%, #414a55 34%, #252c35 68%, #4d262a 100%)', color: 'common.white', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.18), inset 0 -1px 0 rgba(0,0,0,.32)' }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={1}>
            <Box>
              <Stack direction="row" spacing={0.75} alignItems="center">
                <TuneIcon fontSize="small" />
                <Typography variant="subtitle1" fontWeight={950}>Search Criteria</Typography>
              </Stack>
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,.68)', mt: 0.25, display: 'block' }}>
                Customer order searches allow up to 400 IDs. Non-customer order searches allow up to 100 IDs.
              </Typography>
            </Box>
            <Chip size="small" label={`${orderNumberList.length} / ${maxSearchOrderNumbers} orders`} color={hasTooManyOrders ? 'error' : 'default'} sx={{ color: 'common.white', borderColor: 'rgba(255,255,255,.25)', bgcolor: 'rgba(255,255,255,.08)' }} variant="outlined" />
          </Stack>
        </Box>

        <Box sx={{ p: { xs: 1.5, md: 2 }, background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(145deg, rgba(252,253,254,.92), rgba(224,228,233,.82))' : 'linear-gradient(145deg, rgba(34,40,49,.9), rgba(21,26,34,.9))' }}>
          <Grid container spacing={{ xs: 1.15, md: 1.35 }} alignItems="stretch">
            <Grid item xs={12} md={4}>
              <Box
                sx={{
                  height: '100%',
                  p: { xs: 1.15, md: 1.35 },
                  border: 1,
                  borderColor: orderPopulation ? (theme) => alpha(theme.palette.primary.main, 0.26) : 'warning.light',
                  borderRadius: 2,
                  background: (theme) => theme.palette.mode === 'light'
                    ? `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.07)}, rgba(255,255,255,.88) 58%, ${alpha(theme.palette.secondary.main, 0.08)})`
                    : `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.15)}, rgba(22,27,35,.92) 62%, ${alpha(theme.palette.secondary.main, 0.12)})`,
                  boxShadow: 'inset 0 1px 0 rgba(255,255,255,.38)'
                }}
              >
                <Typography variant="subtitle2" fontWeight={950}>
                  Search Order Type <Box component="span" color="error.main">*</Box>
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.8 }}>
                  Select the population before entering order IDs.
                </Typography>
                <RadioGroup
                  value={orderPopulation}
                  onChange={(event) => {
                    setOrderPopulation(event.target.value as OrderPopulation);
                    setSearched(false);
                    setSubmittedCriteria(null);
                    setSearchedOrders([]);
                    setSearchError(undefined);
                    setResultSearch('');
                    setPage(1);
                  }}
                  sx={{
                    gap: 0.75,
                    '& .MuiFormControlLabel-root': {
                      m: 0,
                      px: 1.15,
                      py: 0.45,
                      border: 1,
                      borderColor: 'divider',
                      borderRadius: 1.5,
                      bgcolor: (theme) => alpha(theme.palette.background.paper, 0.76),
                      boxShadow: '0 5px 14px rgba(15,23,42,.05)'
                    },
                    '& .MuiFormControlLabel-label': {
                      fontSize: 'clamp(.76rem, .7rem + .14vw, .9rem)',
                      fontWeight: 900
                    }
                  }}
                >
                  <FormControlLabel value="customer" control={<Radio size="small" />} label="Customer Orders" />
                  <FormControlLabel value="nonCustomer" control={<Radio size="small" />} label="Non-Customer / Bulk Orders" />
                </RadioGroup>
                {!orderPopulation && (
                  <Typography variant="caption" color="warning.dark" fontWeight={800} sx={{ display: 'block', mt: 0.7 }}>
                    Required before search.
                  </Typography>
                )}
              </Box>
            </Grid>
            <Grid item xs={12} md={8}>
              <TextField
                label="Order Numbers"
                size="small"
                multiline
                minRows={4}
                maxRows={4}
                fullWidth
                value={orderNumbers}
                onChange={(event) => setOrderNumbers(event.target.value)}
                error={hasTooManyOrders}
                helperText={hasTooManyOrders ? `Maximum ${maxSearchOrderNumbers} order numbers allowed for ${orderPopulation === 'nonCustomer' ? 'non-customer' : 'customer'} order search.` : hasNoOrderNumbers ? 'Enter at least one order number to search.' : `Paste one or multiple order IDs, separated by a line break, comma, or space. Current limit: ${maxSearchOrderNumbers} ${orderPopulation === 'nonCustomer' ? 'non-customer' : 'customer'} order IDs.`}
                placeholder={'FL-10048291\nFL-10048307\nFL-10048355'}
                InputProps={{ sx: { height: '100%', alignItems: 'flex-start', bgcolor: (theme) => alpha(theme.palette.background.default, 0.58), '& textarea': { overflowY: 'auto !important', resize: 'none' } } }}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: { xs: 1.4, md: 1.65 } }}>
            <Chip icon={<TuneIcon />} label="Refine results" size="small" />
          </Divider>

          <Grid container spacing={{ xs: 1.15, md: 1.35 }}>
            <Grid item xs={12} md={5} lg={4}>
              <TextField size="small" label="Single SKU Search" fullWidth value={sku} onChange={(event) => setSku(event.target.value)} placeholder="HF2903-100" />
            </Grid>
            <Grid item xs={12} md={7} lg={5}>
              <FormControl fullWidth size="small">
                <InputLabel>Order Status</InputLabel>
                <Select
                  multiple
                  value={statuses}
                  input={<OutlinedInput label="Order Status" />}
                  renderValue={(selected) => selected.join(', ')}
                  onChange={(event) => setStatuses(event.target.value as OrderStatus[])}
                >
                  {orderStatuses.map((status) => (
                    <MenuItem key={status} value={status}>
                      <Checkbox checked={statuses.includes(status)} />
                      <ListItemText primary={status} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} lg={3}>
              <TextField size="small" select label="Order Type" fullWidth value={businessOrderType} onChange={(event) => setBusinessOrderType(event.target.value)}>
                <MenuItem value="">All Order Types</MenuItem>
                {businessOrderTypes.map((type) => <MenuItem key={type} value={type}>{type}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6} lg={3}>
              <TextField size="small" label="Order Date From" type="date" fullWidth value={fromDate} onChange={(event) => setFromDate(event.target.value)} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid item xs={12} sm={6} lg={3}>
              <TextField size="small" label="Order Date To" type="date" fullWidth value={toDate} onChange={(event) => setToDate(event.target.value)} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid item xs={12} sm={6} lg={3}>
              <TextField size="small" select label="Fulfillment Type" fullWidth value={fulfillmentType} onChange={(event) => setFulfillmentType(event.target.value)}>
                <MenuItem value="">All</MenuItem>
                {fulfillmentTypes.map((type) => <MenuItem key={type} value={type}>{type}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6} lg={3}>
              <TextField size="small" select label="Banner" fullWidth value={banner} onChange={(event) => setBanner(event.target.value)}>
                <MenuItem value="">All Banners</MenuItem>
                {banners.map((value) => <MenuItem key={value} value={value}>{value}</MenuItem>)}
              </TextField>
            </Grid>
          </Grid>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="flex-end" sx={{ mt: { xs: 1.4, md: 1.65 }, pt: { xs: 1.1, md: 1.25 }, borderTop: 1, borderColor: 'divider' }}>
            <Button startIcon={<RestartAltIcon />} variant="text" onClick={handleReset}>Reset</Button>
            <Button
              component="a"
              href={exportHref}
              download={`foot-locker-orders-${new Date().toISOString().slice(0, 10)}.csv`}
              startIcon={<FileDownloadIcon />}
              variant="outlined"
              disabled={!filteredOrders.length}
              onClick={() => setExportNotice(true)}
            >
              Export Results
            </Button>
            <Button startIcon={<SearchIcon />} disabled={!orderPopulation || hasNoOrderNumbers || hasTooManyOrders || searchLoading} variant="contained" onClick={handleSearch}>Search Orders</Button>
          </Stack>
        </Box>
      </GlassCard>

      {searched && (
        <OrderSearchResultsTable
          orders={filteredOrders}
          globalSearch={resultSearch}
          onGlobalSearch={(value) => {
            setResultSearch(value);
            setPage(1);
          }}
          page={page}
          pageSize={pageSize}
          onPageChange={setPage}
          population={isNonCustomerMode ? 'nonCustomer' : 'customer'}
        />
      )}

      <Snackbar open={exportNotice} autoHideDuration={3200} onClose={() => setExportNotice(false)} message={`Exported ${filteredOrders.length} orders to CSV`} />
    </Box>
  );
}

function OrderHeader({ order, accent }: { order: Order; accent: string }) {
  return (
    <Box sx={{ width: '100%', p: { xs: 0.85, md: 0.95 }, background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(112deg, ${alpha(accent, 0.14)} 0%, rgba(232,235,239,.94) 34%, rgba(250,251,252,.96) 68%, ${alpha(theme.palette.secondary.main, 0.1)} 100%)` : `linear-gradient(112deg, ${alpha(accent, 0.18)} 0%, rgba(38,44,54,.95) 42%, rgba(24,29,37,.96) 100%)`, boxShadow: 'inset 0 1px 0 rgba(255,255,255,.42)' }}>
      <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" gap={0.75} alignItems={{ md: 'center' }}>
        <Box sx={{ minWidth: 0 }}>
          <Stack direction="row" spacing={0.65} alignItems="center" flexWrap="wrap" useFlexGap>
            <ConfirmationNumberIcon sx={{ color: accent, fontSize: 17 }} />
            <Typography variant="subtitle1" fontWeight={950} sx={{ fontSize: 'clamp(.82rem, .72rem + .3vw, .98rem)' }}>{order.orderNumber}</Typography>
            <StatusChip label={order.status} sx={{ height: 21, '& .MuiChip-label': { px: 0.75, fontSize: '0.64rem' } }} />
            <PaymentStatusChip status={order.paymentStatus} />
            {order.onHold && <Chip size="small" icon={<PauseCircleFilledIcon />} label="On Hold" color="warning" sx={{ height: 21, '& .MuiChip-label': { px: 0.75, fontSize: '0.64rem' } }} />}
          </Stack>
        </Box>
        <Grid container spacing={0.55} sx={{ maxWidth: { md: 380, lg: 470 } }}>
          <HeaderMetric icon={<CalendarMonthIcon fontSize="small" />} label="Created" value={order.orderDate} accent={accent} />
          <HeaderMetric icon={<CreditCardIcon fontSize="small" />} label="Order Total" value={`$${order.totalAmount.toFixed(2)}`} accent={accent} />
        </Grid>
      </Stack>
    </Box>
  );
}

function HeaderMetric({ icon, label, value, accent }: { icon: ReactNode; label: string; value: string; accent: string }) {
  return (
    <Grid item xs={6}>
      <Stack direction="row" spacing={0.5} alignItems="center" sx={{ px: { xs: 0.5, sm: 0.65 }, py: 0.15, minHeight: 30, border: 1, borderColor: 'divider', borderRadius: 1.1, background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(180deg, rgba(255,255,255,.92), rgba(219,224,229,.88))' : 'linear-gradient(180deg, rgba(49,56,67,.86), rgba(28,33,42,.9))', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.42), 0 1px 2px rgba(31,38,47,.08)' }}>
        <Box sx={{ color: accent, display: { xs: 'none', sm: 'flex' }, '& svg': { fontSize: 16 } }}>{icon}</Box>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontSize: 'clamp(.55rem, .5rem + .12vw, .62rem)', lineHeight: 1 }}>
            <Box component="span" sx={{ display: { xs: 'none', sm: 'inline' } }}>{label}</Box>
            <Box component="span" sx={{ display: { xs: 'inline', sm: 'none' } }}>{label === 'Order Status' ? 'Status' : label === 'Order Total' ? 'Total' : label}</Box>
          </Typography>
          <Typography variant="body2" fontWeight={900} fontSize={{ xs: label === 'Created' ? '0.58rem' : '0.66rem', sm: 'clamp(.66rem, .58rem + .16vw, .73rem)' }} lineHeight={1.12} noWrap>{value}</Typography>
        </Box>
      </Stack>
    </Grid>
  );
}

function PaymentStatusChip({ status }: { status: string }) {
  const color = status === 'Captured' ? 'success' : status === 'Refunded' ? 'warning' : 'info';
  return <Chip size="small" icon={<CreditCardIcon />} label={status} color={color} variant="outlined" sx={{ height: 21, '& .MuiChip-label': { px: 0.75, fontSize: '0.64rem' }, '& .MuiChip-icon': { fontSize: 14 } }} />;
}

function formatAddress(address: Order['shippingAddress']) {
  if (!address) return '';
  return [
    address.line1,
    address.line2,
    `${address.city}, ${address.state} ${address.postalCode}`,
    address.country
  ].filter(Boolean).join(', ');
}

function fallbackAddress(order: Order, type: 'shipping' | 'billing') {
  const numericSeed = Number(order.customerId.replace(/\D/g, '').slice(-4)) || 1420;
  const streetNumber = 100 + (numericSeed % 8900);
  const billingStreetNumber = streetNumber + 18;
  const cityByBanner: Record<string, [string, string, string]> = {
    'FL-US': ['New York', 'NY', '10001'],
    'CH-US': ['Bradenton', 'FL', '34205'],
    'KFL-US': ['Chicago', 'IL', '60605'],
    'FL-CA': ['Toronto', 'ON', 'M5B 2H1'],
    'CH-CA': ['Toronto', 'ON', 'M5B 2H1']
  };
  const [city, state, postalCode] = cityByBanner[order.organization] ?? ['New York', 'NY', '10001'];
  const streetName = type === 'shipping' ? 'Fulfillment Ave' : 'Billing Center Dr';
  return `${type === 'shipping' ? streetNumber : billingStreetNumber} ${streetName}, ${city}, ${state} ${postalCode}, ${order.organization.endsWith('-CA') ? 'CA' : 'US'}`;
}

function OrderInformation({ order }: { order: Order }) {
  const [communicationOpen, setCommunicationOpen] = useState(false);
  const [detailsExpanded, setDetailsExpanded] = useState(true);
  const fulfillmentTypeDisplay = order.fulfillmentType?.trim() || 'WIP';
  const fulfillmentSummaryDisplay = order.fulfillmentTypeSummary?.trim() || 'WIP';
  const details: Array<{ label: string; value: string; icon: ReactNode; md?: number }> = [
    { label: 'Banner', value: order.organization || '', icon: <ConfirmationNumberIcon /> },
    { label: 'Order Type', value: order.orderType || '', icon: <ReceiptLongOutlinedIcon /> },
    { label: 'Fulfillment Type', value: fulfillmentTypeDisplay, icon: <WarehouseIcon /> },
    { label: 'Return Order ID', value: order.returnOrderId || '', icon: <AssignmentReturnIcon /> },
    { label: 'Fulfillment Summary', value: fulfillmentSummaryDisplay, icon: <LocalShippingIcon />, md: 6 },
    { label: 'Hold Reason', value: order.holdReason || '', icon: <PauseCircleFilledIcon />, md: 6 },
    { label: 'Customer Name', value: order.customerName || '', icon: <PersonOutlineIcon /> },
    { label: 'Customer ID', value: order.customerId || '', icon: <PersonOutlineIcon /> },
    { label: 'Customer Email', value: order.customerEmail || '', icon: <EmailOutlinedIcon /> },
    { label: 'Shipping Address', value: formatAddress(order.shippingAddress) || fallbackAddress(order, 'shipping'), icon: <LocalShippingIcon />, md: 6 },
    { label: 'Billing Address', value: formatAddress(order.billingAddress) || fallbackAddress(order, 'billing'), icon: <CreditCardIcon />, md: 6 }
  ];
  return (
    <Box
      className="order-information-panel"
      sx={{
        mb: 2.5,
        overflow: 'hidden',
        border: 1,
        borderLeft: '4px solid',
        borderColor: (theme) => alpha(theme.palette.secondary.main, 0.28),
        borderLeftColor: 'secondary.main',
        borderRadius: 2,
        color: 'text.primary',
        background: (theme) => `linear-gradient(115deg, ${alpha(theme.palette.info.main, 0.055)}, ${alpha(theme.palette.secondary.main, 0.075)} 56%, ${alpha(theme.palette.background.paper, 0.72)})`,
        boxShadow: '0 8px 24px rgba(31,41,55,.07)'
      }}
    >
      <Box sx={{ px: 1.6, py: 0.95, borderBottom: detailsExpanded ? 1 : 0, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.secondary.main, 0.065) }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between">
          <Stack direction="row" spacing={1} alignItems="center">
            <ReceiptLongOutlinedIcon sx={{ color: 'secondary.main', fontSize: 20 }} />
            <Typography variant="subtitle1" fontWeight={900}>Additional Order Details</Typography>
            <Chip size="small" label={detailsExpanded ? 'Expanded' : 'Collapsed'} variant="outlined" sx={{ fontWeight: 850 }} />
          </Stack>
          <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
            <Button
              size="small"
              variant="outlined"
              endIcon={<ExpandMoreIcon sx={{ transform: detailsExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 180ms ease' }} />}
              onClick={() => setDetailsExpanded((current) => !current)}
              sx={{ minHeight: 28, borderRadius: 1.5, fontWeight: 900 }}
            >
              {detailsExpanded ? 'Collapse' : 'Expand'}
            </Button>
            <Button
              className="communication-notes-link"
              size="small"
              variant="text"
              startIcon={<ChatBubbleOutlineIcon />}
              onClick={() => setCommunicationOpen(true)}
              sx={{ px: 0.5, textDecoration: 'underline', textUnderlineOffset: 3 }}
            >
              Communication Notes ({order.communications.length})
            </Button>
          </Stack>
        </Stack>
      </Box>
      <Collapse in={detailsExpanded} timeout={240} unmountOnExit>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: {
              xs: 'repeat(2, minmax(0, 1fr))',
              md: 'repeat(3, minmax(0, 1fr))',
              xl: 'repeat(4, minmax(0, 1fr))'
            },
            gap: 0.65,
            p: 0.8
          }}
        >
          {details.map(({ label, value, icon, md = 4 }) => (
            <Box key={label} sx={{ gridColumn: { xs: label.includes('Address') ? 'span 2' : 'span 1', md: md >= 6 ? 'span 2' : 'span 1', xl: label.includes('Address') ? 'span 2' : md >= 6 ? 'span 2' : 'span 1' } }}>
              <Stack direction="row" spacing={0.85} alignItems="center" sx={{ height: '100%', px: 1.05, py: 0.52, minHeight: 44, border: 1, borderColor: (theme) => alpha(theme.palette.divider, 0.95), borderRadius: 1.2, bgcolor: 'background.paper', boxShadow: 'inset 0 1px 0 rgba(255,255,255,.5)' }}>
                <Box sx={{ width: 24, height: 24, borderRadius: 1, flex: '0 0 auto', display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.085), '& svg': { fontSize: 14 } }}>{icon}</Box>
                <Box sx={{ minWidth: 0 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.05 }}>{label}</Typography>
                  <Typography variant="body2" fontWeight={800} sx={{ mt: 0.1, lineHeight: 1.16, minHeight: '1.16em', overflowWrap: 'anywhere' }}>{value}</Typography>
                </Box>
              </Stack>
            </Box>
          ))}
        </Box>
      </Collapse>
      <Dialog
        open={communicationOpen}
        onClose={() => setCommunicationOpen(false)}
        maxWidth="md"
        fullWidth
        aria-labelledby={`communication-title-${order.orderNumber}`}
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', md: 820 },
            maxHeight: 'min(72vh, 620px)',
            borderRadius: 2.25,
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle id={`communication-title-${order.orderNumber}`} sx={{ pr: 6.5, px: 2.1, py: 1.6 }}>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <Box sx={{ width: 34, height: 34, borderRadius: 1.35, display: 'grid', placeItems: 'center', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}>
              <SupportAgentIcon fontSize="small" />
            </Box>
            <Box>
              <Typography variant="subtitle1" fontWeight={950}>Customer Communication History</Typography>
              <Typography variant="body2" color="text.secondary">{order.orderNumber} · {order.customerName}</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close communication notes" onClick={() => setCommunicationOpen(false)} sx={{ position: 'absolute', right: 14, top: 14 }}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0, maxHeight: 'calc(min(72vh, 620px) - 84px)' }}>
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 760, '& .MuiTableCell-root': { px: 1, py: 0.72, fontSize: '0.78rem' } }}>
              <TableHead sx={{ bgcolor: (theme) => alpha(theme.palette.info.main, 0.06) }}>
                <TableRow>
                  {['Date / Time', 'Channel', 'Direction', 'Helpdesk Agent', 'Case ID', 'Communication Summary'].map((label) => <TableCell key={label}>{label}</TableCell>)}
                </TableRow>
              </TableHead>
              <TableBody>
                {order.communications.map((communication) => (
                  <TableRow key={`${communication.caseId}-${communication.dateTime}`} hover>
                    <TableCell sx={{ whiteSpace: 'nowrap', fontWeight: 700 }}>{communication.dateTime}</TableCell>
                    <TableCell><Chip size="small" label={communication.channel} variant="outlined" /></TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        label={communication.direction}
                        color={communication.direction === 'Inbound' ? 'info' : communication.direction === 'Outbound' ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>{communication.agent}</TableCell>
                    <TableCell sx={{ fontWeight: 800, color: 'info.main', whiteSpace: 'nowrap' }}>{communication.caseId}</TableCell>
                    <TableCell sx={{ minWidth: 220, maxWidth: 320, whiteSpace: 'normal', lineHeight: 1.35 }}>{communication.summary}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

type ReleaseTableRow = { id: string; line: OrderLine; release?: Release; orderNumber?: string };
type ReleaseSortKey = 'lineNumber' | 'sku' | 'productName' | 'lineStatus' | 'orderedQty' | 'lineTotal' | 'releaseNumber' | 'releaseLineId' | 'quantity' | 'fulfilledQty' | 'cancelledQty' | 'assignedNode' | 'assignedNodeType' | 'releaseDate' | 'updatedDate' | 'fulfillmentMethod';
type SortDirection = 'asc' | 'desc';
type FulfillmentSortKey = 'releaseNumber' | 'releaseLineId' | 'nodeName' | 'type' | 'packageId' | 'packageDetailId' | 'shipmentId' | 'orderedQty' | 'shippedQty' | 'cancelledQty' | 'status' | 'shipVia' | 'trackingNumber' | 'createdDate' | 'updatedDate';
type OrderResultColumnKey = 'orderNumber' | 'paymentStatus' | 'status' | 'holdStatus' | 'orderDate' | 'totalAmount' | 'organization' | 'orderType';

function parseColumnTerms(value: string) {
  return value
    .split(/\n|,/)
    .map((term) => term.trim().toLowerCase())
    .filter(Boolean);
}

function getHoldStatus(order: Order) {
  return order.onHold ? 'On Hold' : 'Clear';
}

function getOrderResultValue(order: Order, key: OrderResultColumnKey) {
  const values: Record<OrderResultColumnKey, string | number> = {
    orderNumber: order.orderNumber,
    paymentStatus: order.paymentStatus,
    status: order.status,
    holdStatus: getHoldStatus(order),
    orderDate: order.orderDate,
    totalAmount: order.totalAmount,
    organization: order.organization,
    orderType: order.orderType
  };
  return values[key];
}

function orderSearchHaystack(order: Order) {
  return [
    order.orderNumber,
    order.paymentStatus,
    order.status,
    getHoldStatus(order),
    order.holdReason ?? '',
    order.orderDate,
    order.totalAmount,
    order.organization,
    order.orderType,
    order.customerName,
    order.customerEmail,
    order.fulfillmentType,
    order.fulfillmentTypeSummary,
    ...order.releases.map((release) => `${release.releaseNumber} ${release.releaseLineId} ${release.sku} ${release.productName} ${release.assignedNode} ${release.assignedNodeType}`),
    ...order.fulfillments.map((fulfillment) => `${fulfillment.fulfillmentId} ${fulfillment.releaseNumber} ${fulfillment.nodeName} ${fulfillment.type} ${fulfillment.status} ${fulfillment.trackingNumber}`)
  ].join(' ').toLowerCase();
}

function getReleaseSortValue(row: ReleaseTableRow, sortKey: ReleaseSortKey) {
  const values: Record<ReleaseSortKey, string | number> = {
    lineNumber: row.line.lineNumber,
    sku: row.line.sku,
    productName: row.line.productName,
    lineStatus: row.line.currentStatus,
    orderedQty: row.line.orderedQty,
    lineTotal: row.line.lineTotal,
    releaseNumber: row.release?.releaseNumber ?? '',
    releaseLineId: row.release?.releaseLineId ?? '',
    quantity: row.release?.quantity ?? 0,
    fulfilledQty: row.release?.fulfilledQty ?? 0,
    cancelledQty: row.release?.cancelledQty ?? 0,
    assignedNode: row.release?.assignedNode ?? '',
    assignedNodeType: row.release?.assignedNodeType ?? '',
    releaseDate: row.release?.releaseDate ?? '',
    updatedDate: row.release?.updatedDate ?? '',
    fulfillmentMethod: row.release?.fulfillmentMethod ?? ''
  };
  return values[sortKey];
}

function getFulfillmentSortValue(row: Fulfillment, sortKey: FulfillmentSortKey) {
  const values: Record<FulfillmentSortKey, string | number> = {
    releaseNumber: row.releaseNumber,
    releaseLineId: row.releaseLineId,
    nodeName: row.nodeName,
    type: row.type,
    packageId: row.packageId,
    packageDetailId: row.packageDetailId,
    shipmentId: row.shipmentId,
    orderedQty: row.quantity,
    shippedQty: 0,
    cancelledQty: 0,
    status: row.status,
    shipVia: row.shipVia,
    trackingNumber: row.trackingNumber,
    createdDate: row.createdDate ?? '',
    updatedDate: row.updatedDate ?? ''
  };
  return values[sortKey];
}

function getFulfillmentShippedQty(row: Fulfillment, releases: Release[]) {
  return releases.find((release) => release.releaseLineId === row.releaseLineId)?.fulfilledQty ?? (row.status === 'Shipped' || row.status === 'Delivered' || row.status === 'In Transit' ? row.quantity : 0);
}

function getFulfillmentCancelledQty(row: Fulfillment, releases: Release[]) {
  return releases.find((release) => release.releaseLineId === row.releaseLineId)?.cancelledQty ?? (row.status.toLowerCase().includes('cancel') ? row.quantity : 0);
}

function getFulfillmentTypeColor(type: Fulfillment['type']) {
  if (type === 'Warehouse') return '#0d6470';
  if (type === 'Supplier') return '#6d3fb8';
  if (type === 'Dropship') return '#b45309';
  return '#1769e0';
}

function getFulfillmentStatusStyle(status: string) {
  const normalizedStatus = status.toLowerCase();
  if (normalizedStatus.includes('cancel')) return { bg: '#fee2e2', fg: '#991b1b', border: '#ef4444' };
  if (normalizedStatus.includes('delivered')) return { bg: '#dcfce7', fg: '#166534', border: '#22c55e' };
  if (normalizedStatus.includes('transit') || normalizedStatus.includes('shipped')) return { bg: '#d1fae5', fg: '#047857', border: '#10b981' };
  if (normalizedStatus.includes('ready')) return { bg: '#ccfbf1', fg: '#0f766e', border: '#14b8a6' };
  if (normalizedStatus.includes('packed')) return { bg: '#ede9fe', fg: '#5b21b6', border: '#8b5cf6' };
  if (normalizedStatus.includes('picked') || normalizedStatus.includes('pick')) return { bg: '#e0f2fe', fg: '#075985', border: '#0ea5e9' };
  if (normalizedStatus.includes('manifest')) return { bg: '#dbeafe', fg: '#1d4ed8', border: '#3b82f6' };
  if (normalizedStatus.includes('label')) return { bg: '#fef3c7', fg: '#92400e', border: '#f59e0b' };
  if (normalizedStatus.includes('awaiting') || normalizedStatus.includes('backorder')) return { bg: '#ffedd5', fg: '#9a3412', border: '#f97316' };
  if (normalizedStatus.includes('return')) return { bg: '#f3e8ff', fg: '#7e22ce', border: '#a855f7' };
  if (normalizedStatus.includes('release') || normalizedStatus.includes('open') || normalizedStatus.includes('schedule')) return { bg: '#e0f2fe', fg: '#0369a1', border: '#38bdf8' };
  return { bg: '#f1f5f9', fg: '#334155', border: '#94a3b8' };
}

function OrderSearchResultsTable({
  orders,
  globalSearch,
  onGlobalSearch,
  page,
  pageSize,
  onPageChange,
  population
}: {
  orders: Order[];
  globalSearch: string;
  onGlobalSearch: (value: string) => void;
  page: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  population: Exclude<OrderPopulation, ''>;
}) {
  const [sortKey, setSortKey] = useState<OrderResultColumnKey>('orderDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [columnFilters, setColumnFilters] = useState<Record<OrderResultColumnKey, string>>({
    orderNumber: '',
    paymentStatus: '',
    status: '',
    holdStatus: '',
    orderDate: '',
    totalAmount: '',
    organization: '',
    orderType: ''
  });
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const columns: Array<{ key: OrderResultColumnKey; label: string; width: number; placeholder: string }> = [
    { key: 'orderNumber', label: 'Order Number', width: 148, placeholder: 'FL-100, FL-101' },
    { key: 'orderType', label: 'Order Type', width: 132, placeholder: 'Web, Launch' },
    { key: 'status', label: 'Order Status', width: 142, placeholder: 'Open, Released' },
    { key: 'organization', label: 'Banner', width: 104, placeholder: 'FL-US, CH-US' },
    { key: 'paymentStatus', label: 'Payment Status', width: 132, placeholder: 'Captured, Refunded' },
    { key: 'holdStatus', label: 'Hold Status', width: 116, placeholder: 'On Hold, Clear' },
    { key: 'orderDate', label: 'Created Date', width: 124, placeholder: '2026-06-24' },
    { key: 'totalAmount', label: 'Order Total', width: 112, placeholder: '199.99' }
  ];

  const tableRows = useMemo(() => {
    const query = globalSearch.trim().toLowerCase();
    return Array.from(new Map(orders.map((order) => [order.orderNumber, order])).values())
      .filter((order) => !query || orderSearchHaystack(order).includes(query))
      .filter((order) => columns.every((column) => {
        const terms = parseColumnTerms(columnFilters[column.key]);
        if (!terms.length) return true;
        const value = String(getOrderResultValue(order, column.key)).toLowerCase();
        return terms.some((term) => value.includes(term));
      }))
      .sort((left, right) => {
        const leftValue = getOrderResultValue(left, sortKey);
        const rightValue = getOrderResultValue(right, sortKey);
        const result = typeof leftValue === 'number' && typeof rightValue === 'number'
          ? leftValue - rightValue
          : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
        return sortDirection === 'asc' ? result : -result;
      });
  }, [columnFilters, columns, globalSearch, orders, sortDirection, sortKey]);

  const tablePageCount = Math.max(1, Math.ceil(tableRows.length / pageSize));
  const activePage = Math.min(page, tablePageCount);
  const pagedRows = tableRows.slice((activePage - 1) * pageSize, activePage * pageSize);

  const handleSort = (key: OrderResultColumnKey) => {
    onPageChange(1);
    if (sortKey === key) {
      setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection(key === 'orderDate' || key === 'totalAmount' ? 'desc' : 'asc');
    }
  };

  const updateColumnFilter = (key: OrderResultColumnKey, value: string) => {
    setColumnFilters((current) => ({ ...current, [key]: value }));
    onPageChange(1);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
      <GlassCard sx={{ p: { xs: 1.35, md: 1.75 }, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.78), overflow: 'hidden' }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} justifyContent="space-between" gap={1.35} alignItems={{ lg: 'center' }} sx={{ mb: 1.35 }}>
          <Box>
            <Stack direction="row" spacing={0.8} alignItems="center" flexWrap="wrap" useFlexGap>
              <Typography variant="subtitle1" fontWeight={950}>Order Search Results</Typography>
              <Chip size="small" label={population === 'nonCustomer' ? 'Non-Customer Orders' : 'Customer Orders'} color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
              <Chip size="small" label={`${tableRows.length} matching`} variant="outlined" />
            </Stack>
            <Typography variant="caption" color="text.secondary">Use the global search or enter comma-separated values under any column.</Typography>
          </Box>
          <TextField
            size="small"
            value={globalSearch}
            onChange={(event) => {
              onGlobalSearch(event.target.value);
              onPageChange(1);
            }}
            placeholder="Search across orders, releases, item, node, tracking"
            sx={{ minWidth: { xs: '100%', lg: 420 } }}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          />
        </Stack>

        <Box
          sx={{
            overflow: 'hidden',
            border: 1,
            borderColor: (theme) => alpha(theme.palette.primary.main, 0.26),
            borderRadius: 2.5,
            bgcolor: 'background.paper',
            boxShadow: '0 18px 42px rgba(15,23,42,.12)'
          }}
        >
          <Box sx={{ overflowX: 'auto' }}>
            <Table
              size="small"
              sx={{
                minWidth: 1110,
                tableLayout: 'fixed',
                '& thead th': {
                  background: (theme) => theme.palette.mode === 'light'
                    ? 'linear-gradient(180deg, rgba(246,248,251,.98), rgba(222,229,238,.96))'
                    : 'linear-gradient(180deg, rgba(38,45,55,.98), rgba(18,24,32,.98))',
                  color: (theme) => theme.palette.mode === 'light' ? '#172033' : '#f7fafc',
                  fontWeight: 950,
                  borderRight: 1,
                  borderRightColor: (theme) => alpha(theme.palette.divider, 0.62),
                  px: 0.75,
                  py: 0.7,
                  verticalAlign: 'top'
                },
                '& thead th:last-of-type': { borderRight: 0 },
                '& tbody tr:nth-of-type(odd)': {
                  background: (theme) => theme.palette.mode === 'light'
                    ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(248,252,253,.98))'
                    : alpha(theme.palette.background.paper, 0.8)
                },
                '& tbody tr:nth-of-type(even)': {
                  background: (theme) => theme.palette.mode === 'light'
                    ? 'linear-gradient(90deg, rgba(232,244,248,.74), rgba(241,248,250,.92))'
                    : alpha(theme.palette.primary.main, 0.075)
                },
                '& tbody tr:hover': {
                  background: (theme) => `${theme.palette.mode === 'light' ? 'linear-gradient(90deg, rgba(214,239,245,.96), rgba(238,248,251,.98))' : alpha(theme.palette.primary.main, 0.14)} !important`,
                  boxShadow: 'inset 3px 0 0 rgba(17,124,139,.72)'
                },
                '& td': {
                  px: 0.8,
                  py: 0.72,
                  borderRight: 1,
                  borderRightColor: (theme) => alpha(theme.palette.divider, 0.42),
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                },
                '& td:last-of-type': { borderRight: 0 },
                '& .MuiTableSortLabel-root': { color: 'inherit' },
                '& .MuiTableSortLabel-root.Mui-active': { color: 'primary.main' },
                '& .MuiTableSortLabel-icon': { color: 'primary.main !important' }
              }}
            >
              <TableHead>
                <TableRow>
                  {columns.map((column) => (
                    <TableCell key={column.key} sortDirection={sortKey === column.key ? sortDirection : false} sx={{ width: column.width }}>
                      <Stack spacing={0.65}>
                        <TableSortLabel
                          active={sortKey === column.key}
                          direction={sortKey === column.key ? sortDirection : 'asc'}
                          onClick={() => handleSort(column.key)}
                        >
                          {column.label}
                        </TableSortLabel>
                        <TextField
                          value={columnFilters[column.key]}
                          onChange={(event) => updateColumnFilter(column.key, event.target.value)}
                          placeholder={column.placeholder}
                          size="small"
                          multiline
                          maxRows={2}
                          InputProps={{
                            sx: {
                              height: 32,
                              bgcolor: (theme) => alpha(theme.palette.background.paper, 0.82),
                              '& textarea, & input': { fontSize: '0.68rem', py: 0.35 }
                            }
                          }}
                        />
                      </Stack>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {pagedRows.map((order) => (
                  <TableRow key={order.orderNumber} hover>
                    <TableCell>
                      <Button
                        variant="text"
                        size="small"
                        onClick={() => setSelectedOrder(order)}
                        sx={{ px: 0, minWidth: 0, fontWeight: 950, textDecoration: 'underline', textUnderlineOffset: 3 }}
                      >
                        {order.orderNumber}
                      </Button>
                    </TableCell>
                    <TableCell sx={{ fontWeight: 850 }}>{order.orderType}</TableCell>
                    <TableCell><StatusChip label={order.status} /></TableCell>
                    <TableCell><Chip size="small" label={order.organization} variant="outlined" sx={{ fontWeight: 900 }} /></TableCell>
                    <TableCell><PaymentStatusChip status={order.paymentStatus} /></TableCell>
                    <TableCell>
                      {order.onHold
                        ? <Chip size="small" icon={<PauseCircleFilledIcon />} label="On Hold" color="warning" variant="outlined" sx={{ fontWeight: 900 }} />
                        : <Chip size="small" label="Clear" color="success" variant="outlined" sx={{ fontWeight: 900 }} />}
                    </TableCell>
                    <TableCell sx={{ fontWeight: 850 }}>{order.orderDate}</TableCell>
                    <TableCell sx={{ fontWeight: 950 }}>{formatCurrency(order.totalAmount)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </Box>

        {!tableRows.length && <Alert severity="info" sx={{ mt: 1.35 }}>No orders match the selected table filters.</Alert>}
        {tableRows.length > 0 && (
          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center" gap={1.25} sx={{ mt: 1.45, pt: 1.15, borderTop: 1, borderColor: 'divider' }}>
            <Typography variant="body2" color="text.secondary">
              Showing {(activePage - 1) * pageSize + 1}-{Math.min(activePage * pageSize, tableRows.length)} of {tableRows.length} orders · {pageSize} per page
            </Typography>
            <Pagination count={tablePageCount} page={activePage} onChange={(_, value) => onPageChange(value)} color="primary" shape="rounded" />
          </Stack>
        )}
      </GlassCard>
      <OrderDetailsDialog order={selectedOrder} onClose={() => setSelectedOrder(null)} />
    </motion.div>
  );
}

function OrderDetailsDialog({ order, onClose }: { order: Order | null; onClose: () => void }) {
  return (
    <Dialog
      open={Boolean(order)}
      onClose={onClose}
      fullWidth
      maxWidth={false}
      aria-labelledby={order ? `order-details-${order.orderNumber}` : undefined}
      PaperProps={{
        sx: {
          m: { xs: 1.5, md: 2 },
          width: { xs: 'calc(100vw - 24px)', md: 'calc(100vw - 40px)' },
          maxWidth: '1780px',
          maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 48px)' },
          borderRadius: { xs: 2, md: 3 },
          overflow: 'hidden',
          bgcolor: 'background.paper'
        }
      }}
    >
      {order && (
        <>
          <DialogTitle id={`order-details-${order.orderNumber}`} sx={{ position: 'relative', pr: 7, px: { xs: 2, md: 3 }, py: 2, borderBottom: 1, borderColor: 'divider' }}>
            <Stack direction="row" spacing={1.4} alignItems="center" flexWrap="wrap" useFlexGap>
              <Box sx={{ width: 42, height: 42, borderRadius: 1.75, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1), border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.22) }}>
                <ReceiptLongOutlinedIcon />
              </Box>
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="h6" fontWeight={950}>{order.orderNumber}</Typography>
                <Typography variant="body2" color="text.secondary">{order.organization} · {order.orderType} · {formatCurrency(order.totalAmount)}</Typography>
              </Box>
              <PaymentStatusChip status={order.paymentStatus} />
              <StatusChip label={order.status} />
            </Stack>
            <IconButton aria-label="Close order details" onClick={onClose} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
          </DialogTitle>
          <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: (theme) => alpha(theme.palette.background.default, 0.58), overflowY: 'auto' }}>
            <OrderInformation order={order} />
            <OrderDetailTables order={order} />
          </DialogContent>
        </>
      )}
    </Dialog>
  );
}

function OrderDetailTables({ order }: { order: Order }) {
  const [globalSearch, setGlobalSearch] = useState('');
  const [releaseColumnFilters, setReleaseColumnFilters] = useState<Partial<Record<ReleaseSortKey, string>>>({});
  const [fulfillmentColumnFilters, setFulfillmentColumnFilters] = useState<Partial<Record<FulfillmentSortKey, string>>>({});
  const [releasePage, setReleasePage] = useState(1);
  const [releaseSortKey, setReleaseSortKey] = useState<ReleaseSortKey>('lineNumber');
  const [releaseSortDirection, setReleaseSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentPage, setFulfillmentPage] = useState(1);
  const [fulfillmentSortKey, setFulfillmentSortKey] = useState<FulfillmentSortKey>('nodeName');
  const [fulfillmentSortDirection, setFulfillmentSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentMultiSort, setFulfillmentMultiSort] = useState(false);
  const [syncStatus, setSyncStatus] = useState<ActionStatus | null>(null);
  const [syncReceiptOpen, setSyncReceiptOpen] = useState(false);
  const [syncTarget, setSyncTarget] = useState<Fulfillment | null>(null);
  const normalizedSearch = globalSearch.trim().toLowerCase();
  const orderLines = useMemo(() => getOrderLines(order), [order.releases]);
  const releaseRows = useMemo<ReleaseTableRow[]>(() => {
    const rows: ReleaseTableRow[] = orderLines.flatMap((line) => {
    const lineReleases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return lineReleases.length
      ? lineReleases.map((release) => ({ id: release.releaseLineId, line, release }))
      : [{ id: `line-${line.lineNumber}`, line }];
    });
    return Array.from(new Map(rows.map((row) => [
      `${row.line.lineNumber}|${row.release?.releaseNumber ?? 'unreleased'}|${row.release?.releaseLineId ?? row.id}`,
      row
    ])).values());
  }, [orderLines, order.releases]);

  const filteredReleaseRows = useMemo(() => releaseRows.filter((row) => {
    const { line, release } = row;
    const matchesGlobal = !normalizedSearch || [
      line.lineNumber, line.sku, line.productName, line.currentStatus, line.orderedQty, line.lineTotal,
      release?.releaseNumber ?? '', release?.releaseLineId ?? '', release?.orderLineId ?? '', release?.itemId ?? '',
      release?.fulfillmentMethod ?? '', release?.assignedNode ?? '', release?.assignedNodeType ?? '',
      release?.releaseDate ?? '', release?.updatedDate ?? '', release?.quantity ?? '', release?.fulfilledQty ?? '', release?.cancelledQty ?? ''
    ].join(' ').toLowerCase().includes(normalizedSearch);
    return matchesGlobal && Object.entries(releaseColumnFilters).every(([key, value]) =>
      !value?.trim() || String(getReleaseSortValue(row, key as ReleaseSortKey)).toLowerCase().includes(value.trim().toLowerCase())
    );
  }), [normalizedSearch, releaseColumnFilters, releaseRows]);

  const sortedReleaseRows = useMemo(() => [...filteredReleaseRows].sort((left, right) => {
    const leftValue = getReleaseSortValue(left, releaseSortKey);
    const rightValue = getReleaseSortValue(right, releaseSortKey);
    const result = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
    return releaseSortDirection === 'asc' ? result : -result;
  }), [filteredReleaseRows, releaseSortDirection, releaseSortKey]);

  const filteredFulfillmentRows = useMemo(() => Array.from(new Map(order.fulfillments.map((row) => [
    `${row.fulfillmentId}|${row.releaseNumber}|${row.releaseLineId}`,
    row
  ])).values()).filter((row) => {
    const matchesGlobal = !normalizedSearch || [
      row.fulfillmentId, row.type, row.nodeName, row.status, row.releaseNumber, row.releaseLineId,
      row.packageId, row.packageDetailId, row.shipmentId, row.quantity, getFulfillmentShippedQty(row, order.releases),
      getFulfillmentCancelledQty(row, order.releases), row.shipVia, row.trackingNumber, row.createdDate ?? '', row.updatedDate ?? ''
    ].join(' ').toLowerCase().includes(normalizedSearch);
    return matchesGlobal && Object.entries(fulfillmentColumnFilters).every(([key, value]) => {
      if (!value?.trim()) return true;
      const typedKey = key as FulfillmentSortKey;
      const cellValue = typedKey === 'shippedQty'
        ? getFulfillmentShippedQty(row, order.releases)
        : typedKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(row, order.releases)
          : getFulfillmentSortValue(row, typedKey);
      return String(cellValue).toLowerCase().includes(value.trim().toLowerCase());
    });
  }), [fulfillmentColumnFilters, normalizedSearch, order.fulfillments, order.releases]);

  const sortedFulfillmentRows = useMemo(() => [...filteredFulfillmentRows].sort((first, second) => {
    const compareValues = (sortKey: FulfillmentSortKey) => {
      const firstValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(first, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(first, order.releases)
          : getFulfillmentSortValue(first, sortKey);
      const secondValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(second, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(second, order.releases)
          : getFulfillmentSortValue(second, sortKey);
      return typeof firstValue === 'number' && typeof secondValue === 'number'
        ? firstValue - secondValue
        : String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: 'base' });
    };
    const result = fulfillmentMultiSort
      ? (compareValues('type') || compareValues('nodeName') || compareValues('status') || compareValues('releaseNumber'))
      : compareValues(fulfillmentSortKey);
    return fulfillmentSortDirection === 'asc' ? result : -result;
  }), [filteredFulfillmentRows, fulfillmentMultiSort, fulfillmentSortDirection, fulfillmentSortKey, order.releases]);

  const releasePageCount = Math.max(1, Math.ceil(sortedReleaseRows.length / popupPageSize));
  const fulfillmentPageCount = Math.max(1, Math.ceil(sortedFulfillmentRows.length / popupPageSize));
  const activeReleasePage = Math.min(releasePage, releasePageCount);
  const activeFulfillmentPage = Math.min(fulfillmentPage, fulfillmentPageCount);
  const pagedReleaseRows = sortedReleaseRows.slice((activeReleasePage - 1) * popupPageSize, activeReleasePage * popupPageSize);
  const pagedFulfillmentRows = sortedFulfillmentRows.slice((activeFulfillmentPage - 1) * popupPageSize, activeFulfillmentPage * popupPageSize);

  const handleReleaseSort = (sortKey: ReleaseSortKey) => {
    setReleasePage(1);
    setReleaseSortDirection((current) => releaseSortKey === sortKey && current === 'asc' ? 'desc' : 'asc');
    setReleaseSortKey(sortKey);
  };
  const handleFulfillmentSort = (sortKey: FulfillmentSortKey) => {
    setFulfillmentMultiSort(false);
    setFulfillmentPage(1);
    if (fulfillmentSortKey === sortKey) setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    else {
      setFulfillmentSortKey(sortKey);
      setFulfillmentSortDirection('asc');
    }
  };
  const confirmSync = async () => {
    if (!syncTarget) return;
    const target = syncTarget;
    let nextStatus: ActionStatus;
    try {
      const response = await omsApi.syncFulfillment(target.fulfillmentId);
      nextStatus = { severity: 'success', message: `${target.releaseNumber}: Fulfillment sync requested. Status sync queued for ${response.fulfillmentId}.` };
    } catch (requestError) {
      nextStatus = { severity: 'error', message: requestError instanceof Error ? requestError.message : 'The fulfillment sync could not be submitted.' };
    } finally {
      setSyncTarget(null);
      setSyncStatus(null);
      setSyncReceiptOpen(false);
      window.setTimeout(() => {
        setSyncStatus(nextStatus);
        setSyncReceiptOpen(true);
      }, 120);
    }
  };

  return (
    <Box>
      <GlassCard sx={{ p: 1.35, mb: 1.5, bgcolor: 'background.paper' }}>
        <TextField
          fullWidth
          size="small"
          label="Global search across release and fulfillment details"
          value={globalSearch}
          onChange={(event) => {
            setGlobalSearch(event.target.value);
            setReleasePage(1);
            setFulfillmentPage(1);
          }}
          placeholder="Search line, item, release, node, package, shipment, status, tracking"
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
        />
      </GlassCard>
      <Stack spacing={2}>
        <Box>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1 }}>
            <Box>
              <Typography variant="subtitle1" fontWeight={950}>Release Details</Typography>
              <Typography variant="body2" color="text.secondary">{sortedReleaseRows.length} matching rows · column search and sorting enabled</Typography>
            </Box>
            <Chip label={`${order.releases.length} releases`} color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
          </Stack>
          <ReleaseLinesTable
            rows={pagedReleaseRows}
            sortKey={releaseSortKey}
            sortDirection={releaseSortDirection}
            onSort={handleReleaseSort}
            columnFilters={releaseColumnFilters}
            onColumnFilterChange={(key, value) => {
              setReleaseColumnFilters((current) => ({ ...current, [key]: value }));
              setReleasePage(1);
            }}
          />
          <HighVolumePagination page={activeReleasePage} count={releasePageCount} total={sortedReleaseRows.length} pageSize={popupPageSize} onChange={setReleasePage} />
        </Box>
        <Divider />
        <Box>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1 }}>
            <Box>
              <Typography variant="subtitle1" fontWeight={950}>Fulfillment Details</Typography>
              <Typography variant="body2" color="text.secondary">{sortedFulfillmentRows.length} matching rows · column search and sorting enabled</Typography>
            </Box>
            <Button
              variant={fulfillmentMultiSort ? 'contained' : 'outlined'}
              startIcon={<TuneIcon />}
              onClick={() => {
                setFulfillmentMultiSort((current) => !current);
                setFulfillmentPage(1);
              }}
              sx={{ borderRadius: 1.75, fontWeight: 900 }}
            >
              Multi-sort {fulfillmentMultiSort ? 'On' : 'Off'}
            </Button>
          </Stack>
          <FulfillmentLinesTable
            rows={pagedFulfillmentRows}
            sortKey={fulfillmentSortKey}
            sortDirection={fulfillmentSortDirection}
            onSort={handleFulfillmentSort}
            onSync={setSyncTarget}
            releases={order.releases}
            multiSort={fulfillmentMultiSort}
            columnFilters={fulfillmentColumnFilters}
            onColumnFilterChange={(key, value) => {
              setFulfillmentColumnFilters((current) => ({ ...current, [key]: value }));
              setFulfillmentPage(1);
            }}
          />
          <HighVolumePagination page={activeFulfillmentPage} count={fulfillmentPageCount} total={sortedFulfillmentRows.length} pageSize={popupPageSize} onChange={setFulfillmentPage} />
        </Box>
      </Stack>
      <ActionConfirmationDialog
        open={Boolean(syncTarget)}
        title="Sync this release status?"
        eyebrow="Fulfillment Synchronization"
        description="The latest package and shipment status will be synchronized to this release line only."
        confirmLabel="Confirm Sync"
        tone="info"
        icon={<SyncIcon />}
        details={syncTarget ? [
          ['Release ID', syncTarget.releaseNumber],
          ['Rel Line Id', syncTarget.releaseLineId],
          ['Fulfillment Location', syncTarget.nodeName],
          ['Current Status', syncTarget.status]
        ] : []}
        onClose={() => setSyncTarget(null)}
        onConfirm={confirmSync}
      />
      <Dialog open={Boolean(syncStatus) && syncReceiptOpen} onClose={() => setSyncReceiptOpen(false)} maxWidth={false} fullWidth sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }} PaperProps={{ sx: { width: { xs: 'calc(100vw - 32px)', sm: 440 }, overflow: 'hidden', borderRadius: 2.5 } }}>
        <Box sx={{ px: 2.35, py: 2.1, background: syncStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : syncStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Typography variant="overline" fontWeight={950} sx={{ color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>Fulfillment Synchronization</Typography>
          <Typography variant="h6" fontWeight={950} color="text.primary">{syncStatus?.severity === 'success' ? 'Sync request submitted' : 'Sync request needs attention'}</Typography>
          <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>{syncStatus?.message}</Typography>
        </Box>
        <DialogActions sx={{ px: 2.35, py: 1.55, borderTop: 1, borderColor: 'divider' }}>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={() => setSyncReceiptOpen(false)}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function NonCustomerResults({
  orders,
  globalSearch,
  onGlobalSearch
}: {
  orders: Order[];
  globalSearch: string;
  onGlobalSearch: (value: string) => void;
}) {
  const [syncStatus, setSyncStatus] = useState<ActionStatus | null>(null);
  const [syncReceiptOpen, setSyncReceiptOpen] = useState(false);
  const [syncTarget, setSyncTarget] = useState<Fulfillment | null>(null);

  const allFulfillments = useMemo(() => orders.flatMap((order) => order.fulfillments), [orders]);
  const totalLines = orders.reduce((total, order) => total + getOrderLines(order).length, 0);
  const totalReleases = orders.reduce((total, order) => total + order.releases.length, 0);
  const totalFulfillmentRows = orders.reduce((total, order) => total + order.fulfillments.length, 0);
  const totalUnits = orders.reduce((total, order) => total + order.totalUnits, 0);
  const totalAmount = orders.reduce((total, order) => total + order.totalAmount, 0);
  const exceptionCount = allFulfillments.filter((fulfillment) => fulfillment.status.includes('Awaiting') || fulfillment.status === 'Cancelled').length;

  const confirmSync = async () => {
    if (!syncTarget) return;
    const target = syncTarget;
    let nextStatus: ActionStatus;
    try {
      const response = await omsApi.syncFulfillment(target.fulfillmentId);
      nextStatus = {
        severity: 'success',
        message: `${target.releaseNumber}: Fulfillment sync requested. Status sync queued for ${response.fulfillmentId}.`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The fulfillment sync could not be submitted.'
      };
    } finally {
      setSyncTarget(null);
      setSyncStatus(null);
      setSyncReceiptOpen(false);
      window.setTimeout(() => {
        setSyncStatus(nextStatus);
        setSyncReceiptOpen(true);
      }, 120);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
      <Stack spacing={1.5}>
        <GlassCard sx={{ p: { xs: 1.45, md: 1.85 }, overflow: 'hidden', bgcolor: (theme) => alpha(theme.palette.background.paper, 0.78) }}>
          <Stack direction={{ xs: 'column', lg: 'row' }} justifyContent="space-between" gap={1.4} alignItems={{ lg: 'center' }}>
            <Box sx={{ minWidth: 0 }}>
              <Stack direction="row" spacing={0.8} flexWrap="wrap" useFlexGap alignItems="center">
                <Chip label="Non-Customer High-Volume Mode" color="primary" sx={{ fontWeight: 950 }} />
                <Chip label={`${orders.length} order${orders.length === 1 ? '' : 's'}`} variant="outlined" />
              </Stack>
              <Typography variant="h6" fontWeight={950} sx={{ mt: 0.8 }}>Bulk Order Operations Workbench</Typography>
              <Typography variant="body2" color="text.secondary">
                Flat, paginated tables for high line-count orders, release orchestration, and node execution status.
              </Typography>
            </Box>
            <Grid container spacing={0.85} sx={{ maxWidth: { lg: 760 } }}>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Lines" value={String(totalLines)} /></Grid>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Releases" value={String(totalReleases)} /></Grid>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Node Rows" value={String(totalFulfillmentRows)} /></Grid>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Units" value={String(totalUnits)} /></Grid>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Demand" value={formatCurrency(totalAmount)} /></Grid>
              <Grid item xs={6} sm={4} md={2}><NonCustomerMetric label="Exceptions" value={String(exceptionCount)} alert={exceptionCount > 0} /></Grid>
            </Grid>
          </Stack>
          <Box sx={{ mt: 1.4, pt: 1.25, borderTop: 1, borderColor: 'divider' }}>
            <TextField
              fullWidth
              size="small"
              label="Global search within non-customer results"
              value={globalSearch}
              onChange={(event) => onGlobalSearch(event.target.value)}
              placeholder="Search order, item, release, fulfillment node, package, shipment, tracking"
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                sx: {
                  borderRadius: 1.75,
                  bgcolor: 'background.paper',
                  boxShadow: '0 8px 22px rgba(15,23,42,.06)'
                }
              }}
            />
          </Box>
        </GlassCard>

        {!orders.length && <Alert severity="info">No non-customer orders match the selected criteria.</Alert>}

        {orders.map((order) => (
          <NonCustomerOrderPanel key={order.orderNumber} order={order} onSync={setSyncTarget} />
        ))}
      </Stack>
      <ActionConfirmationDialog
        open={Boolean(syncTarget)}
        title="Sync this fulfillment node status?"
        eyebrow="Fulfillment Synchronization"
        description="The selected fulfillment execution status will be synchronized back to the release line."
        confirmLabel="Confirm Sync"
        tone="info"
        icon={<SyncIcon />}
        details={syncTarget ? [
          ['Release ID', syncTarget.releaseNumber],
          ['Rel Line Id', syncTarget.releaseLineId],
          ['Fulfillment Location', syncTarget.nodeName],
          ['Current Status', syncTarget.status]
        ] : []}
        onClose={() => setSyncTarget(null)}
        onConfirm={confirmSync}
      />
      <Dialog
        open={Boolean(syncStatus) && syncReceiptOpen}
        onClose={() => setSyncReceiptOpen(false)}
        maxWidth={false}
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', sm: 420 },
            borderRadius: 2.25,
            overflow: 'hidden'
          }
        }}
      >
        <Box sx={{ px: 2.25, py: 2, background: syncStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : syncStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Typography variant="overline" fontWeight={950} sx={{ color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
            Fulfillment Synchronization
          </Typography>
          <Typography variant="h6" fontWeight={950} color="text.primary">
            {syncStatus?.severity === 'success' ? 'Sync request submitted' : 'Sync request needs attention'}
          </Typography>
          <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
            {syncStatus?.message}
          </Typography>
        </Box>
        <DialogActions sx={{ px: 2.25, py: 1.5, borderTop: 1, borderColor: 'divider' }}>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={() => setSyncReceiptOpen(false)}>Done</Button>
        </DialogActions>
      </Dialog>
    </motion.div>
  );
}

function NonCustomerOrderPanel({ order, onSync }: { order: Order; onSync: (fulfillment: Fulfillment) => void }) {
  const [orderGlobalSearch, setOrderGlobalSearch] = useState('');
  const [linePage, setLinePage] = useState(1);
  const [releaseSortKey, setReleaseSortKey] = useState<ReleaseSortKey>('lineNumber');
  const [releaseSortDirection, setReleaseSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentPage, setFulfillmentPage] = useState(1);
  const [fulfillmentSortKey, setFulfillmentSortKey] = useState<FulfillmentSortKey>('nodeName');
  const [fulfillmentSortDirection, setFulfillmentSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentMultiSort, setFulfillmentMultiSort] = useState(true);
  const accent = getOrderAccent(order.status);
  const orderLines = useMemo(() => getOrderLines(order), [order.releases]);
  const releaseRows = useMemo<ReleaseTableRow[]>(() => orderLines.flatMap((line) => {
    const lineReleases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return lineReleases.length
      ? lineReleases.map((release) => ({ id: `${order.orderNumber}-${release.releaseLineId}`, orderNumber: order.orderNumber, line, release }))
      : [{ id: `${order.orderNumber}-line-${line.lineNumber}`, orderNumber: order.orderNumber, line }];
  }), [orderLines, order.orderNumber, order.releases]);

  const filteredReleaseRows = useMemo(() => {
    const query = orderGlobalSearch.trim().toLowerCase();
    if (!query) return releaseRows;
    return releaseRows.filter(({ orderNumber, line, release }) => [
      orderNumber ?? '',
      line.lineNumber,
      line.sku,
      line.productName,
      line.currentStatus,
      line.orderedQty,
      line.lineTotal,
      release?.releaseNumber ?? '',
      release?.releaseLineId ?? '',
      release?.assignedNode ?? '',
      release?.assignedNodeType ?? '',
      release?.fulfillmentMethod ?? '',
      release?.releaseDate ?? '',
      release?.updatedDate ?? ''
    ].join(' ').toLowerCase().includes(query));
  }, [orderGlobalSearch, releaseRows]);
  const sortedReleaseRows = useMemo(() => [...filteredReleaseRows].sort((left, right) => {
    const leftValue = getReleaseSortValue(left, releaseSortKey);
    const rightValue = getReleaseSortValue(right, releaseSortKey);
    const result = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
    return releaseSortDirection === 'asc' ? result : -result;
  }), [filteredReleaseRows, releaseSortDirection, releaseSortKey]);
  const linePageCount = Math.max(1, Math.ceil(sortedReleaseRows.length / nonCustomerPageSize));
  const activeLinePage = Math.min(linePage, linePageCount);
  const pagedReleaseRows = sortedReleaseRows.slice((activeLinePage - 1) * nonCustomerPageSize, activeLinePage * nonCustomerPageSize);

  const filteredFulfillmentRows = useMemo(() => {
    const query = orderGlobalSearch.trim().toLowerCase();
    if (!query) return order.fulfillments;
    return order.fulfillments.filter((fulfillment) => [
      fulfillment.fulfillmentId,
      fulfillment.type,
      fulfillment.nodeName,
      fulfillment.status,
      fulfillment.releaseNumber,
      fulfillment.releaseLineId,
      fulfillment.packageId,
      fulfillment.packageDetailId,
      fulfillment.shipmentId,
      fulfillment.quantity,
      getFulfillmentCancelledQty(fulfillment, order.releases),
      fulfillment.shipVia,
      fulfillment.trackingNumber,
      fulfillment.createdDate ?? '',
      fulfillment.updatedDate ?? ''
    ].join(' ').toLowerCase().includes(query));
  }, [orderGlobalSearch, order.fulfillments]);
  const sortedFulfillmentRows = useMemo(() => [...filteredFulfillmentRows].sort((first, second) => {
    const compareValues = (sortKey: FulfillmentSortKey) => {
      const firstValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(first, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(first, order.releases)
          : getFulfillmentSortValue(first, sortKey);
      const secondValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(second, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(second, order.releases)
          : getFulfillmentSortValue(second, sortKey);
      return typeof firstValue === 'number' && typeof secondValue === 'number'
        ? firstValue - secondValue
        : String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: 'base' });
    };
    const result = fulfillmentMultiSort
      ? (compareValues('type') || compareValues('nodeName') || compareValues('status') || compareValues('releaseNumber'))
      : compareValues(fulfillmentSortKey);
    return fulfillmentSortDirection === 'asc' ? result : -result;
  }), [filteredFulfillmentRows, fulfillmentMultiSort, fulfillmentSortDirection, fulfillmentSortKey, order.releases]);
  const fulfillmentPageCount = Math.max(1, Math.ceil(sortedFulfillmentRows.length / nonCustomerPageSize));
  const activeFulfillmentPage = Math.min(fulfillmentPage, fulfillmentPageCount);
  const pagedFulfillmentRows = sortedFulfillmentRows.slice((activeFulfillmentPage - 1) * nonCustomerPageSize, activeFulfillmentPage * nonCustomerPageSize);

  const handleReleaseSort = (sortKey: ReleaseSortKey) => {
    setLinePage(1);
    setReleaseSortDirection((currentDirection) => releaseSortKey === sortKey && currentDirection === 'asc' ? 'desc' : 'asc');
    setReleaseSortKey(sortKey);
  };

  const handleFulfillmentSort = (sortKey: FulfillmentSortKey) => {
    setFulfillmentMultiSort(false);
    setFulfillmentPage(1);
    if (fulfillmentSortKey === sortKey) {
      setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    } else {
      setFulfillmentSortKey(sortKey);
      setFulfillmentSortDirection('asc');
    }
  };

  return (
    <Accordion
      defaultExpanded={false}
      disableGutters
      sx={{
        overflow: 'hidden',
        border: 1,
        borderTop: '4px solid',
        borderColor: (theme) => alpha(theme.palette.text.primary, 0.14),
        borderTopColor: accent,
        borderRadius: '10px !important',
        bgcolor: (theme) => alpha(theme.palette.background.paper, 0.86),
        boxShadow: '0 14px 34px rgba(15,23,42,.1)',
        '&:before': { display: 'none' },
        '&.Mui-expanded': { m: 0, borderColor: alpha(accent, 0.42), borderTopColor: accent }
      }}
    >
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ p: 0, '& .MuiAccordionSummary-content': { m: 0, minWidth: 0 } }}>
        <Box sx={{ width: '100%', px: { xs: 1.2, md: 1.55 }, py: { xs: 1, md: 1.15 }, background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(112deg, ${alpha(accent, 0.13)}, rgba(248,250,252,.98) 44%, rgba(226,232,240,.78))` : `linear-gradient(112deg, ${alpha(accent, 0.18)}, rgba(25,31,40,.95) 62%)` }}>
          <Stack direction={{ xs: 'column', lg: 'row' }} gap={1} alignItems={{ lg: 'center' }} justifyContent="space-between">
            <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap" useFlexGap>
              <ConfirmationNumberIcon sx={{ color: accent, fontSize: 18 }} />
              <Typography variant="subtitle1" fontWeight={950}>{order.orderNumber}</Typography>
              <StatusChip label={order.status} />
              {order.onHold && <Chip size="small" color="warning" icon={<PauseCircleFilledIcon />} label="On Hold" />}
            </Stack>
            <Grid container spacing={0.65} sx={{ maxWidth: { lg: 780 } }}>
              <Grid item xs={6} sm={3}><NonCustomerMetric label="Lines" value={String(getOrderLines(order).length)} /></Grid>
              <Grid item xs={6} sm={3}><NonCustomerMetric label="Created" value={order.orderDate} /></Grid>
              <Grid item xs={6} sm={3}><NonCustomerMetric label="Order Status" value={order.status} /></Grid>
              <Grid item xs={6} sm={3}><NonCustomerMetric label="Order Total" value={formatCurrency(order.totalAmount)} /></Grid>
            </Grid>
          </Stack>
        </Box>
      </AccordionSummary>
      <AccordionDetails sx={{ p: { xs: 1.15, md: 1.5 }, bgcolor: (theme) => alpha(theme.palette.background.default, 0.42) }}>
        <Stack spacing={1.35}>
          <GlassCard sx={{ p: { xs: 1.15, md: 1.35 }, bgcolor: 'background.paper' }}>
            <TextField
              fullWidth
              size="small"
              label="Global search within this order"
              value={orderGlobalSearch}
              onChange={(event) => {
                setOrderGlobalSearch(event.target.value);
                setLinePage(1);
                setFulfillmentPage(1);
              }}
              placeholder="Search line, item, release, fulfillment node, package, shipment, status, tracking"
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                sx: {
                  borderRadius: 1.75,
                  bgcolor: 'background.paper',
                  boxShadow: '0 8px 22px rgba(15,23,42,.06)'
                }
              }}
            />
          </GlassCard>
          <GlassCard sx={{ p: { xs: 1.15, md: 1.35 }, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.76) }}>
            <HighVolumeTableHeader
              title="Line & Release Workbench"
              subtitle={`${filteredReleaseRows.length} matching rows · ${nonCustomerPageSize} rows per page`}
            />
            <ReleaseLinesTable rows={pagedReleaseRows} sortKey={releaseSortKey} sortDirection={releaseSortDirection} onSort={handleReleaseSort} />
            <HighVolumePagination page={activeLinePage} count={linePageCount} total={sortedReleaseRows.length} onChange={setLinePage} />
          </GlassCard>

          <GlassCard sx={{ p: { xs: 1.15, md: 1.35 }, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.76) }}>
            <HighVolumeTableHeader
              title="Fulfillment Node Status Workbench"
              subtitle={`${filteredFulfillmentRows.length} matching node execution rows · ${nonCustomerPageSize} rows per page`}
              action={
                <Button
                  variant={fulfillmentMultiSort ? 'contained' : 'outlined'}
                  startIcon={<TuneIcon />}
                  onClick={() => {
                    setFulfillmentMultiSort((current) => !current);
                    setFulfillmentPage(1);
                  }}
                  sx={{ minWidth: 132, borderRadius: 1.75, fontWeight: 900 }}
                >
                  Multi-sort {fulfillmentMultiSort ? 'On' : 'Off'}
                </Button>
              }
            />
            <FulfillmentLinesTable
              rows={pagedFulfillmentRows}
              sortKey={fulfillmentSortKey}
              sortDirection={fulfillmentSortDirection}
              onSort={handleFulfillmentSort}
              onSync={onSync}
              releases={order.releases}
              multiSort={fulfillmentMultiSort}
              showType={false}
            />
            <HighVolumePagination page={activeFulfillmentPage} count={fulfillmentPageCount} total={sortedFulfillmentRows.length} onChange={setFulfillmentPage} />
          </GlassCard>
        </Stack>
      </AccordionDetails>
    </Accordion>
  );
}

function NonCustomerMetric({ label, value, alert = false }: { label: string; value: string; alert?: boolean }) {
  return (
    <Box sx={{ px: 1, py: 0.8, minHeight: 58, borderRadius: 1.5, border: 1, borderColor: (theme) => alpha(alert ? theme.palette.error.main : theme.palette.primary.main, 0.24), bgcolor: (theme) => alpha(alert ? theme.palette.error.main : theme.palette.primary.main, alert ? 0.085 : 0.06) }}>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1 }}>{label}</Typography>
      <Typography fontWeight={950} color={alert ? 'error.main' : 'text.primary'} sx={{ mt: 0.25, lineHeight: 1.1 }}>{value}</Typography>
    </Box>
  );
}

function HighVolumeTableHeader({
  title,
  subtitle,
  searchValue,
  searchLabel,
  searchPlaceholder,
  onSearch,
  action
}: {
  title: string;
  subtitle: string;
  searchValue?: string;
  searchLabel?: string;
  searchPlaceholder?: string;
  onSearch?: (value: string) => void;
  action?: ReactNode;
}) {
  return (
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between" sx={{ mb: 1.25 }}>
      <Box>
        <Typography variant="subtitle1" fontWeight={950}>{title}</Typography>
        <Typography variant="caption" color="text.secondary">{subtitle}</Typography>
      </Box>
      {(onSearch || action) && (
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'stretch', sm: 'center' }} sx={{ minWidth: { md: onSearch ? 520 : 'auto' } }}>
          {onSearch && (
            <TextField
              fullWidth
              size="small"
              label={searchLabel}
              value={searchValue ?? ''}
              onChange={(event) => onSearch(event.target.value)}
              placeholder={searchPlaceholder}
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
            />
          )}
          {action}
        </Stack>
      )}
    </Stack>
  );
}

function HighVolumePagination({
  page,
  count,
  total,
  pageSize: rowsPerPage = nonCustomerPageSize,
  onChange
}: {
  page: number;
  count: number;
  total: number;
  pageSize?: number;
  onChange: (page: number) => void;
}) {
  if (total <= rowsPerPage) return null;
  return (
    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ mt: 1.35, pt: 1.2, borderTop: 1, borderColor: 'divider' }}>
      <Typography variant="body2" color="text.secondary">
        Showing {(page - 1) * rowsPerPage + 1}-{Math.min(page * rowsPerPage, total)} of {total} rows · {rowsPerPage} per page
      </Typography>
      <Pagination count={count} page={page} onChange={(_, value) => onChange(value)} color="primary" size="small" shape="rounded" />
    </Stack>
  );
}

function OrderLines({ order }: { order: Order }) {
  const [allReleasesOpen, setAllReleasesOpen] = useState(false);
  const [releaseSearch, setReleaseSearch] = useState('');
  const [releasePage, setReleasePage] = useState(1);
  const [releaseSortKey, setReleaseSortKey] = useState<ReleaseSortKey>('lineNumber');
  const [releaseSortDirection, setReleaseSortDirection] = useState<SortDirection>('asc');
  const orderLines = useMemo(() => getOrderLines(order), [order.releases]);
  const orderedUnits = orderLines.reduce((total, line) => total + line.orderedQty, 0);
  const lineAmount = orderLines.reduce((total, line) => total + line.lineTotal, 0);
  const normalizedReleaseSearch = releaseSearch.trim().toLowerCase();
  const releaseRows = useMemo<ReleaseTableRow[]>(() => orderLines.flatMap((line) => {
    const lineReleases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return lineReleases.length
      ? lineReleases.map((release) => ({ id: release.releaseLineId, line, release }))
      : [{ id: `line-${line.lineNumber}`, line }];
  }), [orderLines, order.releases]);
  const filteredReleaseRows = useMemo(() => {
    if (!normalizedReleaseSearch) return releaseRows;

    return releaseRows.filter(({ line, release }) => {
      const lineText = [
        line.lineNumber,
        line.sku,
        line.productName,
        line.currentStatus,
        line.orderedQty,
        line.lineTotal,
        release?.releaseNumber ?? '',
        release?.releaseLineId ?? '',
        release?.orderLineId ?? '',
        release?.itemId ?? '',
        release?.releaseStatus ?? '',
        release?.fulfillmentMethod ?? '',
        release?.assignedNode ?? '',
        release?.assignedNodeType ?? '',
        release?.releaseDate ?? '',
        release?.updatedDate ?? '',
        release?.quantity ?? '',
        release?.fulfilledQty ?? '',
        release?.cancelledQty ?? ''
      ].join(' ').toLowerCase();
      return lineText.includes(normalizedReleaseSearch);
    });
  }, [normalizedReleaseSearch, releaseRows]);
  const sortedReleaseRows = useMemo(() => [...filteredReleaseRows].sort((left, right) => {
    const leftValue = getReleaseSortValue(left, releaseSortKey);
    const rightValue = getReleaseSortValue(right, releaseSortKey);
    const result = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
    return releaseSortDirection === 'asc' ? result : -result;
  }), [filteredReleaseRows, releaseSortDirection, releaseSortKey]);
  const filteredLineCount = new Set(filteredReleaseRows.map((row) => row.line.lineNumber)).size;
  const filteredReleaseCount = filteredReleaseRows.filter((row) => row.release).length;
  const releasePageCount = Math.max(1, Math.ceil(sortedReleaseRows.length / popupPageSize));
  const pagedReleaseRows = sortedReleaseRows.slice((releasePage - 1) * popupPageSize, releasePage * popupPageSize);

  const closeAllReleases = () => {
    setAllReleasesOpen(false);
    setReleaseSearch('');
    setReleasePage(1);
  };
  const handleReleaseSort = (sortKey: ReleaseSortKey) => {
    setReleasePage(1);
    setReleaseSortDirection((currentDirection) => releaseSortKey === sortKey && currentDirection === 'asc' ? 'desc' : 'asc');
    setReleaseSortKey(sortKey);
  };

  return (
    <Box sx={{ mb: 1.5 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 0.75 }}>
        <Box>
          <Typography variant="subtitle2" fontWeight={950}>Order Lines</Typography>
          <Typography variant="caption" color="text.secondary">Line-level merchandise and release allocation</Typography>
        </Box>
        <Chip size="small" label={`${order.releases.length} releases`} variant="outlined" />
      </Stack>
      <GlassCard sx={{ mb: 0.75, overflow: 'hidden', borderColor: (theme) => alpha(theme.palette.primary.main, 0.3), bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
        <ButtonBase aria-label="Open all order line releases" onClick={() => setAllReleasesOpen(true)} sx={{ width: '100%', p: { xs: 1, md: 1.1 }, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(4, minmax(0, 1fr)) 28px' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center' }}>
            <AggregateMetric label="Order Lines" value={String(orderLines.length)} />
            <AggregateMetric label="Ordered Units" value={String(orderedUnits)} />
            <AggregateMetric label="Releases" value={String(order.releases.length)} />
            <AggregateMetric label="Line Amount" value={formatCurrency(lineAmount)} />
            <OpenInNewIcon color="primary" />
          </Box>
        </ButtonBase>
      </GlassCard>
      <Dialog
        open={allReleasesOpen}
        onClose={closeAllReleases}
        fullWidth
        maxWidth={false}
        aria-labelledby={`all-order-releases-${order.orderNumber}`}
        PaperProps={{
          sx: {
            m: { xs: 1.5, md: 2 },
            width: { xs: 'calc(100vw - 24px)', md: 'calc(100vw - 32px)' },
            maxWidth: '1760px',
            height: 'auto',
            maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 48px)' },
            borderRadius: { xs: 2, md: 3 }
          }
        }}
      >
        <DialogTitle id={`all-order-releases-${order.orderNumber}`} sx={{ pr: 7 }}>
          <Typography variant="h6">Order Lines & Releases</Typography>
          <Typography variant="body2" color="text.secondary">{order.orderNumber} · {filteredLineCount} of {orderLines.length} lines · {filteredReleaseCount} of {order.releases.length} releases · {sortedReleaseRows.length} table rows</Typography>
          <IconButton aria-label="Close all order releases" onClick={closeAllReleases} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: (theme) => alpha(theme.palette.background.default, 0.5), overflowY: 'auto' }}>
          <Box sx={{ position: 'sticky', top: 0, zIndex: 2, mb: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper', backdropFilter: 'none', boxShadow: '0 10px 24px rgba(15,23,42,.06)' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
              <TextField
                fullWidth
                size="small"
                label="Search order lines and releases"
                value={releaseSearch}
                onChange={(event) => {
                  setReleaseSearch(event.target.value);
                  setReleasePage(1);
                }}
                placeholder="Search line ID, item, status, release, node, delivery method"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
                }}
              />
              <Chip label="Sortable table" color="primary" variant="outlined" sx={{ minWidth: 132, fontWeight: 900 }} />
            </Stack>
          </Box>
          <ReleaseLinesTable
            rows={pagedReleaseRows}
            sortKey={releaseSortKey}
            sortDirection={releaseSortDirection}
            onSort={handleReleaseSort}
          />
          {!filteredReleaseRows.length && <Alert severity="info" sx={{ mt: 1.25 }}>No order lines or releases match this popup search.</Alert>}
          {sortedReleaseRows.length > popupPageSize && (
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ position: 'sticky', bottom: 0, mt: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper', backdropFilter: 'none', boxShadow: '0 -10px 24px rgba(15,23,42,.06)' }}>
              <Typography variant="body2" color="text.secondary">
                Showing {(releasePage - 1) * popupPageSize + 1}-{Math.min(releasePage * popupPageSize, sortedReleaseRows.length)} of {sortedReleaseRows.length} matching rows
              </Typography>
              <Pagination count={releasePageCount} page={releasePage} onChange={(_, value) => setReleasePage(value)} color="primary" size="small" />
            </Stack>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function AggregateMetric({ label, value, alert = false }: { label: string; value: string; alert?: boolean }) {
  return (
    <Box sx={{ minWidth: 0 }}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Typography fontWeight={900} color={alert ? 'error.main' : 'text.primary'} noWrap>{value}</Typography>
    </Box>
  );
}

function OrderLineSummary({ line }: { line: OrderLine }) {
  return (
    <GlassCard sx={{ p: 1.4, borderLeft: '4px solid', borderLeftColor: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.03) }}>
      <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: '80px minmax(105px, .75fr) minmax(200px, 1.75fr) minmax(115px, .8fr) 85px 105px' }, gap: { xs: 0.7, md: 1.5 }, alignItems: 'center' }}>
        <LineValue label="Line ID" value={line.lineNumber} strong />
        <LineValue label="Item ID" value={line.sku} strong />
        <LineValue label="Item Description" value={line.productName} />
        <Box><Typography variant="caption" color="text.secondary">Line Status</Typography><Box><StatusChip label={line.currentStatus} /></Box></Box>
        <LineValue label="Ordered Qty" value={String(line.orderedQty)} strong />
        <LineValue label="Line Total" value={formatCurrency(line.lineTotal)} strong />
      </Box>
    </GlassCard>
  );
}

function CustomerOrderWorkbench({ order }: { order: Order }) {
  const [workbenchOpen, setWorkbenchOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [releasePage, setReleasePage] = useState(1);
  const [releaseSortKey, setReleaseSortKey] = useState<ReleaseSortKey>('lineNumber');
  const [releaseSortDirection, setReleaseSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentPage, setFulfillmentPage] = useState(1);
  const [fulfillmentSortKey, setFulfillmentSortKey] = useState<FulfillmentSortKey>('nodeName');
  const [fulfillmentSortDirection, setFulfillmentSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentMultiSort, setFulfillmentMultiSort] = useState(false);
  const [syncStatus, setSyncStatus] = useState<ActionStatus | null>(null);
  const [syncReceiptOpen, setSyncReceiptOpen] = useState(false);
  const [syncTarget, setSyncTarget] = useState<Fulfillment | null>(null);
  const normalizedSearch = globalSearch.trim().toLowerCase();
  const orderLines = useMemo(() => getOrderLines(order), [order.releases]);

  const releaseRows = useMemo<ReleaseTableRow[]>(() => orderLines.flatMap((line) => {
    const lineReleases = order.releases.filter((release) => release.orderLineId === line.lineNumber);
    return lineReleases.length
      ? lineReleases.map((release) => ({ id: release.releaseLineId, line, release }))
      : [{ id: `line-${line.lineNumber}`, line }];
  }), [orderLines, order.releases]);

  const filteredReleaseRows = useMemo(() => {
    if (!normalizedSearch) return releaseRows;
    return releaseRows.filter(({ line, release }) => [
      line.lineNumber,
      line.sku,
      line.productName,
      line.currentStatus,
      line.orderedQty,
      line.lineTotal,
      release?.releaseNumber ?? '',
      release?.releaseLineId ?? '',
      release?.orderLineId ?? '',
      release?.itemId ?? '',
      release?.fulfillmentMethod ?? '',
      release?.assignedNode ?? '',
      release?.assignedNodeType ?? '',
      release?.releaseDate ?? '',
      release?.updatedDate ?? '',
      release?.quantity ?? '',
      release?.fulfilledQty ?? '',
      release?.cancelledQty ?? ''
    ].join(' ').toLowerCase().includes(normalizedSearch));
  }, [normalizedSearch, releaseRows]);

  const sortedReleaseRows = useMemo(() => [...filteredReleaseRows].sort((left, right) => {
    const leftValue = getReleaseSortValue(left, releaseSortKey);
    const rightValue = getReleaseSortValue(right, releaseSortKey);
    const result = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { numeric: true, sensitivity: 'base' });
    return releaseSortDirection === 'asc' ? result : -result;
  }), [filteredReleaseRows, releaseSortDirection, releaseSortKey]);

  const filteredFulfillmentRows = useMemo(() => {
    if (!normalizedSearch) return order.fulfillments;
    return order.fulfillments.filter((release) => [
      release.fulfillmentId,
      release.type,
      release.nodeName,
      release.status,
      release.releaseNumber,
      release.releaseLineId,
      release.packageId,
      release.packageDetailId,
      release.shipmentId,
      release.quantity,
      getFulfillmentShippedQty(release, order.releases),
      release.shipVia,
      release.trackingNumber,
      release.createdDate ?? '',
      release.updatedDate ?? ''
    ].join(' ').toLowerCase().includes(normalizedSearch));
  }, [normalizedSearch, order.fulfillments, order.releases]);

  const sortedFulfillmentRows = useMemo(() => [...filteredFulfillmentRows].sort((first, second) => {
    const compareValues = (sortKey: FulfillmentSortKey) => {
      const firstValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(first, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(first, order.releases)
          : getFulfillmentSortValue(first, sortKey);
      const secondValue = sortKey === 'shippedQty'
        ? getFulfillmentShippedQty(second, order.releases)
        : sortKey === 'cancelledQty'
          ? getFulfillmentCancelledQty(second, order.releases)
          : getFulfillmentSortValue(second, sortKey);
      return typeof firstValue === 'number' && typeof secondValue === 'number'
        ? firstValue - secondValue
        : String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: 'base' });
    };
    const result = fulfillmentMultiSort
      ? (compareValues('type') || compareValues('nodeName') || compareValues('status') || compareValues('releaseNumber'))
      : compareValues(fulfillmentSortKey);
    return fulfillmentSortDirection === 'asc' ? result : -result;
  }), [filteredFulfillmentRows, fulfillmentMultiSort, fulfillmentSortDirection, fulfillmentSortKey, order.releases]);

  const locations = useMemo(() => {
    const grouped = new Set(order.fulfillments.map((release) => `${release.type}-${release.nodeId}`));
    return grouped.size;
  }, [order.fulfillments]);
  const orderedUnits = orderLines.reduce((total, line) => total + line.orderedQty, 0);
  const lineAmount = orderLines.reduce((total, line) => total + line.lineTotal, 0);
  const fulfillmentQuantity = order.fulfillments.reduce((total, release) => total + release.quantity, 0);
  const activeShipments = order.fulfillments.filter((release) => release.trackingNumber !== 'Pending' && release.status !== 'Cancelled').length;
  const fulfillmentExceptions = order.fulfillments.filter((release) => release.status === 'Cancelled' || release.status.includes('Awaiting')).length;
  const filteredLineCount = new Set(filteredReleaseRows.map((row) => row.line.lineNumber)).size;
  const filteredReleaseCount = filteredReleaseRows.filter((row) => row.release).length;
  const filteredFulfillmentLocationCount = new Set(filteredFulfillmentRows.map((release) => `${release.type}-${release.nodeId}`)).size;
  const releasePageCount = Math.max(1, Math.ceil(sortedReleaseRows.length / popupPageSize));
  const fulfillmentPageCount = Math.max(1, Math.ceil(sortedFulfillmentRows.length / popupPageSize));
  const activeReleasePage = Math.min(releasePage, releasePageCount);
  const activeFulfillmentPage = Math.min(fulfillmentPage, fulfillmentPageCount);
  const pagedReleaseRows = sortedReleaseRows.slice((activeReleasePage - 1) * popupPageSize, activeReleasePage * popupPageSize);
  const pagedFulfillmentRows = sortedFulfillmentRows.slice((activeFulfillmentPage - 1) * popupPageSize, activeFulfillmentPage * popupPageSize);

  const closeWorkbench = () => {
    setWorkbenchOpen(false);
    setGlobalSearch('');
    setReleasePage(1);
    setFulfillmentPage(1);
  };

  const openWorkbench = () => {
    setWorkbenchOpen(true);
    setReleasePage(1);
    setFulfillmentPage(1);
  };

  const handleReleaseSort = (sortKey: ReleaseSortKey) => {
    setReleasePage(1);
    setReleaseSortDirection((currentDirection) => releaseSortKey === sortKey && currentDirection === 'asc' ? 'desc' : 'asc');
    setReleaseSortKey(sortKey);
  };

  const handleFulfillmentSort = (sortKey: FulfillmentSortKey) => {
    setFulfillmentMultiSort(false);
    setFulfillmentPage(1);
    if (fulfillmentSortKey === sortKey) {
      setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    } else {
      setFulfillmentSortKey(sortKey);
      setFulfillmentSortDirection('asc');
    }
  };

  const goBackToWorkbench = () => {
    setSyncTarget(null);
    setWorkbenchOpen(true);
  };

  const confirmSync = async () => {
    if (!syncTarget) return;
    const target = syncTarget;
    let nextStatus: ActionStatus;
    try {
      const response = await omsApi.syncFulfillment(target.fulfillmentId);
      nextStatus = {
        severity: 'success',
        message: `${target.releaseNumber}: Fulfillment sync requested. Status sync queued for ${response.fulfillmentId}.`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The fulfillment sync could not be submitted.'
      };
    } finally {
      setSyncTarget(null);
      setSyncStatus(null);
      setSyncReceiptOpen(false);
      window.setTimeout(() => {
        setSyncStatus(nextStatus);
        setSyncReceiptOpen(true);
      }, 120);
    }
  };

  return (
    <Box sx={{ mt: 1.15 }}>
      <GlassCard sx={{ p: { xs: 1, md: 1.15 }, overflow: 'hidden', borderColor: (theme) => alpha(theme.palette.primary.main, 0.28), bgcolor: 'background.paper' }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={0.9} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} sx={{ mb: 0.85 }}>
          <Box>
            <Typography variant="subtitle2" fontWeight={950}>Order & Fulfillment Details</Typography>
            <Typography variant="caption" color="text.secondary">Line releases and node execution status in one operational view</Typography>
          </Box>
          <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap alignItems="center">
            <Chip size="small" label={`${orderLines.length} order lines`} color="primary" variant="outlined" />
            <Chip size="small" label={`${order.releases.length} releases`} variant="outlined" />
            <Chip size="small" label={`${order.fulfillments.length} node rows`} variant="outlined" />
            <Button size="small" variant="contained" startIcon={<OpenInNewIcon />} onClick={openWorkbench} sx={{ minHeight: 30, fontWeight: 950 }}>
              Open Details
            </Button>
          </Stack>
        </Stack>
        <Stack spacing={0.75}>
          <Box sx={{ overflow: 'hidden', border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.24), borderRadius: 1.5, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.035) }}>
            <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(4, minmax(0, 1fr))' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center', p: { xs: 1, md: 1.1 } }}>
              <AggregateMetric label="Order Lines" value={String(orderLines.length)} />
              <AggregateMetric label="Ordered Units" value={String(orderedUnits)} />
              <AggregateMetric label="Releases" value={String(order.releases.length)} />
              <AggregateMetric label="Line Amount" value={formatCurrency(lineAmount)} />
            </Box>
          </Box>

          <Box sx={{ overflow: 'hidden', border: 1, borderColor: (theme) => alpha(theme.palette.secondary.main, 0.24), borderRadius: 1.5, bgcolor: (theme) => alpha(theme.palette.secondary.main, 0.035) }}>
            <Box sx={{ px: { xs: 1, md: 1.1 }, pt: 0.85, pb: 0.15, borderBottom: 1, borderColor: (theme) => alpha(theme.palette.secondary.main, 0.16) }}>
              <Typography variant="caption" fontWeight={950} color="text.secondary">Fulfillment Nodes</Typography>
            </Box>
            <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(5, minmax(0, 1fr))' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center', px: { xs: 1, md: 1.1 }, pt: 0.75, pb: { xs: 1, md: 1.1 } }}>
              <AggregateMetric label="Locations" value={String(locations)} />
              <AggregateMetric label="Node Records" value={String(order.fulfillments.length)} />
              <AggregateMetric label="Total Quantity" value={String(fulfillmentQuantity)} />
              <AggregateMetric label="Active Shipments" value={String(activeShipments)} />
              <AggregateMetric label="Exceptions" value={String(fulfillmentExceptions)} alert={fulfillmentExceptions > 0} />
            </Box>
          </Box>
        </Stack>
      </GlassCard>

      <Dialog
        open={workbenchOpen}
        onClose={closeWorkbench}
        fullWidth
        maxWidth={false}
        aria-labelledby={`customer-order-workbench-${order.orderNumber}`}
        PaperProps={{
          sx: {
            m: { xs: 1.5, md: 2 },
            width: { xs: 'calc(100vw - 24px)', md: 'calc(100vw - 32px)' },
            maxWidth: '1780px',
            height: 'auto',
            maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 48px)' },
            overflow: 'hidden',
            borderRadius: { xs: 2, md: 3 },
            border: 1,
            borderColor: (theme) => alpha(theme.palette.primary.main, 0.28),
            backgroundColor: 'background.paper',
            backgroundImage: (theme) => theme.palette.mode === 'light'
              ? 'linear-gradient(145deg, #f8fafc 0%, #eef2f6 46%, #ffffff 100%)'
              : 'linear-gradient(145deg, #202733 0%, #171d27 54%, #1a1f28 100%)',
            boxShadow: '0 24px 74px rgba(15,23,42,.28)'
          }
        }}
      >
        <DialogTitle id={`customer-order-workbench-${order.orderNumber}`} sx={{ position: 'relative', pr: 7, px: { xs: 2, md: 3 }, py: 2.1, bgcolor: 'background.paper', borderBottom: 1, borderColor: 'divider' }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Box sx={{ width: 42, height: 42, borderRadius: 1.75, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1), border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.22) }}>
              <ReceiptLongOutlinedIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" sx={{ fontWeight: 950, letterSpacing: 0 }}>Order Lines & Fulfillment Node Status</Typography>
              <Typography variant="body2" color="text.secondary">{order.orderNumber} · {orderLines.length} total order lines · {filteredLineCount} matching lines · {filteredReleaseCount} of {order.releases.length} releases · {filteredFulfillmentLocationCount} of {locations} nodes</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close order workbench" onClick={closeWorkbench} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: 'background.default', overflowY: 'auto' }}>
          <Box sx={{ position: 'sticky', top: 0, zIndex: 3, mb: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper', backdropFilter: 'none', boxShadow: '0 10px 24px rgba(15,23,42,.06)' }}>
            <TextField
              fullWidth
              size="small"
              label="Global search across order lines and fulfillment node status"
              value={globalSearch}
              onChange={(event) => {
                setGlobalSearch(event.target.value);
                setReleasePage(1);
                setFulfillmentPage(1);
              }}
              placeholder="Search line, item, release, node, package, shipment, status, tracking"
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                sx: {
                  borderRadius: 1.75,
                  bgcolor: (theme) => theme.palette.mode === 'light' ? '#ffffff' : alpha(theme.palette.common.white, 0.06),
                  boxShadow: '0 8px 22px rgba(15,23,42,.06)'
                }
              }}
            />
          </Box>

          <Stack spacing={2}>
            <Box>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1 }}>
                <Box>
                  <Typography variant="subtitle1" fontWeight={950}>Order Lines & Release Lines</Typography>
                  <Typography variant="body2" color="text.secondary">{sortedReleaseRows.length} matching table rows · {popupPageSize} rows per page</Typography>
                </Box>
                <Chip label="Sortable release table" color="primary" variant="outlined" sx={{ fontWeight: 900 }} />
              </Stack>
              <ReleaseLinesTable rows={pagedReleaseRows} sortKey={releaseSortKey} sortDirection={releaseSortDirection} onSort={handleReleaseSort} />
              {!filteredReleaseRows.length && <Alert severity="info" sx={{ mt: 1.25 }}>No order lines or releases match this search.</Alert>}
              {sortedReleaseRows.length > popupPageSize && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ mt: 1.25, px: 1.5, py: 1.15, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.96) }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {(activeReleasePage - 1) * popupPageSize + 1}-{Math.min(activeReleasePage * popupPageSize, sortedReleaseRows.length)} of {sortedReleaseRows.length} matching release rows
                  </Typography>
                  <Pagination count={releasePageCount} page={activeReleasePage} onChange={(_, value) => setReleasePage(value)} color="primary" size="small" />
                </Stack>
              )}
            </Box>

            <Divider />

            <Box>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1 }}>
                <Box>
                  <Typography variant="subtitle1" fontWeight={950}>Fulfillment Node Status</Typography>
                  <Typography variant="body2" color="text.secondary">{sortedFulfillmentRows.length} matching node status rows · {popupPageSize} rows per page</Typography>
                </Box>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                  <Button
                    variant="outlined"
                    startIcon={<TuneIcon />}
                    onClick={() => {
                      if (fulfillmentSortKey === 'nodeName') {
                        setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
                      } else {
                        setFulfillmentSortKey('nodeName');
                        setFulfillmentSortDirection('asc');
                      }
                      setFulfillmentPage(1);
                    }}
                    sx={{ borderRadius: 1.75, fontWeight: 900, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}
                  >
                    Sort by Location
                  </Button>
                  <Button
                    variant={fulfillmentMultiSort ? 'contained' : 'outlined'}
                    startIcon={<TuneIcon />}
                    onClick={() => {
                      setFulfillmentMultiSort((current) => !current);
                      setFulfillmentPage(1);
                    }}
                    sx={{ borderRadius: 1.75, fontWeight: 900 }}
                  >
                    Multi-sort {fulfillmentMultiSort ? 'On' : 'Off'}
                  </Button>
                </Stack>
              </Stack>
              <FulfillmentLinesTable
                rows={pagedFulfillmentRows}
                sortKey={fulfillmentSortKey}
                sortDirection={fulfillmentSortDirection}
                onSort={handleFulfillmentSort}
                onSync={setSyncTarget}
                releases={order.releases}
                multiSort={fulfillmentMultiSort}
              />
              {!filteredFulfillmentRows.length && <Alert severity="info" sx={{ mt: 1.25 }}>No fulfillment node status records match this search.</Alert>}
              {sortedFulfillmentRows.length > popupPageSize && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ mt: 1.25, px: 1.5, py: 1.15, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.96) }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {(activeFulfillmentPage - 1) * popupPageSize + 1}-{Math.min(activeFulfillmentPage * popupPageSize, sortedFulfillmentRows.length)} of {sortedFulfillmentRows.length} matching fulfillment rows
                  </Typography>
                  <Pagination count={fulfillmentPageCount} page={activeFulfillmentPage} onChange={(_, value) => setFulfillmentPage(value)} color="primary" size="small" />
                </Stack>
              )}
            </Box>
          </Stack>
        </DialogContent>
      </Dialog>

      <ActionConfirmationDialog
        open={Boolean(syncTarget)}
        title="Sync this release status?"
        eyebrow="Fulfillment Synchronization"
        description="The latest package and shipment status will be synchronized to this release line only."
        confirmLabel="Confirm Sync"
        tone="info"
        icon={<SyncIcon />}
        details={syncTarget ? [
          ['Release ID', syncTarget.releaseNumber],
          ['Rel Line Id', syncTarget.releaseLineId],
          ['Fulfillment Location', syncTarget.nodeName],
          ['Current Status', syncTarget.status]
        ] : []}
        onClose={goBackToWorkbench}
        onConfirm={confirmSync}
      />
      <Dialog
        open={Boolean(syncStatus) && syncReceiptOpen}
        onClose={() => setSyncReceiptOpen(false)}
        maxWidth={false}
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', sm: 440 },
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: syncStatus?.severity === 'success' ? '#16a064' : syncStatus?.severity === 'error' ? '#d22f3a' : '#1769e0',
            boxShadow: '0 28px 80px rgba(15,23,42,.34)'
          }
        }}
      >
        <Box sx={{ px: 2.35, py: 2.1, background: syncStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : syncStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.35} alignItems="flex-start">
            <Box sx={{ width: 42, height: 42, flex: '0 0 auto', borderRadius: 1.75, display: 'grid', placeItems: 'center', color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8', bgcolor: 'rgba(255,255,255,.72)', border: '1px solid rgba(17,24,39,.08)' }}>
              <SyncIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" fontWeight={950} sx={{ color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
                Fulfillment Synchronization
              </Typography>
              <Typography variant="h6" fontWeight={950} color="text.primary" sx={{ mt: 0.2 }}>
                {syncStatus?.severity === 'success' ? 'Sync request submitted' : 'Sync request needs attention'}
              </Typography>
              <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
                {syncStatus?.message}
              </Typography>
            </Box>
          </Stack>
        </Box>
        <DialogActions sx={{ px: 2.35, py: 1.55, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={() => setSyncReceiptOpen(false)} sx={{ minWidth: 150 }}>
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

type ConfirmationTone = 'info' | 'warning' | 'error';
type ActionStatus = { message: string; severity: 'success' | 'error' | 'info' };
type FulfillmentAiInsight = {
  key: string;
  label: string;
  title: string;
  summary: string;
  findings: string[];
  recommendation: string;
  tone: ConfirmationTone;
};
type FulfillmentLocationGroup = { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] };

function ActionConfirmationDialog({
  open,
  title,
  eyebrow,
  description,
  confirmLabel,
  tone,
  icon,
  details,
  onClose,
  onConfirm
}: {
  open: boolean;
  title: string;
  eyebrow: string;
  description: string;
  confirmLabel: string;
  tone: ConfirmationTone;
  icon: ReactNode;
  details: Array<[string, string]>;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      aria-labelledby="action-confirmation-title"
      sx={{ zIndex: (theme) => theme.zIndex.modal + 120 }}
      PaperProps={{
        sx: {
          overflow: 'hidden',
          borderRadius: 2,
          width: { xs: 'calc(100vw - 28px)', sm: 520 },
          border: 1,
          borderColor: (theme) => alpha(theme.palette[tone].main, 0.34),
          bgcolor: 'background.paper',
          color: 'text.primary',
          boxShadow: (theme) => `0 28px 70px ${alpha(theme.palette.common.black, 0.28)}`
        }
      }}
    >
      <Box sx={{ px: 2.4, pt: 2.35, pb: 2, background: (theme) => theme.palette.mode === 'light' ? `linear-gradient(120deg, ${alpha(theme.palette[tone].main, 0.18)}, #ffffff 68%)` : `linear-gradient(120deg, ${alpha(theme.palette[tone].main, 0.24)}, #151b25 72%)` }}>
        <Stack direction="row" spacing={1.35} alignItems="flex-start">
          <Box sx={{ width: 42, height: 42, flex: '0 0 auto', borderRadius: 1.7, display: 'grid', placeItems: 'center', color: `${tone}.main`, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.13), border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), '& svg': { fontSize: 23 } }}>
            {icon}
          </Box>
          <Box sx={{ minWidth: 0, pt: 0.2 }}>
            <Typography variant="overline" fontWeight={900} color={`${tone}.main`}>{eyebrow}</Typography>
            <DialogTitle id="action-confirmation-title" sx={{ p: 0, mt: 0.2, fontSize: '1.15rem', fontWeight: 900, color: 'text.primary' }}>{title}</DialogTitle>
            <Typography color="text.primary" variant="body2" sx={{ mt: 0.65, opacity: 0.78 }}>{description}</Typography>
          </Box>
        </Stack>
      </Box>
      <DialogContent sx={{ px: 2.4, py: 2 }}>
        <Grid container spacing={1}>
          {details.map(([label, value]) => (
            <Grid item xs={12} sm={6} key={label}>
              <Box sx={{ px: 1.25, py: 1, minHeight: 58, borderRadius: 1.35, bgcolor: (theme) => theme.palette.mode === 'light' ? alpha(theme.palette[tone].main, 0.065) : alpha(theme.palette[tone].main, 0.16), border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.24), color: 'text.primary' }}>
                <Typography variant="caption" color="text.secondary">{label}</Typography>
                <Typography fontWeight={900} sx={{ overflowWrap: 'anywhere' }}>{value}</Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
        <Alert severity={tone} icon={<WarningAmberRoundedIcon />} variant="outlined" sx={{ mt: 2, bgcolor: (theme) => theme.palette.mode === 'light' ? alpha(theme.palette[tone].main, 0.045) : alpha(theme.palette[tone].main, 0.14), color: 'text.primary', '& .MuiAlert-icon': { color: `${tone}.main` } }}>
          Review these details before confirming. This operation will be recorded in the order activity history.
        </Alert>
      </DialogContent>
      <DialogActions sx={{ px: 2.4, py: 1.6, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
        <Button onClick={onClose} color="inherit">Go Back</Button>
        <Button variant="contained" color={tone} startIcon={icon} onClick={onConfirm} sx={{ minWidth: 150, boxShadow: (theme) => `0 7px 18px ${alpha(theme.palette[tone].main, 0.26)}` }}>
          {confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function ReleaseLinesTable({
  rows,
  sortKey,
  sortDirection,
  onSort,
  columnFilters,
  onColumnFilterChange
}: {
  rows: ReleaseTableRow[];
  sortKey: ReleaseSortKey;
  sortDirection: SortDirection;
  onSort: (sortKey: ReleaseSortKey) => void;
  columnFilters?: Partial<Record<ReleaseSortKey, string>>;
  onColumnFilterChange?: (key: ReleaseSortKey, value: string) => void;
}) {
  const [actionAnchor, setActionAnchor] = useState<HTMLElement | null>(null);
  const [activeRelease, setActiveRelease] = useState<Release | null>(null);
  const [actionStatus, setActionStatus] = useState<ActionStatus | null>(null);
  const [actionReceiptOpen, setActionReceiptOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<null | {
    release: Release;
    kind: 'rerelease' | 'rerouteWithDn' | 'rerouteWithoutDn' | 'hardCancel';
    title: string;
    description: string;
    confirmLabel: string;
    tone: ConfirmationTone;
    icon: ReactNode;
    outcome: string;
  }>(null);

  const columns: Array<{ key: ReleaseSortKey; label: string; width?: number }> = [
    { key: 'lineNumber', label: 'Line', width: 58 },
    { key: 'sku', label: 'Item ID', width: 82 },
    { key: 'productName', label: 'Item Description', width: 154 },
    { key: 'lineStatus', label: 'Line Status', width: 106 },
    { key: 'orderedQty', label: 'Ordered Qty', width: 74 },
    { key: 'lineTotal', label: 'Line Total', width: 92 },
    { key: 'releaseNumber', label: 'Release ID', width: 112 },
    { key: 'releaseLineId', label: 'Rel Line Id', width: 68 },
    { key: 'quantity', label: 'Qty', width: 54 },
    { key: 'fulfilledQty', label: 'Ful Qty', width: 58 },
    { key: 'cancelledQty', label: 'Cxl Qty', width: 58 },
    { key: 'assignedNode', label: 'Ship From', width: 104 },
    { key: 'assignedNodeType', label: 'Node Type', width: 76 },
    { key: 'releaseDate', label: 'Created', width: 78 },
    { key: 'updatedDate', label: 'Updated', width: 86 },
    { key: 'fulfillmentMethod', label: 'Method', width: 102 }
  ];

  const openReleaseActions = (event: ReactMouseEvent<HTMLButtonElement>, release: Release) => {
    setActionAnchor(event.currentTarget);
    setActiveRelease(release);
  };

  const closeReleaseActions = () => {
    setActionAnchor(null);
    setActiveRelease(null);
  };

  const requestReleaseAction = (kind: 'rerelease' | 'rerouteWithDn' | 'rerouteWithoutDn' | 'hardCancel') => {
    if (!activeRelease) return;
    const release = activeRelease;
    const action = kind === 'rerelease'
      ? {
          title: 'Re-release to fulfillment node?',
          description: 'This will create a new release attempt and resend the release payload to the assigned fulfillment node.',
          confirmLabel: 'Confirm Re-release',
          tone: 'info' as const,
          icon: <RestartAltIcon />,
          outcome: `re-release queued to ${release.assignedNode}.`
        }
      : kind === 'rerouteWithDn' ? {
          title: 'Re-route release with DN?',
          description: 'This will return the release to orchestration, create a delivery note, and select an eligible fulfillment node.',
          confirmLabel: 'Re-route With DN',
          tone: 'warning' as const,
          icon: <AltRouteIcon />,
          outcome: 're-route request with DN queued for orchestration.'
        } : kind === 'rerouteWithoutDn' ? {
          title: 'Re-route release without DN?',
          description: 'This will return the release to orchestration without creating a delivery note.',
          confirmLabel: 'Re-route Without DN',
          tone: 'warning' as const,
          icon: <AltRouteIcon />,
          outcome: 're-route request without DN queued for orchestration.'
        } : {
          title: 'Hard cancel this release?',
          description: 'This will permanently stop release processing and cannot be automatically reversed.',
          confirmLabel: 'Confirm Hard Cancel',
          tone: 'error' as const,
          icon: <BlockIcon />,
          outcome: 'hard cancellation request submitted.'
        };
    setPendingAction({ release, kind, ...action });
    setActionAnchor(null);
    setActiveRelease(null);
  };

  const confirmReleaseAction = async () => {
    if (!pendingAction) return;
    const action = pendingAction;
    let nextStatus: ActionStatus;
    try {
      const response = action.kind === 'rerelease'
        ? await omsApi.rereleaseToFulfillmentNode(action.release.releaseNumber)
        : action.kind === 'rerouteWithDn'
          ? await omsApi.rerouteRelease(action.release.releaseNumber, true)
          : action.kind === 'rerouteWithoutDn'
            ? await omsApi.rerouteRelease(action.release.releaseNumber, false)
            : await omsApi.hardCancelRelease(action.release.releaseNumber);
      nextStatus = {
        severity: 'success',
        message: `${response.releaseId}: ${response.status}. ${action.outcome}`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The release command could not be submitted.'
      };
    } finally {
      setPendingAction(null);
      setActionStatus(null);
      setActionReceiptOpen(false);
      window.setTimeout(() => {
        setActionStatus(nextStatus);
        setActionReceiptOpen(true);
      }, 120);
    }
  };

  return (
    <Box
      sx={{
        overflow: 'hidden',
        border: 1,
        borderColor: (theme) => alpha(theme.palette.primary.main, 0.26),
        borderRadius: 2.5,
        bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#ffffff', 0.94) : alpha(theme.palette.background.paper, 0.9),
        boxShadow: '0 18px 42px rgba(15,23,42,.13)',
        backdropFilter: 'blur(18px)'
      }}
    >
      <Box sx={{ overflowX: 'auto' }}>
        <Table
          size="small"
          sx={{
            width: 'max(100%, 1160px)',
            minWidth: { xs: 1040, md: 1120 },
            tableLayout: 'fixed',
            '& thead th': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(180deg, rgba(246,248,251,.98), rgba(222,229,238,.96))'
                : 'linear-gradient(180deg, rgba(38,45,55,.98), rgba(18,24,32,.98))',
              color: (theme) => theme.palette.mode === 'light' ? '#172033' : '#f7fafc',
              fontSize: '0.72rem',
              fontWeight: 950,
              lineHeight: 1.1,
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
              borderBottom: 1,
              borderBottomColor: (theme) => alpha(theme.palette.primary.main, 0.26),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.62),
              px: 0.62,
              py: 0.58
            },
            '& thead th:last-of-type': { borderRight: 0 },
            '& tbody tr': {
              transition: 'background-color .16s ease, box-shadow .16s ease',
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(247,251,253,.97))'
                : alpha(theme.palette.background.paper, 0.74)
            },
            '& tbody tr:nth-of-type(even)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(232,244,248,.74), rgba(241,248,250,.92))'
                : alpha(theme.palette.primary.main, 0.075)
            },
            '& tbody tr:nth-of-type(odd)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(248,252,253,.98))'
                : alpha(theme.palette.background.paper, 0.8)
            },
            '& tbody tr:hover': {
              background: (theme) => `${theme.palette.mode === 'light' ? 'linear-gradient(90deg, rgba(214,239,245,.96), rgba(238,248,251,.98))' : alpha(theme.palette.primary.main, 0.14)} !important`,
              boxShadow: 'inset 3px 0 0 rgba(17,124,139,.72)'
            },
            '& td': {
              px: 0.62,
              py: 0.54,
              verticalAlign: 'middle',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              overflowWrap: 'anywhere',
              wordBreak: 'break-word',
              borderBottomColor: (theme) => alpha(theme.palette.divider, 0.72),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.42)
            },
            '& td:last-of-type': { borderRight: 0 },
            '& .MuiChip-root': { height: 22, fontSize: '0.68rem', maxWidth: '100%', fontWeight: 850 },
            '& .MuiTableSortLabel-root': { maxWidth: '100%', color: 'inherit' },
            '& .MuiTableSortLabel-root:hover': { color: 'primary.main' },
            '& .MuiTableSortLabel-root.Mui-active': { color: 'primary.main' },
            '& .MuiTableSortLabel-icon': { color: 'primary.main !important', ml: 0.15 },
            '& .release-line-id': {
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              minWidth: 34,
              px: 0.6,
              py: 0.2,
              borderRadius: 1,
              color: '#0d6470',
              bgcolor: 'rgba(17,124,139,.1)',
              border: '1px solid rgba(17,124,139,.22)'
            }
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.key} sortDirection={sortKey === column.key ? sortDirection : false} sx={{ width: column.width }}>
                  <TableSortLabel
                    active={sortKey === column.key}
                    direction={sortKey === column.key ? sortDirection : 'asc'}
                    onClick={() => onSort(column.key)}
                  >
                    {column.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell sx={{ width: 102, fontWeight: 950 }}>Actions</TableCell>
            </TableRow>
            {columnFilters && onColumnFilterChange && (
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={`filter-${column.key}`} sx={{ py: 0.45 }}>
                    <TextField
                      variant="standard"
                      size="small"
                      placeholder="Filter"
                      value={columnFilters[column.key] ?? ''}
                      onChange={(event) => onColumnFilterChange(column.key, event.target.value)}
                      InputProps={{ disableUnderline: true }}
                      inputProps={{ 'aria-label': `Filter ${column.label}` }}
                      sx={{ width: '100%', '& input': { fontSize: '0.67rem', py: 0.25 } }}
                    />
                  </TableCell>
                ))}
                <TableCell />
              </TableRow>
            )}
          </TableHead>
          <TableBody>
            {rows.map(({ id, line, release }) => (
              <TableRow key={`${line.lineNumber}|${release?.releaseNumber ?? 'unreleased'}|${release?.releaseLineId ?? id}`} hover>
                <TableCell sx={{ fontWeight: 950 }} title={line.lineNumber}><Box component="span" className="release-line-id">{line.lineNumber}</Box></TableCell>
                <TableCell sx={{ fontWeight: 850, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={line.sku}>{line.sku}</TableCell>
                <TableCell sx={{ maxWidth: 154 }}>
                  <Tooltip title={line.productName} arrow placement="top">
                    <Typography
                      variant="body2"
                      fontWeight={800}
                      noWrap
                      sx={{ maxWidth: 132, cursor: 'help' }}
                    >
                      {line.productName}
                    </Typography>
                  </Tooltip>
                </TableCell>
                <TableCell><StatusChip label={line.currentStatus} /></TableCell>
                <TableCell sx={{ fontWeight: 900 }}>{line.orderedQty}</TableCell>
                <TableCell sx={{ fontWeight: 900 }}>{formatCurrency(line.lineTotal)}</TableCell>
                <TableCell sx={{ fontWeight: 950 }} title={release?.releaseNumber ?? 'Not released'}>{release?.releaseNumber ?? 'Not released'}</TableCell>
                <TableCell sx={{ fontWeight: 850 }} title={release?.releaseLineId ?? '-'}>{release?.releaseLineId ?? '-'}</TableCell>
                <TableCell sx={{ fontWeight: 850 }}>{release?.quantity ?? '-'}</TableCell>
                <TableCell>{release?.fulfilledQty ?? '-'}</TableCell>
                <TableCell>{release?.cancelledQty ?? '-'}</TableCell>
                <TableCell sx={{ fontWeight: 850 }} title={release?.assignedNode ?? '-'}>{release?.assignedNode ?? '-'}</TableCell>
                <TableCell>{release ? <Chip size="small" label={release.assignedNodeType} variant="outlined" /> : '-'}</TableCell>
                <CompactDateCell value={release?.releaseDate} />
                <CompactDateCell value={release?.updatedDate} />
                <TableCell>{release ? <Chip size="small" label={release.fulfillmentMethod} variant="outlined" /> : '-'}</TableCell>
                <TableCell>
                  <Button
                    className="release-actions-button"
                    size="small"
                    variant="contained"
                    endIcon={<MoreVertIcon />}
                    disabled={!release}
                    onClick={(event) => release && openReleaseActions(event, release)}
                    sx={{
                      minWidth: 86,
                      px: 0.8,
                      fontSize: '0.7rem',
                      color: 'common.white',
                      background: 'linear-gradient(135deg, #0b5963, #168895 55%, #6fb5bd)',
                      border: '1px solid rgba(255,255,255,.42)',
                      boxShadow: '0 6px 16px rgba(17,124,139,.25)',
                      '&:hover': {
                        background: 'linear-gradient(135deg, #084951, #117c8b 55%, #55a5ae)',
                        boxShadow: '0 8px 20px rgba(17,124,139,.34)'
                      },
                      '&.Mui-disabled': {
                        color: 'rgba(15,23,42,.42)',
                        background: 'linear-gradient(135deg, rgba(226,232,240,.8), rgba(203,213,225,.72))',
                        borderColor: 'rgba(148,163,184,.34)'
                      }
                    }}
                  >
                    Actions
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Box>
      <Menu anchorEl={actionAnchor} open={Boolean(actionAnchor)} onClose={closeReleaseActions}>
        <MenuItem onClick={() => requestReleaseAction('rerelease')}>
          <ListItemIcon><RestartAltIcon fontSize="small" color="info" /></ListItemIcon>
          <ListItemText primary="Repush release" />
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => requestReleaseAction('rerouteWithDn')}>
          <ListItemIcon><AltRouteIcon fontSize="small" color="warning" /></ListItemIcon>
          <ListItemText primary="Reroute with DN" />
        </MenuItem>
        <MenuItem onClick={() => requestReleaseAction('rerouteWithoutDn')}>
          <ListItemIcon><AltRouteIcon fontSize="small" color="warning" /></ListItemIcon>
          <ListItemText primary="Reroute w/o DN" />
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => requestReleaseAction('hardCancel')}>
          <ListItemIcon><BlockIcon fontSize="small" color="error" /></ListItemIcon>
          <ListItemText primary="Hard cancel" />
        </MenuItem>
      </Menu>
      <ActionConfirmationDialog
        open={Boolean(pendingAction)}
        title={pendingAction?.title ?? ''}
        eyebrow="Release Command Confirmation"
        description={pendingAction?.description ?? ''}
        confirmLabel={pendingAction?.confirmLabel ?? 'Confirm'}
        tone={pendingAction?.tone ?? 'info'}
        icon={pendingAction?.icon ?? <RestartAltIcon />}
        details={pendingAction ? [
          ['Release ID', pendingAction.release.releaseNumber],
          ['Rel Line Id', pendingAction.release.releaseLineId],
          ['Assigned Node', pendingAction.release.assignedNode],
          ['Delivery Method', pendingAction.release.fulfillmentMethod]
        ] : []}
        onClose={() => setPendingAction(null)}
        onConfirm={confirmReleaseAction}
      />
      <Dialog
        open={Boolean(actionStatus) && actionReceiptOpen}
        onClose={() => setActionReceiptOpen(false)}
        maxWidth={false}
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', sm: 440 },
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: actionStatus?.severity === 'success' ? '#16a064' : actionStatus?.severity === 'error' ? '#d22f3a' : '#1769e0',
            boxShadow: '0 28px 80px rgba(15,23,42,.34)'
          }
        }}
      >
        <Box sx={{ px: 2.35, py: 2.1, background: actionStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : actionStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.35} alignItems="flex-start">
            <Box sx={{ width: 42, height: 42, flex: '0 0 auto', borderRadius: 1.75, display: 'grid', placeItems: 'center', color: actionStatus?.severity === 'success' ? '#087443' : actionStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8', bgcolor: 'rgba(255,255,255,.72)', border: '1px solid rgba(17,24,39,.08)' }}>
              {actionStatus?.severity === 'error' ? <WarningAmberRoundedIcon /> : <RestartAltIcon />}
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" fontWeight={950} sx={{ color: actionStatus?.severity === 'success' ? '#087443' : actionStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
                Release Command
              </Typography>
              <Typography variant="h6" fontWeight={950} color="text.primary" sx={{ mt: 0.2 }}>
                {actionStatus?.severity === 'success' ? 'Release command submitted' : 'Release command needs attention'}
              </Typography>
              <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
                {actionStatus?.message}
              </Typography>
            </Box>
          </Stack>
        </Box>
        <DialogActions sx={{ px: 2.35, py: 1.55, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
          <Button variant="contained" startIcon={<RestartAltIcon />} onClick={() => setActionReceiptOpen(false)} sx={{ minWidth: 150 }}>
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function LineValue({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <Box sx={{ minWidth: 0 }}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Tooltip title={value} arrow placement="top">
        <Typography
          fontWeight={strong ? 900 : 700}
          noWrap
          sx={{ cursor: value.length > 18 ? 'help' : 'default' }}
        >
          {value}
        </Typography>
      </Tooltip>
    </Box>
  );
}

function CompactDateCell({ value }: { value?: string }) {
  const displayValue = compactDateTime(value);
  const tooltipValue = fullTimestamp(value);
  return (
    <TableCell sx={{ whiteSpace: 'nowrap', maxWidth: 86 }}>
      <Tooltip title={tooltipValue} arrow placement="top">
        <Typography
          variant="body2"
          fontWeight={850}
          noWrap
          sx={{ maxWidth: 72, cursor: value ? 'help' : 'default' }}
        >
          {displayValue}
        </Typography>
      </Tooltip>
    </TableCell>
  );
}

function FulfillmentMetric({ label, value, accent, alert = false }: { label: string; value: string; accent: string; alert?: boolean }) {
  return (
    <Box
      sx={{
        minHeight: 48,
        px: 1.15,
        py: 0.75,
        borderRadius: 1.5,
        border: 1,
        borderColor: alpha(accent, alert ? 0.38 : 0.22),
        bgcolor: alpha(accent, alert ? 0.105 : 0.065),
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,.34)'
      }}
    >
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1 }}>{label}</Typography>
      <Typography fontWeight={950} sx={{ color: alert ? 'error.main' : 'text.primary', lineHeight: 1.25 }}>{value}</Typography>
    </Box>
  );
}

function FulfillmentLines({ order }: { order: Order }) {
  const [syncStatus, setSyncStatus] = useState<ActionStatus | null>(null);
  const [syncReceiptOpen, setSyncReceiptOpen] = useState(false);
  const [syncTarget, setSyncTarget] = useState<Fulfillment | null>(null);
  const [activeFulfillmentInsight, setActiveFulfillmentInsight] = useState<FulfillmentAiInsight | null>(null);
  const [allFulfillmentsOpen, setAllFulfillmentsOpen] = useState(false);
  const [fulfillmentSearch, setFulfillmentSearch] = useState('');
  const [fulfillmentPage, setFulfillmentPage] = useState(1);
  const [fulfillmentSortKey, setFulfillmentSortKey] = useState<FulfillmentSortKey>('nodeName');
  const [fulfillmentSortDirection, setFulfillmentSortDirection] = useState<SortDirection>('asc');
  const [fulfillmentMultiSort, setFulfillmentMultiSort] = useState(false);
  const locations = useMemo(() => {
    const grouped = new Map<string, FulfillmentLocationGroup>();
    order.fulfillments.forEach((fulfillment) => {
      const key = `${fulfillment.type}-${fulfillment.nodeId}`;
      const current = grouped.get(key);
      if (current) current.releases.push(fulfillment);
      else grouped.set(key, { type: fulfillment.type, nodeId: fulfillment.nodeId, nodeName: fulfillment.nodeName, releases: [fulfillment] });
    });
    return Array.from(grouped.values());
  }, [order.fulfillments]);
  const fulfillmentQuantity = order.fulfillments.reduce((total, release) => total + release.quantity, 0);
  const activeShipments = order.fulfillments.filter((release) => release.trackingNumber !== 'Pending' && release.status !== 'Cancelled').length;
  const fulfillmentExceptions = order.fulfillments.filter((release) => release.status === 'Cancelled' || release.status.includes('Awaiting')).length;
  const getNodeAiInsights = (location: FulfillmentLocationGroup): FulfillmentAiInsight[] => {
    const stuckNodes = location.releases.filter((release) => release.status.includes('Awaiting') || release.status.includes('Label') || release.trackingNumber === 'Pending').length;
    const activeNodeShipments = location.releases.filter((release) => release.trackingNumber !== 'Pending' && release.status !== 'Cancelled').length;
    const nodeQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
    const nodeReleaseIds = location.releases.map((release) => release.releaseNumber).join(', ');
    return [
      {
        key: `${location.nodeId}-stuck-node`,
        label: 'AI Stuck Node Analysis',
        title: `${location.nodeName} Stuck Node Analysis`,
        summary: `${stuckNodes} of ${location.releases.length} fulfillment records show stuck-risk signals for ${location.nodeId}.`,
        findings: [
          `${location.type} node ${location.nodeName} owns ${nodeQuantity} units across release lines ${nodeReleaseIds}.`,
          `${activeNodeShipments} records already have active shipment or tracking progress.`,
          stuckNodes > 0 ? 'Pending tracking, label, or awaiting status signals need immediate node heartbeat review.' : 'No severe stuck signal is currently visible for this node.'
        ],
        recommendation: `Run sync for stale records at ${location.nodeName}; reroute only the release lines that remain pending after the next node heartbeat.`,
        tone: stuckNodes > 0 ? 'warning' : 'info'
      },
      {
        key: `${location.nodeId}-aging`,
        label: 'AI Release Aging',
        title: `${location.nodeName} Release Aging`,
        summary: `${location.releases.length} node status records were evaluated for SLA aging, shipment event lag, and package progression.`,
        findings: [
          location.type === 'Warehouse' ? 'Warehouse aging checks include acknowledgement, pick-wave creation, pack completion, and manifest events.' : `${location.type} aging checks focus on acknowledgement, fulfillment acceptance, and carrier event creation.`,
          `Latest review covers ${location.releases.length} fulfillment records at ${location.nodeId}.`,
          'Records with pending tracking numbers are treated as higher-risk until carrier movement is visible.'
        ],
        recommendation: `Prioritize ${location.nodeName} records with pending tracking numbers and open package IDs before triggering reroute actions.`,
        tone: 'info'
      },
      {
        key: `${location.nodeId}-reroute`,
        label: 'AI Reroute Advisor',
        title: `${location.nodeName} Reroute Recommendation`,
        summary: `AI evaluated ${location.type.toLowerCase()} alternatives using stuck risk, quantity, release status, and shipment status for this node.`,
        findings: [
          'Re-release is preferred when allocation exists but the node acknowledgement is stale.',
          'Reroute with DN is recommended when customer communication or downstream documents must stay aligned.',
          'Hard cancel should stay limited to release lines with confirmed operational exception or unrecoverable node failure.'
        ],
        recommendation: `Use ${location.nodeName} as the decision point: sync first, reroute next, hard cancel only for unrecoverable exceptions.`,
        tone: 'warning'
      }
    ];
  };
  const normalizedFulfillmentSearch = fulfillmentSearch.trim().toLowerCase();
  const filteredFulfillmentRows = useMemo(() => {
    if (!normalizedFulfillmentSearch) return order.fulfillments;

    return order.fulfillments.filter((release) => [
        release.fulfillmentId,
        release.type,
        release.nodeId,
        release.nodeName,
        release.status,
        release.releaseNumber,
        release.releaseLineId,
        release.packageId,
      release.packageDetailId,
      release.shipmentId,
      release.quantity,
      getFulfillmentCancelledQty(release, order.releases),
      release.shipVia,
        release.trackingNumber
      ].join(' ').toLowerCase().includes(normalizedFulfillmentSearch));
  }, [normalizedFulfillmentSearch, order.fulfillments]);
  const filteredFulfillmentCount = filteredFulfillmentRows.length;
  const filteredFulfillmentLocationCount = new Set(filteredFulfillmentRows.map((release) => `${release.type}-${release.nodeId}`)).size;
  const sortedFulfillmentRows = useMemo(() => {
    return [...filteredFulfillmentRows].sort((first, second) => {
      const compareValues = (sortKey: FulfillmentSortKey) => {
        const firstValue = sortKey === 'shippedQty'
          ? getFulfillmentShippedQty(first, order.releases)
          : sortKey === 'cancelledQty'
            ? getFulfillmentCancelledQty(first, order.releases)
            : getFulfillmentSortValue(first, sortKey);
        const secondValue = sortKey === 'shippedQty'
          ? getFulfillmentShippedQty(second, order.releases)
          : sortKey === 'cancelledQty'
            ? getFulfillmentCancelledQty(second, order.releases)
            : getFulfillmentSortValue(second, sortKey);
        return typeof firstValue === 'number' && typeof secondValue === 'number'
          ? firstValue - secondValue
          : String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: 'base' });
      };
      const result = fulfillmentMultiSort
        ? (compareValues('type') || compareValues('nodeName') || compareValues('status') || compareValues('releaseNumber'))
        : compareValues(fulfillmentSortKey);
      return fulfillmentSortDirection === 'asc' ? result : -result;
    });
  }, [filteredFulfillmentRows, fulfillmentMultiSort, fulfillmentSortDirection, fulfillmentSortKey, order.releases]);
  const fulfillmentPageCount = Math.max(1, Math.ceil(sortedFulfillmentRows.length / popupPageSize));
  const pagedFulfillmentRows = sortedFulfillmentRows.slice((fulfillmentPage - 1) * popupPageSize, fulfillmentPage * popupPageSize);

  const closeAllFulfillments = () => {
    setAllFulfillmentsOpen(false);
    setFulfillmentSearch('');
    setFulfillmentPage(1);
  };

  const goBackToFulfillmentPopup = () => {
    setSyncTarget(null);
    setAllFulfillmentsOpen(true);
  };

  const handleFulfillmentSort = (sortKey: FulfillmentSortKey) => {
    setFulfillmentMultiSort(false);
    if (fulfillmentSortKey === sortKey) {
      setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    } else {
      setFulfillmentSortKey(sortKey);
      setFulfillmentSortDirection('asc');
    }
    setFulfillmentPage(1);
  };

  const confirmSync = async () => {
    if (!syncTarget) return;
    const target = syncTarget;
    let nextStatus: ActionStatus;
    try {
      const response = await omsApi.syncFulfillment(target.fulfillmentId);
      nextStatus = {
        severity: 'success',
        message: `${target.releaseNumber}: Fulfillment sync requested. Status sync queued for ${response.fulfillmentId}.`
      };
    } catch (requestError) {
      nextStatus = {
        severity: 'error',
        message: requestError instanceof Error ? requestError.message : 'The fulfillment sync could not be submitted.'
      };
    } finally {
      setSyncTarget(null);
      setSyncStatus(null);
      setSyncReceiptOpen(false);
      window.setTimeout(() => {
        setSyncStatus(nextStatus);
        setSyncReceiptOpen(true);
      }, 120);
    }
  };
  return (
    <Box>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', sm: 'center' }} gap={0.75} sx={{ mb: 0.75 }}>
        <Box>
          <Typography variant="subtitle2" fontWeight={950}>Fulfillment Node Status</Typography>
          <Typography variant="caption" color="text.secondary">Actual node-level execution status by warehouse, store, dropship, or supplier location</Typography>
        </Box>
        <Chip size="small" label={`${order.fulfillments.length} releases`} variant="outlined" />
      </Stack>
      <GlassCard sx={{ mb: 0.75, overflow: 'hidden', borderColor: (theme) => alpha(theme.palette.primary.main, 0.3), bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
        <ButtonBase aria-label="Open all fulfillment releases" onClick={() => setAllFulfillmentsOpen(true)} sx={{ width: '100%', p: { xs: 1, md: 1.1 }, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(5, minmax(0, 1fr)) 28px' }, gap: { xs: 0.75, md: 1 }, alignItems: 'center' }}>
            <AggregateMetric label="Locations" value={String(locations.length)} />
            <AggregateMetric label="Node Records" value={String(order.fulfillments.length)} />
            <AggregateMetric label="Total Quantity" value={String(fulfillmentQuantity)} />
            <AggregateMetric label="Active Shipments" value={String(activeShipments)} />
            <AggregateMetric label="Exceptions" value={String(fulfillmentExceptions)} alert={fulfillmentExceptions > 0} />
            <OpenInNewIcon color="primary" />
          </Box>
        </ButtonBase>
      </GlassCard>
      {showFulfillmentNodeAi && (
        <Grid container spacing={1.1} sx={{ mb: 0.75 }}>
          {locations.map((location) => (
            <Grid item xs={12} xl={6} key={`${location.type}-${location.nodeId}`}>
              <FulfillmentNodeAiCard
                location={location}
                insights={getNodeAiInsights(location)}
                onOpen={setActiveFulfillmentInsight}
              />
            </Grid>
          ))}
        </Grid>
      )}
      <Dialog
        open={allFulfillmentsOpen}
        onClose={closeAllFulfillments}
        fullWidth
        maxWidth={false}
        aria-labelledby={`all-fulfillments-${order.orderNumber}`}
        PaperProps={{
          sx: {
            m: { xs: 1.5, md: 2 },
            width: { xs: 'calc(100vw - 24px)', md: 'calc(100vw - 32px)' },
            maxWidth: '1760px',
            height: 'auto',
            maxHeight: { xs: 'calc(100vh - 24px)', md: 'calc(100vh - 48px)' },
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: (theme) => alpha(theme.palette.primary.main, 0.28),
            background: (theme) => theme.palette.mode === 'light'
              ? `linear-gradient(145deg, ${alpha(theme.palette.background.default, 0.7)}, ${alpha(theme.palette.primary.main, 0.055)} 44%, ${alpha(theme.palette.background.paper, 0.98)} 100%)`
              : `linear-gradient(145deg, ${alpha(theme.palette.background.default, 0.84)}, ${alpha(theme.palette.primary.main, 0.12)} 48%, ${alpha(theme.palette.background.paper, 0.92)} 100%)`,
            boxShadow: '0 24px 74px rgba(15,23,42,.28)'
          }
        }}
      >
        <DialogTitle
          id={`all-fulfillments-${order.orderNumber}`}
          sx={{
            position: 'relative',
            pr: 7,
            px: { xs: 2, md: 3 },
            py: 2.15,
            bgcolor: 'background.paper',
            borderBottom: 1,
            borderColor: 'divider'
          }}
        >
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Box sx={{ width: 42, height: 42, borderRadius: 1.75, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1), border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.22) }}>
              <LocalShippingIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" sx={{ fontWeight: 950, letterSpacing: 0 }}>Fulfillment Node Status & Releases</Typography>
              <Typography variant="body2" color="text.secondary">{order.orderNumber} · {filteredFulfillmentLocationCount} of {locations.length} nodes · {filteredFulfillmentCount} of {order.fulfillments.length} node status records · {sortedFulfillmentRows.length} table rows</Typography>
            </Box>
          </Stack>
          <IconButton aria-label="Close all fulfillment releases" onClick={closeAllFulfillments} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: { xs: 1.5, md: 2 }, bgcolor: 'background.default', overflowY: 'auto' }}>
          <Box sx={{ position: 'sticky', top: 0, zIndex: 2, mb: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper', backdropFilter: 'none', boxShadow: '0 10px 24px rgba(15,23,42,.06)' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
              <TextField
                fullWidth
                size="small"
                label="Search fulfillment node status"
                value={fulfillmentSearch}
                onChange={(event) => {
                  setFulfillmentSearch(event.target.value);
                  setFulfillmentPage(1);
                }}
                placeholder="Search node, release, package, shipment, status, tracking"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                  sx: {
                    borderRadius: 1.75,
                    bgcolor: (theme) => theme.palette.mode === 'light' ? '#ffffff' : alpha(theme.palette.common.white, 0.06),
                    boxShadow: '0 8px 22px rgba(15,23,42,.06)'
                  }
                }}
              />
              <Button
                variant="outlined"
                startIcon={<TuneIcon />}
                onClick={() => {
                  if (fulfillmentSortKey === 'nodeName') {
                    setFulfillmentSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
                  } else {
                    setFulfillmentSortKey('nodeName');
                    setFulfillmentSortDirection('asc');
                  }
                  setFulfillmentPage(1);
                }}
                sx={{ minWidth: 154, borderRadius: 1.75, fontWeight: 900, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}
              >
                Sort by Location
              </Button>
              <Button
                variant={fulfillmentMultiSort ? 'contained' : 'outlined'}
                startIcon={<TuneIcon />}
                onClick={() => {
                  setFulfillmentMultiSort((current) => !current);
                  setFulfillmentPage(1);
                }}
                sx={{ minWidth: 132, borderRadius: 1.75, fontWeight: 900 }}
              >
                Multi-sort {fulfillmentMultiSort ? 'On' : 'Off'}
              </Button>
            </Stack>
          </Box>
          <Box>
            <FulfillmentLinesTable
              rows={pagedFulfillmentRows}
              sortKey={fulfillmentSortKey}
              sortDirection={fulfillmentSortDirection}
              onSort={handleFulfillmentSort}
              onSync={setSyncTarget}
              releases={order.releases}
              multiSort={fulfillmentMultiSort}
            />
          </Box>
          {!filteredFulfillmentRows.length && <Alert severity="info" sx={{ m: 2 }}>No fulfillment node status records match this popup search.</Alert>}
          {sortedFulfillmentRows.length > popupPageSize && (
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.25} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ position: 'sticky', bottom: 0, mt: 1.5, px: 1.5, py: 1.25, border: 1, borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper', backdropFilter: 'none', boxShadow: '0 -10px 24px rgba(15,23,42,.06)' }}>
              <Typography variant="body2" color="text.secondary">
                Showing {(fulfillmentPage - 1) * popupPageSize + 1}-{Math.min(fulfillmentPage * popupPageSize, sortedFulfillmentRows.length)} of {sortedFulfillmentRows.length} matching fulfillment node status records
              </Typography>
              <Pagination count={fulfillmentPageCount} page={fulfillmentPage} onChange={(_, value) => setFulfillmentPage(value)} color="primary" size="small" />
            </Stack>
          )}
        </DialogContent>
      </Dialog>
      <ActionConfirmationDialog
        open={Boolean(syncTarget)}
        title="Sync this release status?"
        eyebrow="Fulfillment Synchronization"
        description="The latest package and shipment status will be synchronized to this release line only."
        confirmLabel="Confirm Sync"
        tone="info"
        icon={<SyncIcon />}
        details={syncTarget ? [
          ['Release ID', syncTarget.releaseNumber],
          ['Rel Line Id', syncTarget.releaseLineId],
          ['Fulfillment Location', syncTarget.nodeName],
          ['Current Status', syncTarget.status]
        ] : []}
        onClose={goBackToFulfillmentPopup}
        onConfirm={confirmSync}
      />
      {showFulfillmentNodeAi && <FulfillmentAiInsightDialog insight={activeFulfillmentInsight} onClose={() => setActiveFulfillmentInsight(null)} />}
      <Dialog
        open={Boolean(syncStatus) && syncReceiptOpen}
        onClose={() => setSyncReceiptOpen(false)}
        maxWidth={false}
        fullWidth
        sx={{ zIndex: (theme) => theme.zIndex.modal + 180 }}
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', sm: 440 },
            overflow: 'hidden',
            borderRadius: 2.5,
            border: 1,
            borderColor: syncStatus?.severity === 'success' ? '#16a064' : syncStatus?.severity === 'error' ? '#d22f3a' : '#1769e0',
            boxShadow: '0 28px 80px rgba(15,23,42,.34)'
          }
        }}
      >
        <Box sx={{ px: 2.35, py: 2.1, background: syncStatus?.severity === 'success' ? 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' : syncStatus?.severity === 'error' ? 'linear-gradient(120deg, #fff0f1, #ffffff 72%)' : 'linear-gradient(120deg, #eef7ff, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.35} alignItems="flex-start">
            <Box sx={{ width: 42, height: 42, flex: '0 0 auto', borderRadius: 1.75, display: 'grid', placeItems: 'center', color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8', bgcolor: 'rgba(255,255,255,.72)', border: '1px solid rgba(17,24,39,.08)' }}>
              <SyncIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" fontWeight={950} sx={{ color: syncStatus?.severity === 'success' ? '#087443' : syncStatus?.severity === 'error' ? '#9f1721' : '#0f4ea8' }}>
                Fulfillment Synchronization
              </Typography>
              <Typography variant="h6" fontWeight={950} color="text.primary" sx={{ mt: 0.2 }}>
                {syncStatus?.severity === 'success' ? 'Sync request submitted' : 'Sync request needs attention'}
              </Typography>
              <Typography sx={{ mt: 0.75, color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>
                {syncStatus?.message}
              </Typography>
            </Box>
          </Stack>
        </Box>
        <DialogActions sx={{ px: 2.35, py: 1.55, borderTop: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.background.default, 0.55) }}>
          <Button variant="contained" startIcon={<SyncIcon />} onClick={() => setSyncReceiptOpen(false)} sx={{ minWidth: 150 }}>
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function FulfillmentNodeAiCard({
  location,
  insights,
  onOpen
}: {
  location: FulfillmentLocationGroup;
  insights: FulfillmentAiInsight[];
  onOpen: (insight: FulfillmentAiInsight) => void;
}) {
  const nodeQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
  const pendingCount = location.releases.filter((release) => release.trackingNumber === 'Pending' || release.status.includes('Awaiting')).length;
  const activeCount = location.releases.filter((release) => release.trackingNumber !== 'Pending' && release.status !== 'Cancelled').length;
  const accent = location.type === 'Warehouse' ? '#0f766e' : location.type === 'Store' ? '#6d5bd0' : location.type === 'Dropship' ? '#b45309' : '#0f5f8a';
  const NodeIcon = location.type === 'Warehouse' ? WarehouseIcon : location.type === 'Store' ? StorefrontIcon : LocalShippingIcon;

  return (
    <GlassCard
      sx={{
        height: '100%',
        p: 1.1,
        borderColor: alpha(accent, 0.32),
        bgcolor: (theme) => theme.palette.mode === 'light'
          ? `linear-gradient(135deg, ${alpha('#ffffff', 0.98)}, ${alpha(accent, 0.075)})`
          : `linear-gradient(135deg, ${alpha(theme.palette.background.paper, 0.94)}, ${alpha(accent, 0.14)})`,
        boxShadow: '0 16px 34px rgba(15,23,42,.1)'
      }}
    >
      <Stack spacing={1}>
        <Stack direction="row" spacing={1} alignItems="center" justifyContent="space-between">
          <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
            <Box
              sx={{
                width: 38,
                height: 38,
                flex: '0 0 auto',
                borderRadius: 1.6,
                display: 'grid',
                placeItems: 'center',
                color: accent,
                bgcolor: alpha(accent, 0.11),
                border: `1px solid ${alpha(accent, 0.24)}`
              }}
            >
              <NodeIcon fontSize="small" />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="subtitle2" fontWeight={950} noWrap title={location.nodeName}>{location.nodeName}</Typography>
              <Stack direction="row" spacing={0.7} alignItems="center" sx={{ flexWrap: 'wrap' }}>
                <Chip size="small" label={location.type} sx={{ height: 20, fontSize: '0.66rem', fontWeight: 900, color: accent, bgcolor: alpha(accent, 0.1), border: `1px solid ${alpha(accent, 0.2)}` }} />
                <Typography variant="caption" color="text.secondary" fontWeight={800}>{location.nodeId}</Typography>
              </Stack>
            </Box>
          </Stack>
          <Chip size="small" label={`${location.releases.length} records`} variant="outlined" sx={{ fontWeight: 900 }} />
        </Stack>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', sm: 'repeat(4, minmax(0, 1fr))' },
            gap: 0.65
          }}
        >
          <AggregateMetric label="Quantity" value={String(nodeQuantity)} />
          <AggregateMetric label="Active" value={String(activeCount)} />
          <AggregateMetric label="Pending" value={String(pendingCount)} alert={pendingCount > 0} />
          <AggregateMetric label="Releases" value={String(new Set(location.releases.map((release) => release.releaseNumber)).size)} />
        </Box>

        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={0.75}>
          {insights.map((insight) => (
            <Button
              key={insight.key}
              size="small"
              variant={insight.tone === 'warning' ? 'contained' : 'outlined'}
              color={insight.tone === 'warning' ? 'warning' : 'primary'}
              startIcon={<AutoAwesomeIcon />}
              onClick={() => onOpen(insight)}
              sx={{
                flex: 1,
                minHeight: 32,
                px: 0.8,
                borderRadius: 1.6,
                fontSize: '0.68rem',
                fontWeight: 950,
                whiteSpace: 'normal',
                lineHeight: 1.1,
                boxShadow: insight.tone === 'warning' ? '0 8px 18px rgba(217,119,6,.2)' : 'none'
              }}
            >
              {insight.label}
            </Button>
          ))}
        </Stack>
      </Stack>
    </GlassCard>
  );
}

function FulfillmentAiButtonBar({
  insights,
  onOpen,
  compact = false
}: {
  insights: FulfillmentAiInsight[];
  onOpen: (insight: FulfillmentAiInsight) => void;
  compact?: boolean;
}) {
  return (
    <GlassCard
      sx={{
        mb: compact ? 1.25 : 0.75,
        p: compact ? 1 : 1.05,
        borderColor: (theme) => alpha(theme.palette.primary.main, 0.28),
        bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#f8fbff', 0.92) : alpha(theme.palette.primary.main, 0.08),
        boxShadow: '0 14px 34px rgba(15,23,42,.08)'
      }}
    >
      <Stack direction={{ xs: 'column', lg: 'row' }} spacing={1} alignItems={{ xs: 'stretch', lg: 'center' }} justifyContent="space-between">
        <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box
            sx={{
              width: compact ? 34 : 38,
              height: compact ? 34 : 38,
              flex: '0 0 auto',
              borderRadius: 1.6,
              display: 'grid',
              placeItems: 'center',
              color: '#0f5f6a',
              background: 'linear-gradient(135deg, rgba(255,255,255,.96), rgba(189,221,228,.86))',
              border: '1px solid rgba(17,124,139,.24)',
              boxShadow: 'inset 0 1px 0 rgba(255,255,255,.68)'
            }}
          >
            <AutoAwesomeIcon fontSize={compact ? 'small' : 'medium'} />
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="subtitle2" fontWeight={950} sx={{ lineHeight: 1.1 }}>Fulfillment Node AI Analytics</Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.25 }}>
              Stuck-node, release-aging, and reroute intelligence before reviewing node status lines
            </Typography>
          </Box>
        </Stack>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={0.85}>
          {insights.map((insight) => (
            <Button
              key={insight.key}
              size="small"
              variant={insight.tone === 'warning' ? 'contained' : 'outlined'}
              color={insight.tone === 'warning' ? 'warning' : 'primary'}
              startIcon={<AutoAwesomeIcon />}
              onClick={() => onOpen(insight)}
              sx={{
                minHeight: compact ? 32 : 34,
                px: 1.2,
                borderRadius: 1.75,
                fontSize: '0.72rem',
                fontWeight: 950,
                whiteSpace: 'nowrap',
                boxShadow: insight.tone === 'warning' ? '0 8px 20px rgba(217,119,6,.22)' : 'none'
              }}
            >
              {insight.label}
            </Button>
          ))}
        </Stack>
      </Stack>
    </GlassCard>
  );
}

function FulfillmentAiInsightDialog({ insight, onClose }: { insight: FulfillmentAiInsight | null; onClose: () => void }) {
  return (
    <Dialog open={Boolean(insight)} onClose={onClose} maxWidth="sm" fullWidth sx={{ zIndex: (theme) => theme.zIndex.modal + 170 }}>
      <DialogTitle sx={{ position: 'relative', pr: 7, px: 3, py: 2.25 }}>
        <Stack direction="row" spacing={1.25} alignItems="center">
          <Box
            sx={{
              width: 44,
              height: 44,
              flex: '0 0 auto',
              borderRadius: 1.75,
              display: 'grid',
              placeItems: 'center',
              color: 'primary.main',
              bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1),
              border: 1,
              borderColor: (theme) => alpha(theme.palette.primary.main, 0.22)
            }}
          >
            <AutoAwesomeIcon />
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="h6" fontWeight={950} sx={{ lineHeight: 1.15 }}>{insight?.title}</Typography>
            <Typography variant="body2" color="text.secondary">Fulfillment node AI analytics</Typography>
          </Box>
        </Stack>
        <IconButton aria-label="Close fulfillment AI analytics" onClick={onClose} sx={{ position: 'absolute', right: 12, top: 12 }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers sx={{ px: 3, py: 2.25 }}>
        <Typography sx={{ mb: 1.4, color: '#111827', fontWeight: 900, lineHeight: 1.45 }}>
          {insight?.summary}
        </Typography>
        <Stack spacing={1}>
          {insight?.findings.map((finding) => (
            <Stack
              key={finding}
              direction="row"
              spacing={1}
              alignItems="flex-start"
              sx={{
                p: 1.15,
                borderRadius: 1.5,
                border: 1,
                borderColor: (theme) => alpha(theme.palette.primary.main, 0.18),
                bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045)
              }}
            >
              <AutoAwesomeIcon color="primary" fontSize="small" sx={{ mt: 0.2 }} />
              <Typography variant="body2" fontWeight={750} color="text.primary">{finding}</Typography>
            </Stack>
          ))}
        </Stack>
        <Alert severity={insight?.tone ?? 'info'} sx={{ mt: 1.5, '& .MuiAlert-message': { color: '#111827', fontWeight: 850 } }}>
          {insight?.recommendation}
        </Alert>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="contained" startIcon={<AutoAwesomeIcon />} onClick={onClose} sx={{ minWidth: 120 }}>
          Done
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function FulfillmentLinesTable({
  rows,
  sortKey,
  sortDirection,
  onSort,
  onSync,
  releases,
  multiSort,
  showType = true,
  columnFilters,
  onColumnFilterChange
}: {
  rows: Fulfillment[];
  sortKey: FulfillmentSortKey;
  sortDirection: SortDirection;
  onSort: (sortKey: FulfillmentSortKey) => void;
  onSync: (fulfillment: Fulfillment) => void;
  releases: Release[];
  multiSort: boolean;
  showType?: boolean;
  columnFilters?: Partial<Record<FulfillmentSortKey, string>>;
  onColumnFilterChange?: (key: FulfillmentSortKey, value: string) => void;
}) {
  const columns: Array<{ key: FulfillmentSortKey; label: string; width: number }> = [
    { key: 'releaseNumber', label: 'Release ID', width: 98 },
    { key: 'releaseLineId', label: 'Rel Line Id', width: 68 },
    ...(showType ? [{ key: 'type' as const, label: 'Type', width: 82 }] : []),
    { key: 'nodeName', label: 'Fulfillment Location', width: 128 },
    { key: 'packageId', label: 'Package ID', width: 100 },
    { key: 'packageDetailId', label: 'Pkg Detail', width: 62 },
    { key: 'shipmentId', label: 'Shipment ID', width: 102 },
    { key: 'orderedQty', label: 'Ord Qty', width: 58 },
    { key: 'shippedQty', label: 'Ful Qty', width: 58 },
    { key: 'cancelledQty', label: 'Cxl Qty', width: 58 },
    { key: 'status', label: 'Status', width: 112 },
    { key: 'createdDate', label: 'Created', width: 78 },
    { key: 'updatedDate', label: 'Updated', width: 86 },
    { key: 'shipVia', label: 'Ship Via', width: 112 },
    { key: 'trackingNumber', label: 'Tracking #', width: 120 }
  ];

  return (
    <Box
      sx={{
        overflow: 'hidden',
        border: 1,
        borderColor: (theme) => alpha(theme.palette.primary.main, 0.26),
        borderRadius: 2.5,
        bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#ffffff', 0.94) : alpha(theme.palette.background.paper, 0.9),
        boxShadow: '0 18px 42px rgba(15,23,42,.13)',
        backdropFilter: 'blur(18px)'
      }}
    >
      <Box sx={{ overflowX: 'auto' }}>
        <Table
          size="small"
          sx={{
            width: 'max(100%, 1080px)',
            minWidth: { xs: 980, md: 1040 },
            tableLayout: 'fixed',
            '& thead th': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(180deg, rgba(246,248,251,.98), rgba(222,229,238,.96))'
                : 'linear-gradient(180deg, rgba(38,45,55,.98), rgba(18,24,32,.98))',
              color: (theme) => theme.palette.mode === 'light' ? '#172033' : '#f7fafc',
              fontSize: '0.72rem',
              fontWeight: 950,
              lineHeight: 1.1,
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
              borderBottom: 1,
              borderBottomColor: (theme) => alpha(theme.palette.primary.main, 0.26),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.62),
              px: 0.65,
              py: 0.6
            },
            '& thead th:last-of-type': { borderRight: 0 },
            '& tbody tr': {
              transition: 'background-color .16s ease, box-shadow .16s ease',
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(247,251,253,.97))'
                : alpha(theme.palette.background.paper, 0.74)
            },
            '& tbody tr:nth-of-type(even)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(232,244,248,.74), rgba(241,248,250,.92))'
                : alpha(theme.palette.primary.main, 0.075)
            },
            '& tbody tr:nth-of-type(odd)': {
              background: (theme) => theme.palette.mode === 'light'
                ? 'linear-gradient(90deg, rgba(255,255,255,.99), rgba(248,252,253,.98))'
                : alpha(theme.palette.background.paper, 0.8)
            },
            '& tbody tr:hover': {
              background: (theme) => `${theme.palette.mode === 'light' ? 'linear-gradient(90deg, rgba(214,239,245,.96), rgba(238,248,251,.98))' : alpha(theme.palette.primary.main, 0.14)} !important`,
              boxShadow: 'inset 3px 0 0 rgba(17,124,139,.72)'
            },
            '& td': {
              px: 0.65,
              py: 0.58,
              verticalAlign: 'middle',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              overflowWrap: 'anywhere',
              wordBreak: 'break-word',
              borderBottomColor: (theme) => alpha(theme.palette.divider, 0.72),
              borderRight: 1,
              borderRightColor: (theme) => alpha(theme.palette.divider, 0.42)
            },
            '& td:last-of-type': { borderRight: 0 },
            '& .MuiChip-root': { height: 22, fontSize: '0.68rem', maxWidth: '100%', fontWeight: 850 },
            '& .MuiTableSortLabel-root': { maxWidth: '100%', color: 'inherit' },
            '& .MuiTableSortLabel-root:hover': { color: 'primary.main' },
            '& .MuiTableSortLabel-root.Mui-active': { color: 'primary.main' },
            '& .MuiTableSortLabel-icon': { color: 'primary.main !important', ml: 0.15 },
            '& .fulfillment-location-pill': {
              display: 'inline-flex',
              alignItems: 'center',
              maxWidth: '100%',
              gap: 0.55,
              px: 0.75,
              py: 0.35,
              borderRadius: 1.25,
              color: '#0d6470',
              bgcolor: 'rgba(17,124,139,.1)',
              border: '1px solid rgba(17,124,139,.22)'
            },
            '& .fulfillment-type-chip': {
              height: 22,
              minWidth: 62,
              borderRadius: 999,
              color: '#ffffff',
              fontSize: '0.62rem',
              fontWeight: 950
            }
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.key} sortDirection={!multiSort && sortKey === column.key ? sortDirection : false} sx={{ width: column.width }}>
                  <TableSortLabel
                    active={!multiSort && sortKey === column.key}
                    direction={!multiSort && sortKey === column.key ? sortDirection : 'asc'}
                    onClick={() => onSort(column.key)}
                  >
                    {column.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell sx={{ width: 86, fontWeight: 950 }}>Sync</TableCell>
            </TableRow>
            {columnFilters && onColumnFilterChange && (
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={`filter-${column.key}`} sx={{ py: 0.45 }}>
                    <TextField
                      variant="standard"
                      size="small"
                      placeholder="Filter"
                      value={columnFilters[column.key] ?? ''}
                      onChange={(event) => onColumnFilterChange(column.key, event.target.value)}
                      InputProps={{ disableUnderline: true }}
                      inputProps={{ 'aria-label': `Filter ${column.label}` }}
                      sx={{ width: '100%', '& input': { fontSize: '0.67rem', py: 0.25 } }}
                    />
                  </TableCell>
                ))}
                <TableCell />
              </TableRow>
            )}
          </TableHead>
          <TableBody>
            {rows.map((release) => {
              const accent = getFulfillmentTypeColor(release.type);
              const Icon = release.type === 'Warehouse' ? WarehouseIcon : release.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
              const shippedQty = getFulfillmentShippedQty(release, releases);
              const cancelledQty = getFulfillmentCancelledQty(release, releases);
              const statusStyle = getFulfillmentStatusStyle(release.status);
              return (
                <TableRow
                  key={`${release.fulfillmentId}|${release.releaseNumber}|${release.releaseLineId}`}
                  hover
                  sx={{
                    '& td:first-of-type': { boxShadow: `inset 4px 0 0 ${accent}` },
                    '&:nth-of-type(odd)': {
                      background: (theme) => theme.palette.mode === 'light'
                        ? `linear-gradient(90deg, ${alpha(accent, 0.045)}, rgba(255,255,255,.99) 24%, rgba(248,252,253,.98))`
                        : alpha(accent, 0.055)
                    },
                    '&:nth-of-type(even)': {
                      background: (theme) => theme.palette.mode === 'light'
                        ? `linear-gradient(90deg, ${alpha(accent, 0.09)}, rgba(232,244,248,.76) 30%, rgba(241,248,250,.92))`
                        : alpha(accent, 0.09)
                    }
                  }}
                >
                  <TableCell sx={{ fontWeight: 950, whiteSpace: 'nowrap' }} title={release.releaseNumber}>{release.releaseNumber}</TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.releaseLineId}>{release.releaseLineId}</TableCell>
                  {showType && <TableCell><Chip className="fulfillment-type-chip" label={release.type} sx={{ bgcolor: accent }} /></TableCell>}
                  <TableCell sx={{ maxWidth: 128 }}>
                    <Tooltip title={release.nodeName} arrow placement="top">
                      <Box component="span" className="fulfillment-location-pill" sx={{ minWidth: 0, maxWidth: 106, cursor: 'help' }}>
                        <Icon sx={{ fontSize: 15, flex: '0 0 auto', color: accent }} />
                        <Typography
                          component="span"
                          variant="body2"
                          fontWeight={900}
                          noWrap
                          sx={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis' }}
                        >
                          {release.nodeName}
                        </Typography>
                      </Box>
                    </Tooltip>
                  </TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.packageId}>{release.packageId}</TableCell>
                  <TableCell sx={{ fontWeight: 900, textAlign: 'center' }} title={release.packageDetailId}>{release.packageDetailId}</TableCell>
                  <TableCell sx={{ whiteSpace: 'normal' }} title={release.shipmentId}>{release.shipmentId}</TableCell>
                  <TableCell sx={{ fontWeight: 900 }}>{release.quantity}</TableCell>
                  <TableCell sx={{ fontWeight: 900, color: shippedQty > 0 ? 'success.main' : 'text.secondary' }}>{shippedQty}</TableCell>
                  <TableCell sx={{ fontWeight: 900, color: cancelledQty > 0 ? 'error.main' : 'text.secondary' }}>{cancelledQty}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={release.status}
                      sx={{
                        color: statusStyle.fg,
                        bgcolor: statusStyle.bg,
                        border: `1px solid ${statusStyle.border}`,
                        fontWeight: 950,
                        height: 'auto',
                        minHeight: 22,
                        '& .MuiChip-label': { whiteSpace: 'normal', lineHeight: 1.1, py: 0.25 }
                      }}
                    />
                  </TableCell>
                  <CompactDateCell value={release.createdDate} />
                  <CompactDateCell value={release.updatedDate} />
                  <TableCell sx={{ whiteSpace: 'normal' }} title={release.shipVia}>{release.shipVia}</TableCell>
                  <TableCell sx={{ fontWeight: 850, whiteSpace: 'normal' }} title={release.trackingNumber}>{release.trackingNumber}</TableCell>
                  <TableCell>
                    <Button
                      className="sync-release-button"
                      size="small"
                      variant="contained"
                      startIcon={<SyncIcon />}
                      onClick={() => onSync(release)}
                      sx={{
                        minWidth: 74,
                        px: 0.65,
                        fontSize: '0.68rem',
                        color: 'common.white',
                        background: 'linear-gradient(135deg, #0b5963, #168895 55%, #6fb5bd)',
                        border: '1px solid rgba(255,255,255,.42)',
                        boxShadow: '0 6px 16px rgba(17,124,139,.25)',
                        '&:hover': { background: 'linear-gradient(135deg, #084951, #117c8b 55%, #55a5ae)', boxShadow: '0 8px 20px rgba(17,124,139,.34)' }
                      }}
                    >
                      Sync
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>
    </Box>
  );
}

function FulfillmentLocationSummary({ location }: { location: { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] } }) {
  const Icon = location.type === 'Warehouse' ? WarehouseIcon : location.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
  const totalQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
  const statuses = Array.from(new Set(location.releases.map((release) => release.status)));
  const statusSummary = statuses.length === 1 ? statuses[0] : `${statuses.length} statuses`;
  return (
    <GlassCard sx={{ p: 1.35, borderLeft: '4px solid', borderLeftColor: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.035) }}>
      <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'minmax(230px, 1.8fr) 110px 110px 90px minmax(150px, 1fr)' }, gap: { xs: 0.75, md: 1.5 }, alignItems: 'center' }}>
        <Stack direction="row" spacing={1.1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box sx={{ width: 36, height: 36, borderRadius: 1.5, display: 'grid', placeItems: 'center', flex: '0 0 auto', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon fontSize="small" /></Box>
          <LineValue label={location.nodeId} value={location.nodeName} strong />
        </Stack>
        <Box><Typography variant="caption" color="text.secondary">Type</Typography><Box><Chip size="small" label={location.type} variant="outlined" /></Box></Box>
        <LineValue label="Release Lines" value={String(location.releases.length)} strong />
        <LineValue label="Total Qty" value={String(totalQuantity)} strong />
        <Box><Typography variant="caption" color="text.secondary">Execution Status</Typography><Box><Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} /></Box></Box>
      </Box>
    </GlassCard>
  );
}

function FulfillmentLocationDialogRow({
  location,
  onSync
}: {
  location: { type: Fulfillment['type']; nodeId: string; nodeName: string; releases: Fulfillment[] };
  onSync: (fulfillment: Fulfillment) => void;
}) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const Icon = location.type === 'Warehouse' ? WarehouseIcon : location.type === 'Store' ? StorefrontIcon : LocalShippingIcon;
  const totalQuantity = location.releases.reduce((total, release) => total + release.quantity, 0);
  const statuses = Array.from(new Set(location.releases.map((release) => release.status)));
  const statusSummary = statuses.length === 1 ? statuses[0] : `${statuses.length} statuses`;

  return (
    <>
      <GlassCard
        sx={{
          borderLeft: '4px solid',
          borderLeftColor: 'info.main',
          bgcolor: (theme) => alpha(theme.palette.info.main, 0.035),
          borderColor: (theme) => alpha(theme.palette.info.main, 0.28),
          transition: 'background-color 180ms ease, border-color 180ms ease, box-shadow 180ms ease',
          '&:hover': { borderColor: 'warning.main', bgcolor: (theme) => alpha(theme.palette.warning.main, 0.08), boxShadow: (theme) => `0 8px 24px ${alpha(theme.palette.warning.main, 0.14)}` }
        }}
      >
        <ButtonBase aria-label={`Open fulfillment ${location.nodeId} details`} onClick={() => setDetailsOpen(true)} sx={{ width: '100%', p: 1.35, textAlign: 'left' }}>
          <Box sx={{ width: '100%', display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'minmax(230px, 1.8fr) 110px 110px 90px minmax(150px, 1fr) 28px' }, gap: { xs: 0.75, md: 1.5 }, alignItems: 'center' }}>
            <Stack direction="row" spacing={1.1} alignItems="center" sx={{ minWidth: 0 }}>
              <Box className="fulfillment-type-icon" sx={{ width: 36, height: 36, borderRadius: 1.5, display: 'grid', placeItems: 'center', flex: '0 0 auto', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon fontSize="small" /></Box>
              <LineValue label={location.nodeId} value={location.nodeName} strong />
            </Stack>
            <Box><Typography variant="caption" color="text.secondary">Type</Typography><Box><Chip size="small" label={location.type} variant="outlined" /></Box></Box>
            <LineValue label="Release Lines" value={String(location.releases.length)} strong />
            <LineValue label="Total Qty" value={String(totalQuantity)} strong />
            <Box><Typography variant="caption" color="text.secondary">Execution Status</Typography><Box><Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} /></Box></Box>
            <OpenInNewIcon fontSize="small" color="info" />
          </Box>
        </ButtonBase>
      </GlassCard>
      <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} fullWidth maxWidth="xl" aria-labelledby={`fulfillment-details-${location.nodeId}`}>
        <DialogTitle id={`fulfillment-details-${location.nodeId}`} sx={{ pr: 7 }}>
          <Stack direction="row" spacing={1.25} alignItems="center" flexWrap="wrap" useFlexGap>
            <Box sx={{ width: 38, height: 38, borderRadius: 1.5, display: 'grid', placeItems: 'center', color: 'info.main', bgcolor: (theme) => alpha(theme.palette.info.main, 0.1) }}><Icon /></Box>
            <Box>
              <Typography variant="h6">{location.nodeName}</Typography>
              <Typography variant="body2" color="text.secondary">{location.nodeId} · {location.type} · {location.releases.length} release lines</Typography>
            </Box>
            <Chip size="small" label={statusSummary} color={statusSummary === 'Cancelled' ? 'error' : statusSummary === 'In Transit' || statusSummary === 'Ready for Pickup' ? 'success' : 'info'} />
          </Stack>
          <IconButton aria-label="Close fulfillment details" onClick={() => setDetailsOpen(false)} sx={{ position: 'absolute', right: 14, top: 14 }}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0, bgcolor: (theme) => alpha(theme.palette.warning.main, 0.04) }}>
        <Box sx={{ px: 2, py: 1.15, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.warning.main, 0.075) }}>
          <Typography variant="overline" fontWeight={900} color="text.secondary">{location.releases.length} releases fulfilled by {location.nodeName}</Typography>
        </Box>
        <Box sx={{ overflowX: 'auto' }}>
          <Table size="small" sx={{ minWidth: 1180 }}>
            <TableHead>
              <TableRow>
                {['Release ID', 'Rel Line Id', 'Package ID', 'Pkg Detail', 'Shipment ID', 'Ord Qty', 'Ful Qty', 'Cxl Qty', 'Status', 'Ship Via', 'Tracking Number', 'Sync'].map((label) => <TableCell key={label}>{label}</TableCell>)}
              </TableRow>
            </TableHead>
            <TableBody>
              {location.releases.map((release) => {
                const fulfilledQty = release.status === 'Shipped' || release.status === 'Delivered' || release.status === 'In Transit' ? release.quantity : 0;
                const cancelledQty = release.status.toLowerCase().includes('cancel') ? release.quantity : 0;
                return (
                  <TableRow key={release.fulfillmentId} hover>
                    <TableCell sx={{ fontWeight: 900 }}>{release.releaseNumber}</TableCell>
                    <TableCell>{release.releaseLineId}</TableCell>
                    <TableCell>{release.packageId}</TableCell>
                    <TableCell sx={{ fontWeight: 900, textAlign: 'center' }}>{release.packageDetailId}</TableCell>
                    <TableCell>{release.shipmentId}</TableCell>
                    <TableCell sx={{ fontWeight: 800 }}>{release.quantity}</TableCell>
                    <TableCell sx={{ fontWeight: 800, color: fulfilledQty > 0 ? 'success.main' : 'text.secondary' }}>{fulfilledQty}</TableCell>
                    <TableCell sx={{ fontWeight: 800, color: cancelledQty > 0 ? 'error.main' : 'text.secondary' }}>{cancelledQty}</TableCell>
                    <TableCell><Chip size="small" label={release.status} color={release.status === 'Cancelled' ? 'error' : release.status === 'In Transit' || release.status === 'Ready for Pickup' ? 'success' : 'info'} /></TableCell>
                    <TableCell>{release.shipVia}</TableCell>
                    <TableCell sx={{ fontWeight: 800 }}>{release.trackingNumber}</TableCell>
                    <TableCell>
                      <Button
                        className="sync-release-button"
                        size="small"
                        variant="contained"
                        startIcon={<SyncIcon />}
                        onClick={() => { setDetailsOpen(false); onSync(release); }}
                        sx={{ minWidth: 112, bgcolor: 'info.main', color: 'common.white', boxShadow: '0 5px 14px rgba(23,105,224,.2)', '&:hover': { bgcolor: 'info.dark' } }}
                      >
                        Sync Status
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Box>
        </DialogContent>
      </Dialog>
    </>
  );
}
