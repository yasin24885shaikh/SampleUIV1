import { useMemo, useState } from 'react';
import { Box, Button, CardActionArea, Chip, MenuItem, Pagination, Stack, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import SearchIcon from '@mui/icons-material/Search';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

export default function CommonProducts() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const { data, error, reload } = useApiResource(omsApi.getProducts);
  const productCatalog = data?.items ?? [];
  const filtered = useMemo(
    () =>
      productCatalog.filter(
        (product) =>
          (!query || `${product.sku} ${product.productName} ${product.vendor}`.toLowerCase().includes(query.toLowerCase())) &&
          (!category || product.category === category)
      ),
    [category, productCatalog, query]
  );

  if (!data) {
    return (
      <Box>
        <PageHeader title="Common Products" subtitle="Reusable product catalog for merchandising, order capture, and fulfillment validation." badge="Catalog" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={6} />}
      </Box>
    );
  }

  return (
    <Box>
      <PageHeader title="Common Products" subtitle="Reusable product catalog for merchandising, order capture, and fulfillment validation." badge="Catalog" />
      <GlassCard sx={{ p: 2.5, mb: 2.5 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
          <TextField value={query} onChange={(event) => setQuery(event.target.value)} label="Search Products" fullWidth InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1 }} /> }} />
          <TextField select value={category} onChange={(event) => setCategory(event.target.value)} label="Category" sx={{ minWidth: 220 }}>
            <MenuItem value="">All Categories</MenuItem>
            <MenuItem value="Running">Running</MenuItem>
            <MenuItem value="Lifestyle">Lifestyle</MenuItem>
            <MenuItem value="Launch">Launch</MenuItem>
          </TextField>
          <Button variant="contained" sx={{ minWidth: 130 }}>Apply</Button>
        </Stack>
      </GlassCard>
      <Grid container spacing={2.5}>
        {filtered.map((product) => (
          <Grid item xs={12} sm={6} lg={4} xl={3} key={product.sku}>
            <GlassCard sx={{ overflow: 'hidden', height: '100%' }}>
              <CardActionArea sx={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'stretch' }}>
                <Box component="img" src={product.image} alt={product.productName} sx={{ width: '100%', aspectRatio: '16 / 10', objectFit: 'cover' }} />
                <Box sx={{ p: 2 }}>
                  <Stack direction="row" justifyContent="space-between" gap={1}>
                    <Typography fontWeight={900}>{product.sku}</Typography>
                    <Chip size="small" label={product.category} />
                  </Stack>
                  <Typography sx={{ mt: 1, minHeight: 48 }}>{product.productName}</Typography>
                  <Typography color="text.secondary">{product.vendor}</Typography>
                  <Typography fontWeight={900} sx={{ mt: 1 }}>${product.price}.00</Typography>
                </Box>
              </CardActionArea>
            </GlassCard>
          </Grid>
        ))}
      </Grid>
      <Stack alignItems="center" sx={{ mt: 3 }}>
        <Pagination count={3} color="primary" />
      </Stack>
    </Box>
  );
}
