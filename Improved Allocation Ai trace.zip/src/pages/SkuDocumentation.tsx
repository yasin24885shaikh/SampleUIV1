import { Box, Button, Stack, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import SearchIcon from '@mui/icons-material/Search';
import InventoryIcon from '@mui/icons-material/Inventory';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import FactoryIcon from '@mui/icons-material/Factory';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi } from '../services/omsApi';

const loadDefaultSku = (signal: AbortSignal) => omsApi.getSkuDocumentation('FV5029-141', signal);

export default function SkuDocumentation() {
  const { data, error, reload } = useApiResource(loadDefaultSku);

  if (!data) {
    return (
      <Box>
        <PageHeader title="SKU Documentation" subtitle="Authoritative SKU attributes, vendor details, packaging rules, and shipping constraints." badge="SKUDOC" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={5} />}
      </Box>
    );
  }
  const { product: sku, sections } = data;

  return (
    <Box>
      <PageHeader title="SKU Documentation" subtitle="Authoritative SKU attributes, vendor details, packaging rules, and shipping constraints." badge="SKUDOC" />
      <GlassCard sx={{ p: 2.5, mb: 2.5 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
          <TextField label="Search SKU" defaultValue="FV5029-141" fullWidth />
          <Button startIcon={<SearchIcon />} variant="contained" sx={{ minWidth: 150 }}>Search</Button>
        </Stack>
      </GlassCard>
      <Grid container spacing={2.5}>
        <Grid item xs={12} md={4}>
          <GlassCard sx={{ overflow: 'hidden' }}>
            <Box component="img" src={sku.image} alt={sku.productName} sx={{ width: '100%', height: 270, objectFit: 'cover' }} />
            <Box sx={{ p: 2.5 }}>
              <Typography variant="h5">{sku.sku}</Typography>
              <Typography color="text.secondary">{sku.productName}</Typography>
              <Typography sx={{ mt: 1 }} fontWeight={900}>${sku.price}.00</Typography>
            </Box>
          </GlassCard>
        </Grid>
        <Grid item xs={12} md={8}>
          <Grid container spacing={2}>
            <InfoPanel icon={<InventoryIcon />} title={sections[0].title} lines={sections[0].lines} />
            <InfoPanel icon={<FactoryIcon />} title={sections[1].title} lines={sections[1].lines} />
            <InfoPanel icon={<InventoryIcon />} title={sections[2].title} lines={sections[2].lines} />
            <InfoPanel icon={<LocalShippingIcon />} title={sections[3].title} lines={sections[3].lines} />
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
}

function InfoPanel({ icon, title, lines }: { icon: React.ReactNode; title: string; lines: string[] }) {
  return (
    <Grid item xs={12} md={6}>
      <GlassCard sx={{ p: 2.5, height: '100%' }}>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1.5 }}>
          {icon}
          <Typography variant="h6">{title}</Typography>
        </Stack>
        {lines.map((line) => (
          <Typography key={line} color="text.secondary" sx={{ py: 0.45 }}>{line}</Typography>
        ))}
      </GlassCard>
    </Grid>
  );
}
