import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputAdornment,
  InputLabel,
  LinearProgress,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography
} from '@mui/material';
import { alpha } from '@mui/material/styles';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import EditIcon from '@mui/icons-material/Edit';
import BlockIcon from '@mui/icons-material/Block';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import { useApiResource } from '../hooks/useApiResource';
import { omsApi, type OmsUser } from '../services/omsApi';

const roles = ['OMS Administrator', 'OMS Ops L2', 'OMS Ops L1', 'Business Read', 'Business Write'];
const statuses = ['Active', 'Disabled'];
const accessReasons = ['New operations user', 'Temporary support coverage', 'Role correction', 'Leadership demo access'];

type UserRow = OmsUser;
type ActionDialog = 'add' | null;
type PendingAction =
  | { kind: 'add'; title: string; description: string; details: Array<[string, string]> }
  | { kind: 'role'; user: UserRow; value: string; title: string; description: string; details: Array<[string, string]> }
  | { kind: 'status'; user: UserRow; value: string; title: string; description: string; details: Array<[string, string]> };

const emptyAddForm = {
  userId: '',
  firstName: '',
  lastName: '',
  role: roles[1],
  status: statuses[0],
  reason: accessReasons[0]
};

export default function UserManagement() {
  const { data, error, reload } = useApiResource(omsApi.getUsers);
  const [rows, setRows] = useState<UserRow[]>([]);
  const [globalSearch, setGlobalSearch] = useState('');
  const [inlineEditing, setInlineEditing] = useState(false);
  const [statusEditing, setStatusEditing] = useState(false);
  const [actionDialog, setActionDialog] = useState<ActionDialog>(null);
  const [addForm, setAddForm] = useState(emptyAddForm);
  const [confirmation, setConfirmation] = useState<{ title: string; message: string } | null>(null);
  const [inlineMessage, setInlineMessage] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (data?.items) {
      setRows(data.items);
    }
  }, [data]);

  const filteredUsers = useMemo(() => {
    const query = globalSearch.trim().toLowerCase();
    if (!query) return rows;
    return rows.filter((user) => [
      user.name,
      user.userId,
      user.firstName,
      user.lastName,
      user.role,
      user.status
    ].join(' ').toLowerCase().includes(query));
  }, [globalSearch, rows]);

  const requestUserUpdate = (user: UserRow, field: 'role' | 'status', value: string) => {
    setPendingAction({
      kind: field,
      user,
      value,
      title: field === 'role' ? 'Confirm role change' : `Confirm ${value.toLowerCase()}`,
      description: field === 'role' ? 'Apply this role assignment to the selected user?' : 'Apply this account status change?',
      details: [['User', `${user.name} (${user.userId})`], [field === 'role' ? 'New role' : 'New status', value]]
    });
  };

  const runPendingAction = async () => {
    if (!pendingAction) return;
    const action = pendingAction;
    setPendingAction(null);
    setActionLoading(true);
    setProgress(8);
    const progressTimer = window.setInterval(() => setProgress((current) => Math.min(current + 14, 88)), 160);
    try {
      if (action.kind === 'add') {
        const [createdUser] = await Promise.all([
          omsApi.addUser({
            userId: addForm.userId,
            firstName: addForm.firstName,
            lastName: addForm.lastName,
            role: addForm.role,
            permissions: 'Role managed',
            status: addForm.status,
            reason: addForm.reason
          }),
          new Promise((resolve) => window.setTimeout(resolve, 1050))
        ]);
        setRows((current) => [...current, createdUser]);
        setActionDialog(null);
        setConfirmation({ title: 'User added', message: `${createdUser.name} (${createdUser.userId}) was provisioned as ${createdUser.role}.` });
      } else if (action.kind === 'status') {
        await Promise.all([
          omsApi.updateUserStatus(action.user.userId, { status: action.value, reason: action.value === 'Disabled' ? 'Admin disabled from User Management' : 'Admin reactivated from User Management' }),
          new Promise((resolve) => window.setTimeout(resolve, 900))
        ]);
        setRows((current) => current.map((row) => row.userId === action.user.userId ? { ...row, status: action.value } : row));
        setInlineMessage(`${action.user.name} status updated to ${action.value}.`);
      } else {
        await Promise.all([
          omsApi.updateUserAccess(action.user.userId, { role: action.value, reason: 'Role update from User Management' }),
          new Promise((resolve) => window.setTimeout(resolve, 900))
        ]);
        setRows((current) => current.map((row) => row.userId === action.user.userId ? { ...row, role: action.value } : row));
        setInlineMessage(`${action.user.name} role updated to ${action.value}.`);
      }
    } catch (requestError) {
      setConfirmation({ title: 'Action failed', message: requestError instanceof Error ? requestError.message : 'The user action could not be submitted.' });
    } finally {
      window.clearInterval(progressTimer);
      setProgress(100);
      window.setTimeout(() => {
        setActionLoading(false);
        setProgress(0);
      }, 350);
    }
  };

  const openAddUser = () => {
    setAddForm(emptyAddForm);
    setActionDialog('add');
  };

  const confirmAddUser = () => {
    const name = `${addForm.firstName} ${addForm.lastName}`.trim();
    if (!addForm.userId || !addForm.firstName || !addForm.lastName || rows.some((user) => user.userId === addForm.userId)) return;
    setPendingAction({ kind: 'add', title: 'Confirm new user', description: 'Provision this OMS user with role-based access?', details: [['User', `${name} (${addForm.userId})`], ['Role', addForm.role], ['Status', addForm.status]] });
  };

  if (!data) {
    return (
      <Box>
        <PageHeader title="User Management" subtitle="Manage OMS role assignments and active status." badge="IAM" />
        {error ? <ApiErrorState message={error.message} onRetry={reload} /> : <ApiLoading rows={5} />}
      </Box>
    );
  }

  return (
    <Box>
      <PageHeader title="User Management" subtitle="Manage OMS role assignments and active status." badge="IAM" />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', lg: 'center' }} justifyContent="space-between">
          <TextField
            size="small"
            label="Global search"
            value={globalSearch}
            onChange={(event) => setGlobalSearch(event.target.value)}
            placeholder="Search user ID, name, role, status"
            sx={{ minWidth: { xs: '100%', lg: 380 } }}
            InputProps={{
              startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
            }}
          />
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
            <Button startIcon={<PersonAddIcon />} variant="contained" onClick={openAddUser}>Add User</Button>
            <Button
              startIcon={<EditIcon />}
              variant={inlineEditing ? 'contained' : 'outlined'}
              onClick={() => {
                setInlineEditing((current) => !current);
                setInlineMessage(!inlineEditing ? 'Inline role dropdowns are enabled.' : 'Inline editing is locked.');
              }}
            >
              Edit User
            </Button>
            <Button
              startIcon={<BlockIcon />}
              variant={statusEditing ? 'contained' : 'outlined'}
              color="error"
              onClick={() => {
                setStatusEditing((current) => !current);
                setInlineMessage(!statusEditing ? 'Active status dropdowns are enabled for disable/reactivate changes.' : 'Active status editing is locked.');
              }}
            >
              Disable User
            </Button>
          </Stack>
        </Stack>
        {inlineMessage && (
          <Alert severity="info" sx={{ mt: 1.5, borderRadius: 2, '& .MuiAlert-message': { fontWeight: 850 } }} onClose={() => setInlineMessage('')}>
            {inlineMessage}
          </Alert>
        )}
      </GlassCard>

      <GlassCard sx={{ p: 0, overflow: 'hidden' }}>
        <Box sx={{ px: 2, py: 1.4, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between">
            <Box>
              <Typography variant="subtitle1" fontWeight={950}>Enterprise Access Directory</Typography>
              <Typography variant="body2" color="text.secondary">{filteredUsers.length} matching users · Edit User controls role assignment</Typography>
            </Box>
            <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
              <Chip size="small" label={inlineEditing ? 'Role editing on' : 'Role editing locked'} color={inlineEditing ? 'primary' : 'default'} />
              <Chip size="small" label={statusEditing ? 'Status editing on' : 'Status editing locked'} color={statusEditing ? 'error' : 'default'} />
            </Stack>
          </Stack>
        </Box>
        <Box sx={{ overflowX: 'auto' }}>
          <Table size="small" sx={{ minWidth: 820 }}>
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: 160 }}>User ID</TableCell>
                <TableCell sx={{ width: 220 }}>Name</TableCell>
                <TableCell sx={{ width: 230 }}>Role</TableCell>
                <TableCell sx={{ width: 160 }}>Active Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow hover key={user.name}>
                  <TableCell>
                    <Typography fontWeight={950}>{user.userId}</Typography>
                    <Typography variant="caption" color="text.secondary">Azure SSO ID</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography fontWeight={950}>{user.name}</Typography>
                    <Typography variant="caption" color="text.secondary">{user.firstName} / {user.lastName}</Typography>
                  </TableCell>
                  <TableCell>
                    <Select
                      size="small"
                      fullWidth
                      value={user.role}
                      disabled={!inlineEditing}
                      onChange={(event) => requestUserUpdate(user, 'role', event.target.value)}
                    >
                      {roles.map((role) => <MenuItem key={role} value={role}>{role}</MenuItem>)}
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select
                      size="small"
                      fullWidth
                      value={user.status}
                      disabled={!statusEditing}
                      onChange={(event) => requestUserUpdate(user, 'status', event.target.value)}
                      sx={{
                        fontWeight: 900,
                        color: user.status === 'Active' ? 'success.main' : 'text.secondary'
                      }}
                    >
                      {statuses.map((status) => <MenuItem key={status} value={status}>{status}</MenuItem>)}
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
              {!filteredUsers.length && (
                <TableRow>
                  <TableCell colSpan={4}>
                    <Alert severity="info">No users match the current search.</Alert>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Box>
      </GlassCard>

      <Dialog
        open={actionDialog === 'add'}
        onClose={() => !actionLoading && setActionDialog(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            width: { xs: 'calc(100vw - 32px)', sm: 520 },
            borderRadius: 2.25,
            overflow: 'hidden',
            background: (theme) => theme.palette.mode === 'light'
              ? 'linear-gradient(145deg, #ffffff 0%, #eef2f6 100%)'
              : 'linear-gradient(145deg, #222936 0%, #151a23 100%)',
            boxShadow: '0 24px 70px rgba(15,23,42,.32)'
          }
        }}
      >
        <DialogTitle sx={{ p: 0 }}>
          <Box sx={{ px: 2.2, py: 1.65, color: 'common.white', background: 'linear-gradient(120deg, #111827 0%, #334155 56%, #9f1117 100%)' }}>
            <Stack direction="row" spacing={1.2} alignItems="center">
              <Box sx={{ width: 36, height: 36, borderRadius: 1.4, display: 'grid', placeItems: 'center', bgcolor: 'rgba(255,255,255,.13)', border: '1px solid rgba(255,255,255,.18)' }}>
                <PersonAddIcon fontSize="small" />
              </Box>
              <Box>
                <Typography variant="h6" fontWeight={950} sx={{ lineHeight: 1.1 }}>Add OMS User</Typography>
                <Typography variant="caption" sx={{ color: 'rgba(255,255,255,.72)', fontWeight: 750 }}>Manual Azure SSO identity provisioning</Typography>
              </Box>
            </Stack>
          </Box>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 1.6, bgcolor: 'background.default' }}>
          <Stack spacing={1.25}>
            <Box sx={{ p: 1.25, border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: 'background.paper' }}>
              <Typography variant="overline" fontWeight={950} color="text.secondary">Identity</Typography>
              <Stack spacing={1.15} sx={{ mt: 0.5 }}>
                <TextField
                  size="small"
                  label="User ID"
                  value={addForm.userId}
                  onChange={(event) => setAddForm((current) => ({ ...current, userId: event.target.value.trim().toLowerCase() }))}
                  helperText="Azure SSO / enterprise ID"
                  required
                />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.1}>
                  <TextField
                    size="small"
                    label="First Name"
                    value={addForm.firstName}
                    onChange={(event) => setAddForm((current) => ({ ...current, firstName: event.target.value }))}
                    required
                    fullWidth
                  />
                  <TextField
                    size="small"
                    label="Last Name"
                    value={addForm.lastName}
                    onChange={(event) => setAddForm((current) => ({ ...current, lastName: event.target.value }))}
                    required
                    fullWidth
                  />
                </Stack>
              </Stack>
            </Box>

            <Box sx={{ p: 1.25, border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.22), borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}>
              <Typography variant="overline" fontWeight={950} color="text.secondary">Access</Typography>
              <Stack spacing={1.15} sx={{ mt: 0.5 }}>
                <ActionSelect label="Role" value={addForm.role} options={roles} onChange={(value) => setAddForm((current) => ({ ...current, role: value }))} />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.1}>
                  <ActionSelect label="Initial Status" value={addForm.status} options={statuses} onChange={(value) => setAddForm((current) => ({ ...current, status: value }))} />
                  <ActionSelect label="Reason" value={addForm.reason} options={accessReasons} onChange={(value) => setAddForm((current) => ({ ...current, reason: value }))} />
                </Stack>
              </Stack>
            </Box>

            <Alert severity="info" variant="outlined" sx={{ py: 0.55, '& .MuiAlert-message': { fontWeight: 850 } }}>
              Submit calls the backend IAM provisioning API and records an auditable access event.
            </Alert>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 1.8, py: 1.25, bgcolor: 'background.paper' }}>
          <Button onClick={() => setActionDialog(null)} color="inherit" disabled={actionLoading}>Cancel</Button>
          <Button
            variant="contained"
            startIcon={actionLoading ? <CircularProgress color="inherit" size={16} /> : <PersonAddIcon />}
            onClick={confirmAddUser}
            disabled={actionLoading || !addForm.userId || !addForm.firstName || !addForm.lastName || rows.some((user) => user.userId === addForm.userId)}
          >
            Provision User
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={Boolean(pendingAction)} onClose={() => setPendingAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { width: { xs: 'calc(100vw - 28px)', sm: 390 }, borderRadius: 2, overflow: 'hidden' } }}>
        <DialogTitle sx={{ pb: 0.75 }}>
          <Stack direction="row" spacing={1} alignItems="center">
            <WarningAmberRoundedIcon color={pendingAction?.kind === 'status' && pendingAction.value === 'Disabled' ? 'error' : 'primary'} />
            <Box>
              <Typography variant="overline" color="text.secondary" fontWeight={900}>Review action</Typography>
              <Typography variant="h6" fontWeight={950} sx={{ lineHeight: 1.1 }}>{pendingAction?.title}</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent sx={{ pt: 1 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.25 }}>{pendingAction?.description}</Typography>
          <Stack spacing={0.7}>
            {pendingAction?.details.map(([label, value]) => (
              <Stack key={label} direction="row" justifyContent="space-between" spacing={2} sx={{ px: 1.15, py: 0.8, borderRadius: 1.25, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.055) }}>
                <Typography variant="caption" color="text.secondary" fontWeight={800}>{label}</Typography>
                <Typography variant="body2" fontWeight={900} textAlign="right">{value}</Typography>
              </Stack>
            ))}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 2, py: 1.25, borderTop: 1, borderColor: 'divider' }}>
          <Button size="small" color="inherit" onClick={() => setPendingAction(null)}>Cancel</Button>
          <Button size="small" variant="contained" color={pendingAction?.kind === 'status' && pendingAction.value === 'Disabled' ? 'error' : 'primary'} onClick={runPendingAction}>Confirm</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={actionLoading} maxWidth="xs" fullWidth PaperProps={{ sx: { width: { xs: 'calc(100vw - 28px)', sm: 390 }, borderRadius: 2 } }}>
        <DialogContent sx={{ p: 2.2 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Box>
              <Typography variant="overline" color="primary.main" fontWeight={950}>Live action tracking</Typography>
              <Typography fontWeight={950}>{progress === 100 ? 'Action complete' : 'Applying user change'}</Typography>
            </Box>
            <Typography fontWeight={950} color="primary.main">{progress}%</Typography>
          </Stack>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 999, '& .MuiLinearProgress-bar': { borderRadius: 999, transition: 'transform 180ms ease' } }} />
          <Stack direction="row" justifyContent="space-between" sx={{ mt: 1 }}>
            <Typography variant="caption" color="text.secondary">Validated</Typography>
            <Typography variant="caption" color="text.secondary">IAM request</Typography>
            <Typography variant="caption" color="text.secondary">Audit saved</Typography>
          </Stack>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(confirmation)} onClose={() => setConfirmation(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { width: { xs: 'calc(100vw - 28px)', sm: 380 }, borderRadius: 2, overflow: 'hidden' } }}>
        <DialogTitle sx={{ pb: 0.75 }}>
          <Stack direction="row" spacing={1} alignItems="center">
            <CheckCircleIcon color="success" />
            <Typography variant="h6" fontWeight={950}>{confirmation?.title}</Typography>
          </Stack>
        </DialogTitle>
        <DialogContent sx={{ pt: 0.5 }}>
          <Typography variant="body2" fontWeight={750} color="text.secondary">{confirmation?.message}</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2, pb: 1.5 }}>
          <Button size="small" variant="contained" onClick={() => setConfirmation(null)}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function ActionSelect({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) {
  return (
    <FormControl size="small" fullWidth>
      <InputLabel>{label}</InputLabel>
      <Select label={label} value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
      </Select>
    </FormControl>
  );
}
