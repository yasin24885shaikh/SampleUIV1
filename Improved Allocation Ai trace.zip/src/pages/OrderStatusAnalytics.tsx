import { useMemo, useState, type ReactNode } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  InputAdornment,
  LinearProgress,
  Pagination,
  Stack,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import BoltIcon from '@mui/icons-material/Bolt';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CloseIcon from '@mui/icons-material/Close';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import HourglassTopIcon from '@mui/icons-material/HourglassTop';
import InsightsIcon from '@mui/icons-material/Insights';
import InventoryIcon from '@mui/icons-material/Inventory';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import PsychologyIcon from '@mui/icons-material/Psychology';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import RuleIcon from '@mui/icons-material/Rule';
import SearchIcon from '@mui/icons-material/Search';
import StorefrontIcon from '@mui/icons-material/Storefront';
import TimelineIcon from '@mui/icons-material/Timeline';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import { motion } from 'framer-motion';
import { ApiErrorState, ApiLoading } from '../components/ApiFeedback';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi, type AiIconKey, type OrderStatusAiAnalyticsResponse, type OrderStatusAiFulfillmentPath, type OrderStatusAiNode, type OrderStatusAiRecommendedAction, type OrderStatusAiTransitionInsight } from '../services/omsApi';

const analysisPageSize = 2;

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function buildAnalysisCsv(insight: OrderStatusAiTransitionInsight) {
  const header = ['Transition', 'Order ID', 'Current Status', 'Age', 'Fulfillment Node', 'Stuck Reason', 'Probable Resolution', 'AI Confidence'];
  const rows = insight.stuckOrders.map((order) => [
    `${insight.from} to ${insight.to}`,
    order.orderId,
    order.currentStatus,
    order.age,
    order.fulfillmentNode,
    order.reason,
    order.probableResolution,
    `${order.confidence}%`
  ]);
  return [header, ...rows].map((row) => row.map(csvCell).join(',')).join('\n');
}

function aiIcon(iconKey: AiIconKey): ReactNode {
  const icons: Record<AiIconKey, ReactNode> = {
    factCheck: <FactCheckIcon />,
    open: <OpenInNewIcon />,
    hourglass: <HourglassTopIcon />,
    inventory: <InventoryIcon />,
    shipping: <LocalShippingIcon />,
    warehouse: <WarehouseIcon />,
    dropship: <PrecisionManufacturingIcon />,
    store: <StorefrontIcon />,
    timeline: <TimelineIcon />,
    bolt: <BoltIcon />,
    psychology: <PsychologyIcon />,
    insights: <InsightsIcon />
  };
  return icons[iconKey];
}

export default function OrderStatusAnalytics() {
  const [fromDate, setFromDate] = useState('2026-06-24');
  const [toDate, setToDate] = useState('2026-06-30');
  const [analyticsStarted, setAnalyticsStarted] = useState(false);
  const [analyticsData, setAnalyticsData] = useState<OrderStatusAiAnalyticsResponse | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsError, setAnalyticsError] = useState<Error | null>(null);
  const [activeInsight, setActiveInsight] = useState<OrderStatusAiTransitionInsight | null>(null);
  const [analysisSearch, setAnalysisSearch] = useState('');
  const [analysisPage, setAnalysisPage] = useState(1);
  const [activeAction, setActiveAction] = useState<OrderStatusAiRecommendedAction | null>(null);
  const [actionResult, setActionResult] = useState<{ action: string; owner: string; message: string } | null>(null);
  const lifecycleNodes = analyticsData?.lifecycleNodes ?? [];
  const fulfillmentGroups = analyticsData?.fulfillmentGroups ?? [];
  const transitionInsights = analyticsData?.transitionInsights ?? [];
  const aiCapabilityCards = analyticsData?.aiCapabilityCards ?? [];
  const bottleneckRankings = analyticsData?.bottleneckRankings ?? [];
  const rootCauseClusters = analyticsData?.rootCauseClusters ?? [];
  const recommendedActions = analyticsData?.recommendedActions ?? [];
  const totals = useMemo(() => {
    const volume = lifecycleNodes.reduce((total, node) => total + node.volume, 0);
    const stuck = lifecycleNodes.reduce((total, node) => total + node.stuck, 0) + fulfillmentGroups.reduce((total, path) => total + path.stuck, 0);
    return { volume, stuck, health: volume ? Math.round(((volume - stuck) / volume) * 1000) / 10 : 0 };
  }, [fulfillmentGroups, lifecycleNodes]);
  const filteredAnalysisOrders = useMemo(() => {
    if (!activeInsight) return [];
    const query = analysisSearch.trim().toLowerCase();
    if (!query) return activeInsight.stuckOrders;
    return activeInsight.stuckOrders.filter((order) => [
      order.orderId,
      order.currentStatus,
      order.age,
      order.fulfillmentNode,
      order.reason,
      order.probableResolution,
      order.confidence
    ].join(' ').toLowerCase().includes(query));
  }, [activeInsight, analysisSearch]);
  const analysisPageCount = Math.max(1, Math.ceil(filteredAnalysisOrders.length / analysisPageSize));
  const activeAnalysisPage = Math.min(analysisPage, analysisPageCount);
  const pagedAnalysisOrders = filteredAnalysisOrders.slice((activeAnalysisPage - 1) * analysisPageSize, activeAnalysisPage * analysisPageSize);
  const openInsight = (insight: OrderStatusAiTransitionInsight) => {
    setActiveInsight(insight);
    setAnalysisSearch('');
    setAnalysisPage(1);
  };
  const closeInsight = () => {
    setActiveInsight(null);
    setAnalysisSearch('');
    setAnalysisPage(1);
  };
  const confirmQueueAction = () => {
    if (!activeAction) return;
    const queuedAction = activeAction;
    setActiveAction(null);
    window.setTimeout(() => {
      setActionResult({
        action: queuedAction.action,
        owner: queuedAction.owner,
        message: `${queuedAction.action} was queued successfully for ${queuedAction.owner}. Backend orchestration will track execution in the AI action audit log.`
      });
    }, 120);
  };
  const startAnalytics = async () => {
    setAnalyticsStarted(true);
    setAnalyticsLoading(true);
    setAnalyticsError(null);
    try {
      const response = await omsApi.getOrderStatusAiAnalytics(undefined, {
        orderCreatedFrom: fromDate,
        orderCreatedTo: toDate
      });
      setAnalyticsData(response);
    } catch (requestError) {
      setAnalyticsError(requestError instanceof Error ? requestError : new Error('Unable to load AI analytics'));
    } finally {
      setAnalyticsLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minWidth: 0,
        '& .MuiTypography-body2': { fontSize: 'clamp(.8rem, .74rem + .14vw, .9rem)' },
        '& .MuiTypography-caption': { fontSize: 'clamp(.68rem, .63rem + .1vw, .76rem)' },
        '& .MuiButton-root': { fontSize: 'clamp(.76rem, .7rem + .12vw, .86rem)' },
        '& .MuiChip-root': { maxWidth: '100%' },
        '@media (max-width:1180px)': {
          '& .MuiCard-root, & .MuiPaper-root': { borderRadius: 1.5 },
          '& .MuiButton-root': { minHeight: 30, px: 1 },
          '& .MuiChip-root': { height: 21 }
        }
      }}
    >
      <PageHeader
        title="Order Status AI Analytics"
        subtitle="AI-assisted lifecycle analysis for stuck orders across status transitions, warehouses, store fulfillment, and dropship."
        badge="AI Operations"
      />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2, overflow: 'hidden' }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} justifyContent="space-between" alignItems={{ lg: 'center' }} gap={1.5}>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <Box sx={{ width: 46, height: 46, borderRadius: 2, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1) }}>
              <PsychologyIcon />
            </Box>
            <Box>
              <Typography variant="h6" fontWeight={950}>Lifecycle Diagnostics</Typography>
              <Typography variant="body2" color="text.secondary">Scan orders by created date and identify where status movement is slowing down.</Typography>
            </Box>
          </Stack>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'stretch', sm: 'center' }} sx={{ width: { xs: '100%', lg: 'auto' } }}>
            <TextField
              size="small"
              label="Order Created From"
              type="date"
              value={fromDate}
              onChange={(event) => setFromDate(event.target.value)}
              InputLabelProps={{ shrink: true }}
              InputProps={{ startAdornment: <CalendarMonthIcon sx={{ mr: 1, color: 'text.secondary', fontSize: 18 }} /> }}
              sx={{ minWidth: { sm: 160 } }}
            />
            <TextField
              size="small"
              label="Order Created To"
              type="date"
              value={toDate}
              onChange={(event) => setToDate(event.target.value)}
              InputLabelProps={{ shrink: true }}
              sx={{ minWidth: { sm: 160 } }}
            />
            <Button
              variant="contained"
              size="large"
              startIcon={<AutoAwesomeIcon />}
              onClick={startAnalytics}
              disabled={analyticsLoading}
              sx={{ minWidth: { xs: '100%', sm: 180 }, fontWeight: 950, boxShadow: '0 12px 26px rgba(23,105,224,.24)' }}
            >
              {analyticsLoading ? 'Analyzing...' : 'Start AI Analytics'}
            </Button>
          </Stack>
        </Stack>
      </GlassCard>

      {!analyticsStarted && (
        <Alert severity="info" icon={<AutoAwesomeIcon />} sx={{ mb: 2 }}>
          Select the created date range and start AI analytics to generate status blocks, stuck-order signals, and transition recommendations.
        </Alert>
      )}

      {analyticsStarted && analyticsLoading && <ApiLoading rows={6} />}
      {analyticsStarted && analyticsError && <ApiErrorState message={analyticsError.message} onRetry={startAnalytics} />}

      {analyticsStarted && analyticsData && !analyticsLoading && !analyticsError && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <Grid container spacing={1.4} sx={{ mb: 2 }}>
            <Grid item xs={12} md={4}><SummaryTile label="Orders Analyzed" value={totals.volume.toLocaleString()} tone="#1769e0" /></Grid>
            <Grid item xs={12} md={4}><SummaryTile label="Potentially Stuck" value={totals.stuck.toLocaleString()} tone="#c62828" /></Grid>
            <Grid item xs={12} md={4}><SummaryTile label="Flow Health" value={`${totals.health}%`} tone="#168a51" /></Grid>
          </Grid>

          <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2, overflow: 'hidden', background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(135deg, rgba(255,255,255,.96), rgba(231,237,246,.86))' : 'linear-gradient(135deg, rgba(35,42,52,.94), rgba(20,25,34,.94))' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.5 }}>
              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <AutoAwesomeIcon color="primary" />
                  <Typography variant="h6" fontWeight={950}>AI Command Center</Typography>
                </Stack>
                <Typography variant="body2" color="text.secondary">Predictive risk, explainable root causes, and recommended actions generated from the selected order window.</Typography>
              </Box>
              <Chip icon={<RuleIcon />} label="Explainable AI scoring active" color="primary" variant="outlined" />
            </Stack>
            <Grid container spacing={1.25}>
              {aiCapabilityCards.map((card) => (
                <Grid item xs={12} sm={6} lg={3} key={card.title}>
                  <AiCapabilityCard title={card.title} value={card.value} subtitle={card.subtitle} tone={card.tone} icon={aiIcon(card.iconKey)} />
                </Grid>
              ))}
            </Grid>
          </GlassCard>

          <Grid container spacing={1.5} sx={{ mb: 2 }}>
            <Grid item xs={12} lg={5}>
              <GlassCard sx={{ p: { xs: 1.5, md: 1.75 }, height: '100%' }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1.25 }}>
                  <QueryStatsIcon color="primary" />
                  <Box>
                    <Typography variant="subtitle1" fontWeight={950}>Bottleneck Ranking</Typography>
                    <Typography variant="body2" color="text.secondary">Highest-risk transitions sorted by predicted SLA impact.</Typography>
                  </Box>
                </Stack>
                <Stack spacing={1}>
                  {bottleneckRankings.map((item, index) => (
                    <Box key={item.lane} sx={{ p: 1.1, border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: (theme) => alpha(index === 0 ? theme.palette.error.main : theme.palette.primary.main, index === 0 ? 0.06 : 0.035) }}>
                      <Stack direction="row" justifyContent="space-between" spacing={1}>
                        <Typography fontWeight={950}>{index + 1}. {item.lane}</Typography>
                        <Chip size="small" label={`${item.risk}% risk`} color={item.risk > 85 ? 'error' : item.risk > 75 ? 'warning' : 'info'} variant="outlined" />
                      </Stack>
                      <Typography variant="body2" color="text.secondary">{item.orders} orders · {item.driver}</Typography>
                      <LinearProgress variant="determinate" value={item.risk} sx={{ mt: 0.9, height: 7, borderRadius: 999 }} color={item.risk > 85 ? 'error' : item.risk > 75 ? 'warning' : 'primary'} />
                    </Box>
                  ))}
                </Stack>
              </GlassCard>
            </Grid>
            <Grid item xs={12} lg={7}>
              <GlassCard sx={{ p: { xs: 1.5, md: 1.75 }, height: '100%' }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1.25 }}>
                  <PsychologyIcon color="primary" />
                  <Box>
                    <Typography variant="subtitle1" fontWeight={950}>Root Cause Clusters</Typography>
                    <Typography variant="body2" color="text.secondary">AI groups stuck orders into explainable operational causes.</Typography>
                  </Box>
                </Stack>
                <Grid container spacing={1}>
                  {rootCauseClusters.map((cluster) => (
                    <Grid item xs={12} md={6} key={cluster.name}>
                      <Box sx={{ p: 1.15, height: '100%', border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.58) }}>
                        <Stack direction="row" justifyContent="space-between" spacing={1} alignItems="center">
                          <Typography fontWeight={950}>{cluster.name}</Typography>
                          <Chip size="small" label={`${cluster.confidence}%`} color="primary" variant="outlined" />
                        </Stack>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.35 }}>{cluster.orders} orders</Typography>
                        <Typography variant="caption" fontWeight={850} sx={{ display: 'block', mt: 0.8 }}>{cluster.resolution}</Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </GlassCard>
            </Grid>
            <Grid item xs={12}>
              <GlassCard sx={{ p: { xs: 1.5, md: 1.75 } }}>
                <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.25 }}>
                  <Box>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <BoltIcon color="primary" />
                      <Typography variant="subtitle1" fontWeight={950}>Recommended Action Queue</Typography>
                    </Stack>
                    <Typography variant="body2" color="text.secondary">Prioritized actions the operations team can execute to move stuck orders forward.</Typography>
                  </Box>
                  <Chip label={`${recommendedActions.length} actions ready`} color="success" variant="outlined" />
                </Stack>
                <Grid container spacing={1}>
                  {recommendedActions.map((item) => (
                    <Grid item xs={12} md={6} lg={3} key={item.action}>
                      <Box sx={{ p: 1.15, height: '100%', border: 1, borderLeft: '4px solid', borderColor: 'divider', borderLeftColor: item.urgency === 'High' ? 'error.main' : 'warning.main', borderRadius: 1.75 }}>
                        <Chip size="small" label={item.urgency} color={item.urgency === 'High' ? 'error' : 'warning'} sx={{ mb: 0.8 }} />
                        <Typography fontWeight={950}>{item.action}</Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.45 }}>{item.impact}</Typography>
                        <Typography variant="caption" color="text.secondary" fontWeight={850}>Owner: {item.owner}</Typography>
                        <Button
                          fullWidth
                          size="small"
                          variant="contained"
                          startIcon={<BoltIcon />}
                          onClick={() => setActiveAction(item)}
                          sx={{ mt: 1, fontWeight: 950 }}
                        >
                          Execute Action
                        </Button>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </GlassCard>
            </Grid>
          </Grid>

          <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2, background: (theme) => theme.palette.mode === 'light' ? 'linear-gradient(135deg, rgba(255,255,255,.94), rgba(231,236,242,.78))' : 'linear-gradient(135deg, rgba(35,42,52,.92), rgba(18,23,31,.92))' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.3} alignItems={{ md: 'center' }} justifyContent="space-between" sx={{ mb: 1.6 }}>
              <Box>
                <Typography variant="h6" fontWeight={950}>Order Status Journey</Typography>
                <Typography variant="body2" color="text.secondary">Submitted → Open → Backordered → Allocated → Released → Fulfilled</Typography>
              </Box>
              <Chip icon={<AutoAwesomeIcon />} label="AI transition analysis enabled" color="primary" variant="outlined" />
            </Stack>
            <Box sx={{ maxWidth: 920, mx: 'auto' }}>
              {lifecycleNodes.map((node, index) => (
                <Box key={node.key}>
                  <StatusAnalyticsCard node={node} />
                  {index < transitionInsights.length && (
                    <TransitionInsightButton
                      insight={transitionInsights[index]}
                      onClick={() => openInsight(transitionInsights[index])}
                    />
                  )}
                </Box>
              ))}
            </Box>
          </GlassCard>

          <GlassCard sx={{ p: { xs: 1.5, md: 2 } }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 1.5 }}>
              <Box>
                <Typography variant="h6" fontWeight={950}>Released Fulfillment Paths</Typography>
                <Typography variant="body2" color="text.secondary">Released orders split first to Warehouse, Dropship, or Store. Warehouse then breaks into Milton, JC, Reno, and Camp Hill.</Typography>
              </Box>
              <Chip icon={<AutoAwesomeIcon />} label="AI analytics available on each fulfillment path" color="primary" variant="outlined" />
            </Stack>
            <Grid container spacing={1.25}>
              {fulfillmentGroups.map((path) => (
                <Grid item xs={12} sm={6} lg={4} key={path.title}>
                  <FulfillmentGroupCard path={path} onAnalyze={() => openInsight(path.insight)} />
                </Grid>
              ))}
            </Grid>
          </GlassCard>
        </motion.div>
      )}

      <Dialog open={Boolean(activeInsight)} onClose={closeInsight} maxWidth="md" fullWidth PaperProps={{ sx: { m: { xs: 1.5, sm: 2.5 }, maxHeight: { xs: 'calc(100vh - 24px)', sm: 'calc(100vh - 40px)' } } }}>
        <DialogTitle sx={{ pr: 7 }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.2} alignItems={{ sm: 'center' }} justifyContent="space-between">
            <Stack direction="row" spacing={1.2} alignItems="center">
              <Box sx={{ width: 42, height: 42, borderRadius: 2, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12) }}>
                <AutoAwesomeIcon />
              </Box>
              <Box>
                <Typography variant="h6" fontWeight={950}>AI Analytics</Typography>
                <Typography variant="body2" color="text.secondary">{activeInsight?.from} → {activeInsight?.to}</Typography>
              </Box>
            </Stack>
            {activeInsight && (
              <Button
                component="a"
                href={`data:text/csv;charset=utf-8,${encodeURIComponent(buildAnalysisCsv(activeInsight))}`}
                download={`order-status-ai-analysis-${activeInsight.from.toLowerCase()}-${activeInsight.to.toLowerCase()}.csv`}
                variant="contained"
                startIcon={<FileDownloadIcon />}
                sx={{ fontWeight: 950 }}
              >
                Export Analysis
              </Button>
            )}
          </Stack>
          <Button aria-label="Close AI analytics" onClick={closeInsight} sx={{ position: 'absolute', right: 12, top: 12, minWidth: 0, width: 38, height: 38, borderRadius: 2 }}>
            <CloseIcon />
          </Button>
        </DialogTitle>
        <DialogContent dividers sx={{ px: { xs: 1.5, md: 3 }, py: { xs: 1.5, md: 2 } }}>
          <Typography fontWeight={950} sx={{ mb: 1.2 }}>{activeInsight?.headline}</Typography>
          <Stack spacing={1}>
            {activeInsight?.details.map((detail) => (
              <Stack key={detail} direction="row" spacing={1} alignItems="center" sx={{ p: 1.1, border: 1, borderColor: 'divider', borderRadius: 1.5 }}>
                <WarningAmberIcon color="warning" fontSize="small" />
                <Typography variant="body2">{detail}</Typography>
              </Stack>
            ))}
          </Stack>
          <Divider sx={{ my: 2 }} />
          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" spacing={1} sx={{ mb: 1.3 }}>
            <Box>
              <Typography variant="subtitle1" fontWeight={950}>Stuck Order Detail</Typography>
              <Typography variant="body2" color="text.secondary">AI-ranked sample orders with likely root cause and probable resolution.</Typography>
            </Box>
            <Chip icon={<PsychologyIcon />} label={`${filteredAnalysisOrders.length} matching signals`} color="primary" variant="outlined" />
          </Stack>
          <TextField
            fullWidth
            size="small"
            label="Global search within AI analysis"
            value={analysisSearch}
            onChange={(event) => {
              setAnalysisSearch(event.target.value);
              setAnalysisPage(1);
            }}
            placeholder="Search order, status, node, reason, resolution, confidence"
            sx={{ mb: 1.25 }}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          />
          <Stack spacing={1}>
            {pagedAnalysisOrders.map((order) => (
              <Box key={order.orderId} sx={{ p: 1.25, border: 1, borderLeft: '4px solid', borderColor: 'divider', borderLeftColor: 'warning.main', borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette.warning.main, 0.045) }}>
                <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} justifyContent="space-between">
                  <Box>
                    <Stack direction="row" spacing={0.8} alignItems="center" flexWrap="wrap" useFlexGap>
                      <Typography fontWeight={950}>{order.orderId}</Typography>
                      <Chip size="small" label={order.currentStatus} color="warning" variant="outlined" />
                      <Chip size="small" label={`${order.confidence}% confidence`} color="primary" variant="outlined" />
                    </Stack>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 0.35 }}>{order.fulfillmentNode} · Aging {order.age}</Typography>
                  </Box>
                </Stack>
                <Grid container spacing={1} sx={{ mt: 0.35 }}>
                  <Grid item xs={12} md={6}>
                    <Box sx={{ p: 1, borderRadius: 1.4, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.72) }}>
                      <Typography variant="caption" color="text.secondary" fontWeight={900}>Stuck Reason</Typography>
                      <Typography variant="body2" fontWeight={800}>{order.reason}</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box sx={{ p: 1, borderRadius: 1.4, bgcolor: (theme) => alpha(theme.palette.success.main, 0.075) }}>
                      <Typography variant="caption" color="text.secondary" fontWeight={900}>Probable Resolution</Typography>
                      <Typography variant="body2" fontWeight={800}>{order.probableResolution}</Typography>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            ))}
          </Stack>
          {!filteredAnalysisOrders.length && (
            <Alert severity="info" sx={{ mt: 1.25 }}>No stuck-order analysis rows match this search.</Alert>
          )}
          {filteredAnalysisOrders.length > analysisPageSize && (
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'flex-start', sm: 'center' }} justifyContent="space-between" sx={{ mt: 1.5, pt: 1.25, borderTop: 1, borderColor: 'divider' }}>
              <Typography variant="body2" color="text.secondary">
                Showing {(activeAnalysisPage - 1) * analysisPageSize + 1}-{Math.min(activeAnalysisPage * analysisPageSize, filteredAnalysisOrders.length)} of {filteredAnalysisOrders.length} analysis rows
              </Typography>
              <Pagination count={analysisPageCount} page={activeAnalysisPage} onChange={(_, value) => setAnalysisPage(value)} color="primary" size="small" shape="rounded" />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={closeInsight} variant="outlined" startIcon={<CloseIcon />}>Close</Button>
        </DialogActions>
      </Dialog>
      <Dialog open={Boolean(activeAction)} onClose={() => setActiveAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { m: { xs: 1.5, sm: 2.5 }, width: { xs: 'calc(100vw - 28px)', sm: 500 } } }}>
        <DialogTitle>
          <Stack direction="row" spacing={1.2} alignItems="center">
            <Box sx={{ width: 42, height: 42, borderRadius: 2, display: 'grid', placeItems: 'center', color: 'success.main', bgcolor: (theme) => alpha(theme.palette.success.main, 0.12) }}>
              <BoltIcon />
            </Box>
            <Box>
              <Typography variant="h6" fontWeight={950}>Execute Recommended Action</Typography>
              <Typography variant="body2" color="text.secondary">{activeAction?.owner}</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Typography fontWeight={950}>{activeAction?.action}</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.8 }}>{activeAction?.impact}</Typography>
          <Alert severity={activeAction?.urgency === 'High' ? 'error' : 'warning'} sx={{ mt: 1.5 }}>
            This action will be queued to backend orchestration and tracked in the AI action audit log.
          </Alert>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setActiveAction(null)} color="inherit">Close</Button>
          <Button variant="contained" startIcon={<BoltIcon />} onClick={confirmQueueAction}>Confirm Queue Action</Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={Boolean(actionResult)}
        onClose={() => setActionResult(null)}
        maxWidth={false}
        fullWidth
        PaperProps={{
          sx: {
            m: { xs: 1.5, sm: 2.5 },
            width: { xs: 'calc(100vw - 32px)', sm: 420 },
            borderRadius: 2.25,
            overflow: 'hidden',
            border: 1,
            borderColor: 'success.main',
            boxShadow: '0 24px 70px rgba(15,23,42,.28)'
          }
        }}
      >
        <DialogTitle sx={{ px: 2.25, py: 2, background: 'linear-gradient(120deg, #e8fff3, #ffffff 72%)' }}>
          <Stack direction="row" spacing={1.15} alignItems="center">
            <Box sx={{ width: 38, height: 38, borderRadius: 1.6, display: 'grid', placeItems: 'center', color: 'success.main', bgcolor: (theme) => alpha(theme.palette.success.main, 0.12), border: 1, borderColor: (theme) => alpha(theme.palette.success.main, 0.22) }}>
              <BoltIcon />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" fontWeight={950}>AI action queued</Typography>
              <Typography variant="body2" color="text.secondary">{actionResult?.owner}</Typography>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent dividers sx={{ px: 2.25, py: 1.75 }}>
          <Typography fontWeight={950} sx={{ mb: 0.55 }}>{actionResult?.action}</Typography>
          <Typography sx={{ color: '#111827', fontWeight: 850, lineHeight: 1.45 }}>{actionResult?.message}</Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2.25, py: 1.5 }}>
          <Button variant="contained" startIcon={<BoltIcon />} onClick={() => setActionResult(null)}>Done</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

function SummaryTile({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <GlassCard sx={{ p: 1.6, borderLeft: '4px solid', borderLeftColor: tone, bgcolor: alpha(tone, 0.055) }}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Typography variant="h5" fontWeight={950}>{value}</Typography>
    </GlassCard>
  );
}

function AiCapabilityCard({ title, value, subtitle, tone, icon }: { title: string; value: string; subtitle: string; tone: string; icon: ReactNode }) {
  return (
    <Box sx={{ p: 1.35, height: '100%', border: 1, borderColor: alpha(tone, 0.24), borderRadius: 2, bgcolor: alpha(tone, 0.06), boxShadow: `0 12px 28px ${alpha(tone, 0.08)}` }}>
      <Stack direction="row" spacing={1} alignItems="center">
        <Box sx={{ width: 38, height: 38, borderRadius: 1.6, display: 'grid', placeItems: 'center', color: tone, bgcolor: alpha(tone, 0.12), '& svg': { fontSize: 21 } }}>{icon}</Box>
        <Box>
          <Typography variant="caption" color="text.secondary" fontWeight={900}>{title}</Typography>
          <Typography variant="h6" fontWeight={950} lineHeight={1.05}>{value}</Typography>
        </Box>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.9 }}>{subtitle}</Typography>
    </Box>
  );
}

function StatusAnalyticsCard({ node }: { node: OrderStatusAiNode }) {
  const stuckRate = Math.round((node.stuck / node.volume) * 1000) / 10;
  return (
    <Box sx={{ minWidth: 0, p: { xs: 1.25, md: 1.55 }, border: 1, borderLeft: '5px solid', borderColor: alpha(node.accent, 0.24), borderLeftColor: node.accent, borderRadius: 2.25, bgcolor: (theme) => theme.palette.mode === 'light' ? alpha('#ffffff', 0.9) : alpha(theme.palette.background.paper, 0.8), boxShadow: `0 16px 34px ${alpha(node.accent, 0.12)}` }}>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ md: 'center' }} justifyContent="space-between">
        <Stack direction="row" spacing={1.15} alignItems="center" sx={{ minWidth: 0 }}>
          <Box sx={{ width: 44, height: 44, borderRadius: 1.8, display: 'grid', placeItems: 'center', color: node.accent, bgcolor: alpha(node.accent, 0.12), '& svg': { fontSize: 24 } }}>
            {aiIcon(node.iconKey)}
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="h6" fontWeight={950} lineHeight={1.1}>{node.title}</Typography>
            <Typography variant="body2" color="text.secondary">{node.description}</Typography>
          </Box>
        </Stack>
        <Box sx={{ minWidth: { md: 260 } }}>
          <Stack direction="row" spacing={1} sx={{ mb: 0.8 }}>
            <Chip size="small" label={`${node.volume.toLocaleString()} orders`} variant="outlined" />
            <Chip size="small" label={`${node.stuck.toLocaleString()} stuck`} color={node.stuck > 250 ? 'error' : 'warning'} variant="outlined" />
          </Stack>
          <MetricLine label="Avg Age" value={node.avgAge} />
          <MetricLine label="SLA Target" value={node.sla} />
        </Box>
      </Stack>
      <LinearProgress variant="determinate" value={Math.min(stuckRate * 8, 100)} sx={{ mt: 1.2, height: 7, borderRadius: 999, bgcolor: alpha(node.accent, 0.12), '& .MuiLinearProgress-bar': { bgcolor: node.stuck > 250 ? 'error.main' : node.accent } }} />
    </Box>
  );
}

function TransitionInsightButton({ insight, onClick }: { insight: OrderStatusAiTransitionInsight; onClick: () => void }) {
  return (
    <Button
      variant="outlined"
      startIcon={<AutoAwesomeIcon />}
      onClick={onClick}
      sx={{
        display: 'flex',
        mx: 'auto',
        my: 1,
        minWidth: 190,
        borderRadius: 999,
        fontWeight: 950,
        bgcolor: (theme) => alpha(theme.palette.background.paper, 0.8),
        position: 'relative',
        zIndex: 1,
        whiteSpace: 'nowrap',
        '&:before, &:after': {
          content: '""',
          position: 'absolute',
          left: '50%',
          width: 2,
          height: 18,
          bgcolor: (theme) => alpha(theme.palette.primary.main, 0.45),
          transform: 'translateX(-50%)',
          zIndex: -1
        },
        '&:before': { top: -18 },
        '&:after': { bottom: -18 }
      }}
    >
      AI Analytics
    </Button>
  );
}

function FulfillmentGroupCard({ path, onAnalyze }: { path: OrderStatusAiFulfillmentPath; onAnalyze: () => void }) {
  const stuckRate = Math.round((path.stuck / path.volume) * 1000) / 10;
  return (
    <Box sx={{ p: 1.35, height: '100%', border: 1, borderTop: '4px solid', borderColor: alpha(path.accent, 0.25), borderTopColor: path.accent, borderRadius: 2, bgcolor: alpha(path.accent, 0.055) }}>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} alignItems={{ xs: 'stretch', md: 'flex-start' }} justifyContent="space-between" sx={{ mb: 1 }}>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
          <Box sx={{ width: 36, height: 36, flex: '0 0 auto', borderRadius: 1.5, display: 'grid', placeItems: 'center', color: path.accent, bgcolor: alpha(path.accent, 0.13), '& svg': { fontSize: 20 } }}>{aiIcon(path.iconKey)}</Box>
          <Box sx={{ minWidth: 0 }}>
            <Typography fontWeight={950}>{path.title}</Typography>
            <Typography variant="caption" color="text.secondary">{path.subtitle}</Typography>
          </Box>
        </Stack>
        <Button
          size="small"
          variant="contained"
          startIcon={<AutoAwesomeIcon />}
          onClick={onAnalyze}
          sx={{
            flex: { md: '0 0 auto' },
            minHeight: 30,
            px: 1,
            borderRadius: 999,
            fontSize: '0.74rem',
            fontWeight: 950,
            whiteSpace: 'nowrap',
            color: '#ffffff',
            background: `linear-gradient(135deg, ${path.accent}, ${alpha(path.accent, 0.76)})`,
            boxShadow: `0 10px 22px ${alpha(path.accent, 0.22)}`,
            '&:hover': {
              background: `linear-gradient(135deg, ${path.accent}, ${alpha(path.accent, 0.88)})`,
              boxShadow: `0 12px 26px ${alpha(path.accent, 0.28)}`
            }
          }}
        >
          AI Analytics
        </Button>
      </Stack>
      <MetricLine label="Released" value={path.volume.toLocaleString()} />
      <MetricLine label="Stuck" value={`${path.stuck.toLocaleString()} (${stuckRate}%)`} alert={path.stuck > 40} />
      <LinearProgress variant="determinate" value={Math.min(stuckRate * 10, 100)} sx={{ mt: 1, height: 7, borderRadius: 999, '& .MuiLinearProgress-bar': { bgcolor: path.stuck > 40 ? 'warning.main' : path.accent } }} />
      {path.children && (
        <Box sx={{ mt: 1.25, pt: 1.25, borderTop: 1, borderColor: alpha(path.accent, 0.22) }}>
          <Typography variant="caption" color="text.secondary" fontWeight={900}>Warehouse Breakdown</Typography>
          <Stack spacing={0.85} sx={{ mt: 0.75 }}>
            {path.children.map((child) => (
              <Box key={child.title} sx={{ p: 0.95, border: 1, borderLeft: '4px solid', borderColor: alpha(child.accent, 0.22), borderLeftColor: child.accent, borderRadius: 1.5, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.62) }}>
                <Stack direction="row" justifyContent="space-between" spacing={1} alignItems="center">
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="body2" fontWeight={950}>{child.title}</Typography>
                    <Typography variant="caption" color="text.secondary">{child.subtitle}</Typography>
                  </Box>
                  <Chip size="small" label={`${child.stuck} stuck`} color={child.stuck > 40 ? 'warning' : 'default'} variant="outlined" />
                </Stack>
                <MetricLine label="Released" value={child.volume.toLocaleString()} />
              </Box>
            ))}
          </Stack>
        </Box>
      )}
    </Box>
  );
}

function MetricLine({ label, value, alert = false }: { label: string; value: string; alert?: boolean }) {
  return (
    <Stack direction="row" justifyContent="space-between" spacing={1}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Typography variant="caption" fontWeight={950} color={alert ? 'error.main' : 'text.primary'}>{value}</Typography>
    </Stack>
  );
}
