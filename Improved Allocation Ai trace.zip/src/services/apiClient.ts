import { authConfig } from '../config/authConfig';
import { authTokenStore } from './authTokenStore';

export type QueryValue = string | number | boolean | null | undefined;

export class ApiError extends Error {
  status: number;
  details: unknown;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

type RequestOptions = Omit<RequestInit, 'body'> & {
  body?: unknown;
  query?: Record<string, QueryValue | QueryValue[]>;
};

const baseUrl = (import.meta.env.VITE_API_BASE_URL || '/api/v1').replace(/\/$/, '');
const requestTimeout = Number(import.meta.env.VITE_API_TIMEOUT_MS || 15000);
type HeaderMap = Record<string, string>;
type RequestInterceptor = (headers: HeaderMap, options: RequestOptions) => HeaderMap | Promise<HeaderMap>;

const requestInterceptors: RequestInterceptor[] = [];

function createCorrelationId() {
  return window.crypto?.randomUUID?.() ?? `corr-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function normalizeHeaders(headers?: HeadersInit): HeaderMap {
  if (!headers) return {};
  if (headers instanceof Headers) return Object.fromEntries(headers.entries());
  if (Array.isArray(headers)) return Object.fromEntries(headers);
  return { ...headers };
}

async function createDefaultHeaders(body?: unknown): Promise<HeaderMap> {
  const token = await authTokenStore.getAccessToken();
  return {
    Accept: 'application/json',
    'X-Application-Name': authConfig.appName,
    'X-Client-Version': authConfig.appVersion,
    'X-Environment': authConfig.environment,
    'X-Correlation-ID': createCorrelationId(),
    ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

requestInterceptors.push(async (headers, options) => ({
  ...(await createDefaultHeaders(options.body)),
  ...headers
}));

async function applyRequestInterceptors(options: RequestOptions) {
  let headers = normalizeHeaders(options.headers);
  for (const interceptor of requestInterceptors) {
    headers = await interceptor(headers, options);
  }
  return headers;
}

function createUrl(path: string, query?: RequestOptions['query']) {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const url = `${baseUrl}${normalizedPath}`;
  if (!query) return url;

  const params = new URLSearchParams();
  Object.entries(query).forEach(([key, rawValue]) => {
    const values = Array.isArray(rawValue) ? rawValue : [rawValue];
    values.forEach((value) => {
      if (value !== null && value !== undefined && value !== '') params.append(key, String(value));
    });
  });
  const search = params.toString();
  return search ? `${url}?${search}` : url;
}

async function parseResponse(response: Response) {
  if (response.status === 204) return undefined;
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) return response.json();
  return response.text();
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), requestTimeout);
  const onAbort = () => controller.abort();
  options.signal?.addEventListener('abort', onAbort, { once: true });

  try {
    const headers = await applyRequestInterceptors(options);
    const response = await fetch(createUrl(path, options.query), {
      ...options,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      credentials: 'include',
      headers,
      signal: controller.signal
    });
    const payload = await parseResponse(response);
    if (!response.ok) {
      const message = typeof payload === 'object' && payload && 'message' in payload
        ? String(payload.message)
        : `Request failed with status ${response.status}`;
      throw new ApiError(message, response.status, payload);
    }
    return payload as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (controller.signal.aborted && !options.signal?.aborted) {
      throw new ApiError('The request timed out. Please try again.', 408);
    }
    throw error;
  } finally {
    window.clearTimeout(timeoutId);
    options.signal?.removeEventListener('abort', onAbort);
  }
}

export const apiClient = {
  addRequestInterceptor: (interceptor: RequestInterceptor) => {
    requestInterceptors.push(interceptor);
    return () => {
      const index = requestInterceptors.indexOf(interceptor);
      if (index >= 0) requestInterceptors.splice(index, 1);
    };
  },
  get: <T>(path: string, options: Omit<RequestOptions, 'method' | 'body'> = {}) => request<T>(path, { ...options, method: 'GET' }),
  post: <T>(path: string, body?: unknown, options: Omit<RequestOptions, 'method' | 'body'> = {}) => request<T>(path, { ...options, method: 'POST', body }),
  put: <T>(path: string, body?: unknown, options: Omit<RequestOptions, 'method' | 'body'> = {}) => request<T>(path, { ...options, method: 'PUT', body }),
  patch: <T>(path: string, body?: unknown, options: Omit<RequestOptions, 'method' | 'body'> = {}) => request<T>(path, { ...options, method: 'PATCH', body }),
  delete: <T>(path: string, options: Omit<RequestOptions, 'method' | 'body'> = {}) => request<T>(path, { ...options, method: 'DELETE' })
};

export const apiConfiguration = {
  baseUrl,
  useMockApi: import.meta.env.VITE_USE_MOCK_API !== 'false'
};
