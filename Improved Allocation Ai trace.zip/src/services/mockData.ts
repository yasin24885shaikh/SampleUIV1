import type { OrderStatus } from '../utils/status';

export type Release = {
  releaseNumber: string;
  releaseLineId: string;
  orderLineId: string;
  lineNumber: string;
  sku: string;
  productName: string;
  orderedQty: number;
  lineTotal: number;
  cancelledTotal: number;
  currentStatus: OrderStatus;
  itemId: string;
  releaseStatus: string;
  releaseDate: string;
  fulfillmentMethod: string;
  quantity: number;
  fulfilledQty: number;
  cancelledQty: number;
  assignedNode: string;
  assignedNodeType: string;
  updatedDate: string;
};

export type OrderLine = {
  lineNumber: string;
  sku: string;
  productName: string;
  orderedQty: number;
  lineTotal: number;
  cancelledTotal: number;
  currentStatus: OrderStatus;
};

export type FulfillmentNode = {
  type: string;
  id: string;
  name: string;
  location?: string;
  inventoryAvailable?: number;
  allocatedQty?: number;
  pickStatus?: string;
  supplierId?: string;
  asnNumber?: string;
  shipmentStatus?: string;
};

export type Fulfillment = {
  fulfillmentId: string;
  type: string;
  nodeId: string;
  nodeName: string;
  status: string;
  releaseNumber: string;
  releaseLineId: string;
  packageId: string;
  packageDetailId: string;
  shipmentId: string;
  quantity: number;
  shipVia: string;
  trackingNumber: string;
  createdDate?: string;
  updatedDate?: string;
};

export type CustomerCommunication = {
  dateTime: string;
  channel: string;
  agent: string;
  direction: string;
  summary: string;
  caseId: string;
};

export type OrderAddress = {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
};

export type Order = {
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  orderDate: string;
  orderType: string;
  enterprise: string;
  organization: string;
  paymentStatus: string;
  shippingAddress?: OrderAddress;
  billingAddress?: OrderAddress;
  returnOrderId?: string;
  totalAmount: number;
  status: OrderStatus;
  onHold: boolean;
  holdReason?: string;
  totalUnits: number;
  fulfillmentTypeSummary: string;
  fulfillmentType: 'DC' | 'Store' | 'Supplier' | 'WIP' | any;
  communications: CustomerCommunication[];
  releases: Release[];
  nodes: FulfillmentNode[];
  fulfillments: Fulfillment[];
};

const featuredOrders: Order[] = [
  {
    orderNumber: 'FL-10048291',
    customerId: 'C-778193',
    customerName: 'Maya Johnson',
    customerEmail: 'maya.johnson@example.com',
    orderDate: '2026-06-19',
    orderType: 'Web',
    enterprise: 'Foot Locker North America',
    organization: 'FL-US',
    paymentStatus: 'Authorized',
    totalAmount: 1299.96,
    status: 'Released',
    onHold: true,
    holdReason: 'Address verification required',
    totalUnits: 14,
    fulfillmentTypeSummary: '8 warehouse releases, 2 store pickups, 2 supplier releases',
    fulfillmentType: 'DC',
    communications: [
      { dateTime: '2026-06-22 10:14 CT', channel: 'Email', agent: 'Erica Stone', direction: 'Outbound', summary: 'Requested confirmation of the delivery address before release.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-22 11:02 CT', channel: 'Phone', agent: 'Sam Reed', direction: 'Inbound', summary: 'Customer confirmed billing and delivery address details.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-22 11:18 CT', channel: 'Internal Note', agent: 'Fraud Operations', direction: 'Internal', summary: 'Address review completed; hold queued for release.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-22 12:06 CT', channel: 'Internal Note', agent: 'OMS Operations', direction: 'Internal', summary: 'Split fulfillment created across JC, Camp Hill, Reno, Milton, store, and supplier nodes.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-23 08:42 CT', channel: 'SMS', agent: 'Order Notifications', direction: 'Outbound', summary: 'Customer notified that the first warehouse package shipped.', caseId: 'CASE-90418' },
      { dateTime: '2026-06-23 10:15 CT', channel: 'Chat', agent: 'Leah Carter', direction: 'Inbound', summary: 'Customer requested an update on remaining split shipments.', caseId: 'CASE-90418' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900142',
        releaseLineId: '1',
        orderLineId: '1.1',
        lineNumber: '1.1',
        sku: 'FV5029-141',
        productName: 'Nike Air Max Dn White Metallic Silver',
        orderedQty: 1,
        lineTotal: 139.99,
        cancelledTotal: 0,
        currentStatus: 'Released',
        itemId: 'FV5029-141',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'DC Ship',
        quantity: 2,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'ATL-DC-01',
        assignedNodeType: 'DC',
        updatedDate: '2026-06-20 14:32 CT'
      },
      {
        releaseNumber: 'REL-900143',
        releaseLineId: '2',
        orderLineId: '2.1',
        lineNumber: '2.1',
        sku: 'ID3715',
        productName: 'adidas Samba OG Cloud White',
        orderedQty: 3,
        lineTotal: 209.97,
        cancelledTotal: 0,
        currentStatus: 'Allocated',
        itemId: 'ID3715',
        releaseStatus: 'Allocated',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Store Pickup',
        quantity: 1,
        fulfilledQty: 1,
        cancelledQty: 0,
        assignedNode: 'ST-1842',
        assignedNodeType: 'Store',
        updatedDate: '2026-06-20 15:08 CT'
      },
      {
        releaseNumber: 'REL-900144',
        releaseLineId: '3',
        orderLineId: '2.1',
        lineNumber: '2.1',
        sku: 'ID3715',
        productName: 'adidas Samba OG Cloud White',
        orderedQty: 3,
        lineTotal: 209.97,
        cancelledTotal: 0,
        currentStatus: 'Allocated',
        itemId: 'ID3715',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'DC Ship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'JC-WH-01',
        assignedNodeType: 'DC',
        updatedDate: '2026-06-20 16:24 CT'
      },
      {
        releaseNumber: 'REL-900145',
        releaseLineId: '4',
        orderLineId: '2.1',
        lineNumber: '2.1',
        sku: 'ID3715',
        productName: 'adidas Samba OG Cloud White',
        orderedQty: 3,
        lineTotal: 209.97,
        cancelledTotal: 0,
        currentStatus: 'Allocated',
        itemId: 'ID3715',
        releaseStatus: 'Released',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Dropship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'DS-NIKE-08',
        assignedNodeType: 'Supplier',
        updatedDate: '2026-06-20 16:41 CT'
      },
      {
        releaseNumber: 'REL-900146', releaseLineId: '5', orderLineId: '3.1', lineNumber: '3.1', sku: 'U9060ECA',
        productName: 'New Balance 9060 Sea Salt', orderedQty: 1, lineTotal: 90, cancelledTotal: 0, currentStatus: 'Fulfilled',
        itemId: 'U9060ECA', releaseStatus: 'Fulfilled', releaseDate: '2026-06-21', fulfillmentMethod: 'DC Ship', quantity: 1,
        fulfilledQty: 1, cancelledQty: 0, assignedNode: 'CAMP-HILL-WH-01', assignedNodeType: 'DC', updatedDate: '2026-06-22 08:14 CT'
      },
      {
        releaseNumber: 'REL-900147', releaseLineId: '6', orderLineId: '4.1', lineNumber: '4.1', sku: 'BB550VTA',
        productName: 'New Balance 550 Varsity Team', orderedQty: 2, lineTotal: 120, cancelledTotal: 0, currentStatus: 'Delivered',
        itemId: 'BB550VTA', releaseStatus: 'Delivered', releaseDate: '2026-06-21', fulfillmentMethod: 'DC Ship', quantity: 2,
        fulfilledQty: 2, cancelledQty: 0, assignedNode: 'RENO-WH-02', assignedNodeType: 'DC', updatedDate: '2026-06-23 16:37 CT'
      },
      {
        releaseNumber: 'REL-900148', releaseLineId: '7', orderLineId: '5.1', lineNumber: '5.1', sku: 'HF2903-100',
        productName: 'Jordan Retro 4 White Thunder', orderedQty: 1, lineTotal: 180, cancelledTotal: 0, currentStatus: 'Packed',
        itemId: 'HF2903-100', releaseStatus: 'Packed', releaseDate: '2026-06-21', fulfillmentMethod: 'DC Ship', quantity: 1,
        fulfilledQty: 0, cancelledQty: 0, assignedNode: 'MILTON-WH-01', assignedNodeType: 'DC', updatedDate: '2026-06-23 12:20 CT'
      },
      {
        releaseNumber: 'REL-900149', releaseLineId: '8', orderLineId: '6.1', lineNumber: '6.1', sku: '396403-01',
        productName: 'PUMA Palermo Leather White Green', orderedQty: 1, lineTotal: 75, cancelledTotal: 75, currentStatus: 'Cancelled',
        itemId: '396403-01', releaseStatus: 'Cancelled', releaseDate: '2026-06-21', fulfillmentMethod: 'DC Ship', quantity: 1,
        fulfilledQty: 0, cancelledQty: 1, assignedNode: 'ATL-DC-01', assignedNodeType: 'DC', updatedDate: '2026-06-21 17:08 CT'
      },
      {
        releaseNumber: 'REL-900150', releaseLineId: '9', orderLineId: '7.1', lineNumber: '7.1', sku: 'JI2734',
        productName: 'adidas Adizero EVO SL Core Black', orderedQty: 2, lineTotal: 160, cancelledTotal: 0, currentStatus: 'Picked',
        itemId: 'JI2734', releaseStatus: 'Picked', releaseDate: '2026-06-21', fulfillmentMethod: 'DC Ship', quantity: 2,
        fulfilledQty: 0, cancelledQty: 0, assignedNode: 'JC-WH-01', assignedNodeType: 'DC', updatedDate: '2026-06-23 11:48 CT'
      },
      {
        releaseNumber: 'REL-900151', releaseLineId: '10', orderLineId: '8.1', lineNumber: '8.1', sku: 'A12363C',
        productName: 'Converse Weapon Ox Egret', orderedQty: 1, lineTotal: 110, cancelledTotal: 0, currentStatus: 'In Process',
        itemId: 'A12363C', releaseStatus: 'In Process', releaseDate: '2026-06-21', fulfillmentMethod: 'Store Pickup', quantity: 1,
        fulfilledQty: 0, cancelledQty: 0, assignedNode: 'ST-2044', assignedNodeType: 'Store', updatedDate: '2026-06-23 10:31 CT'
      },
      {
        releaseNumber: 'REL-900152', releaseLineId: '11', orderLineId: '9.1', lineNumber: '9.1', sku: 'DZ5485-612',
        productName: 'Nike Dunk Low University Red', orderedQty: 1, lineTotal: 130, cancelledTotal: 0, currentStatus: 'Released',
        itemId: 'DZ5485-612', releaseStatus: 'Released', releaseDate: '2026-06-22', fulfillmentMethod: 'Supplier Direct', quantity: 1,
        fulfilledQty: 0, cancelledQty: 0, assignedNode: 'DS-ADI-04', assignedNodeType: 'Supplier', updatedDate: '2026-06-23 09:54 CT'
      },
      {
        releaseNumber: 'REL-900153', releaseLineId: '12', orderLineId: '10.1', lineNumber: '10.1', sku: 'U740WM2',
        productName: 'New Balance 740 White Midnight', orderedQty: 1, lineTotal: 85, cancelledTotal: 0, currentStatus: 'Back Ordered',
        itemId: 'U740WM2', releaseStatus: 'Back Ordered', releaseDate: '2026-06-22', fulfillmentMethod: 'DC Ship', quantity: 1,
        fulfilledQty: 0, cancelledQty: 0, assignedNode: 'CAMP-HILL-WH-01', assignedNodeType: 'DC', updatedDate: '2026-06-23 09:18 CT'
      }
    ],
    nodes: [
      {
        type: 'Distribution Center',
        id: 'ATL-DC-01',
        name: 'Atlanta Distribution Campus',
        inventoryAvailable: 1840,
        allocatedQty: 2
      },
      {
        type: 'Store Fulfillment',
        id: 'ST-1842',
        name: 'Foot Locker Lenox Square',
        location: 'Atlanta, GA',
        pickStatus: 'Awaiting Pick'
      },
      { type: 'Distribution Center', id: 'JC-WH-01', name: 'JC Warehouse', inventoryAvailable: 932, allocatedQty: 3 },
      { type: 'Distribution Center', id: 'CAMP-HILL-WH-01', name: 'Camp Hill Warehouse', inventoryAvailable: 684, allocatedQty: 2 },
      { type: 'Distribution Center', id: 'RENO-WH-02', name: 'Reno Warehouse', inventoryAvailable: 511, allocatedQty: 2 },
      { type: 'Distribution Center', id: 'MILTON-WH-01', name: 'Milton Warehouse', inventoryAvailable: 429, allocatedQty: 1 },
      { type: 'Store Fulfillment', id: 'ST-2044', name: 'Foot Locker Perimeter Mall', location: 'Atlanta, GA', pickStatus: 'Pick Started' },
      { type: 'Supplier Fulfillment', id: 'DS-ADI-04', name: 'adidas Direct Network', supplierId: 'ADI-US', asnNumber: 'Pending', shipmentStatus: 'Awaiting ASN' }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610041',
        type: 'Warehouse',
        nodeId: 'JC-WH-01',
        nodeName: 'JC Warehouse',
        status: 'Manifested',
        releaseNumber: 'REL-900142',
        releaseLineId: '1',
        packageId: 'PKG-770142',
        packageDetailId: 'PKGD-770142-01',
        shipmentId: 'SHP-550142',
        quantity: 1,
        shipVia: 'UPS Ground',
        trackingNumber: '1ZFL6100418821'
      },
      {
        fulfillmentId: 'FUL-610042',
        type: 'Store',
        nodeId: 'ST-1842',
        nodeName: 'Foot Locker Lenox Square',
        status: 'Ready for Pickup',
        releaseNumber: 'REL-900143',
        releaseLineId: '2',
        packageId: 'PKG-770143',
        packageDetailId: 'PKGD-770143-01',
        shipmentId: 'SHP-550143',
        quantity: 1,
        shipVia: 'Store Pickup',
        trackingNumber: 'PICKUP-1842-143'
      },
      {
        fulfillmentId: 'FUL-610044',
        type: 'Warehouse',
        nodeId: 'JC-WH-01',
        nodeName: 'JC Warehouse',
        status: 'Awaiting Pick',
        releaseNumber: 'REL-900144',
        releaseLineId: '3',
        packageId: 'PKG-770145',
        packageDetailId: 'PKGD-770145-01',
        shipmentId: 'SHP-550145',
        quantity: 1,
        shipVia: 'UPS Ground',
        trackingNumber: 'Pending'
      },
      {
        fulfillmentId: 'FUL-610043',
        type: 'Dropship',
        nodeId: 'DS-NIKE-08',
        nodeName: 'Nike Dropship Network',
        status: 'Label Created',
        releaseNumber: 'REL-900145',
        releaseLineId: '4',
        packageId: 'PKG-770144',
        packageDetailId: 'PKGD-770144-01',
        shipmentId: 'SHP-550144',
        quantity: 1,
        shipVia: 'FedEx Home Delivery',
        trackingNumber: '784512903661'
      },
      {
        fulfillmentId: 'FUL-610046', type: 'Warehouse', nodeId: 'CAMP-HILL-WH-01', nodeName: 'Camp Hill Warehouse', status: 'Shipped',
        releaseNumber: 'REL-900146', releaseLineId: '5', packageId: 'PKG-770146', packageDetailId: 'PKGD-770146-01',
        shipmentId: 'SHP-550146', quantity: 1, shipVia: 'UPS Ground', trackingNumber: '1ZFL6100461194', createdDate: '2026-06-21 07:42 CT', updatedDate: '2026-06-22 08:14 CT'
      },
      {
        fulfillmentId: 'FUL-610047', type: 'Warehouse', nodeId: 'RENO-WH-02', nodeName: 'Reno Warehouse', status: 'Delivered',
        releaseNumber: 'REL-900147', releaseLineId: '6', packageId: 'PKG-770147', packageDetailId: 'PKGD-770147-01',
        shipmentId: 'SHP-550147', quantity: 2, shipVia: 'FedEx Ground', trackingNumber: '784512906147', createdDate: '2026-06-21 08:11 CT', updatedDate: '2026-06-23 16:37 CT'
      },
      {
        fulfillmentId: 'FUL-610048', type: 'Warehouse', nodeId: 'MILTON-WH-01', nodeName: 'Milton Warehouse', status: 'Packed',
        releaseNumber: 'REL-900148', releaseLineId: '7', packageId: 'PKG-770148', packageDetailId: 'PKGD-770148-01',
        shipmentId: 'SHP-550148', quantity: 1, shipVia: 'UPS SurePost', trackingNumber: 'Pending', createdDate: '2026-06-21 09:03 CT', updatedDate: '2026-06-23 12:20 CT'
      },
      {
        fulfillmentId: 'FUL-610049', type: 'Warehouse', nodeId: 'ATL-DC-01', nodeName: 'Atlanta Distribution Campus', status: 'Cancelled',
        releaseNumber: 'REL-900149', releaseLineId: '8', packageId: 'PKG-770149', packageDetailId: 'PKGD-770149-01',
        shipmentId: 'SHP-550149', quantity: 1, shipVia: 'Not Assigned', trackingNumber: 'Cancelled', createdDate: '2026-06-21 09:19 CT', updatedDate: '2026-06-21 17:08 CT'
      },
      {
        fulfillmentId: 'FUL-610050', type: 'Warehouse', nodeId: 'JC-WH-01', nodeName: 'JC Warehouse', status: 'Picked',
        releaseNumber: 'REL-900150', releaseLineId: '9', packageId: 'PKG-770150', packageDetailId: 'PKGD-770150-01',
        shipmentId: 'SHP-550150', quantity: 2, shipVia: 'UPS Ground', trackingNumber: 'Pending', createdDate: '2026-06-21 10:28 CT', updatedDate: '2026-06-23 11:48 CT'
      },
      {
        fulfillmentId: 'FUL-610051', type: 'Store', nodeId: 'ST-2044', nodeName: 'Foot Locker Perimeter Mall', status: 'Pick Started',
        releaseNumber: 'REL-900151', releaseLineId: '10', packageId: 'PKG-770151', packageDetailId: 'PKGD-770151-01',
        shipmentId: 'SHP-550151', quantity: 1, shipVia: 'Store Pickup', trackingNumber: 'PICKUP-2044-151', createdDate: '2026-06-21 11:02 CT', updatedDate: '2026-06-23 10:31 CT'
      },
      {
        fulfillmentId: 'FUL-610052', type: 'Supplier', nodeId: 'DS-ADI-04', nodeName: 'adidas Direct Network', status: 'Awaiting ASN',
        releaseNumber: 'REL-900152', releaseLineId: '11', packageId: 'PKG-770152', packageDetailId: 'PKGD-770152-01',
        shipmentId: 'SHP-550152', quantity: 1, shipVia: 'FedEx Home Delivery', trackingNumber: 'Pending', createdDate: '2026-06-22 08:07 CT', updatedDate: '2026-06-23 09:54 CT'
      },
      {
        fulfillmentId: 'FUL-610053', type: 'Warehouse', nodeId: 'CAMP-HILL-WH-01', nodeName: 'Camp Hill Warehouse', status: 'Backorder',
        releaseNumber: 'REL-900153', releaseLineId: '12', packageId: 'Pending', packageDetailId: 'Pending',
        shipmentId: 'Pending', quantity: 1, shipVia: 'Not Assigned', trackingNumber: 'Pending', createdDate: '2026-06-22 08:26 CT', updatedDate: '2026-06-23 09:18 CT'
      }
    ]
  },
  {
    orderNumber: 'FL-10048307',
    customerId: 'C-554028',
    customerName: 'Daniel Kim',
    customerEmail: 'daniel.kim@example.com',
    orderDate: '2026-06-20',
    orderType: 'Launch',
    enterprise: 'Foot Locker North America',
    organization: 'CH-US',
    paymentStatus: 'Captured',
    totalAmount: 219.99,
    status: 'Fulfilled',
    onHold: false,
    totalUnits: 1,
    fulfillmentTypeSummary: 'Supplier direct ship',
    fulfillmentType: 'Supplier',
    communications: [
      { dateTime: '2026-06-21 09:05 CT', channel: 'Chat', agent: 'Nina Brooks', direction: 'Inbound', summary: 'Customer requested tracking details for the launch order.', caseId: 'CASE-90463' },
      { dateTime: '2026-06-21 09:12 CT', channel: 'Chat', agent: 'Nina Brooks', direction: 'Outbound', summary: 'Shared carrier tracking and estimated delivery date.', caseId: 'CASE-90463' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900188',
        releaseLineId: '1',
        orderLineId: '1.1',
        lineNumber: '1.1',
        sku: 'HF2903-100',
        productName: 'Jordan Retro 4 White Thunder',
        orderedQty: 1,
        lineTotal: 219.99,
        cancelledTotal: 0,
        currentStatus: 'Fulfilled',
        itemId: 'HF2903-100',
        releaseStatus: 'Fulfilled',
        releaseDate: '2026-06-20',
        fulfillmentMethod: 'Supplier Direct',
        quantity: 1,
        fulfilledQty: 1,
        cancelledQty: 0,
        assignedNode: 'SUP-NIKE-08',
        assignedNodeType: 'Supplier',
        updatedDate: '2026-06-21 08:41 CT'
      }
    ],
    nodes: [
      {
        type: 'Supplier Fulfillment',
        id: 'SUP-NIKE-08',
        name: 'Nike Memphis Direct Ship',
        supplierId: 'NIKE-US',
        asnNumber: 'ASN-661982',
        shipmentStatus: 'In Transit'
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610188',
        type: 'Supplier',
        nodeId: 'SUP-NIKE-08',
        nodeName: 'Nike Memphis Direct Ship',
        status: 'In Transit',
        releaseNumber: 'REL-900188',
        releaseLineId: '1',
        packageId: 'PKG-770188',
        packageDetailId: 'PKGD-770188-01',
        shipmentId: 'SHP-550188',
        quantity: 1,
        shipVia: 'FedEx 2Day',
        trackingNumber: '612999084731'
      }
    ]
  },
  {
    orderNumber: 'FL-10048355',
    customerId: 'C-991703',
    customerName: 'Ari Williams',
    customerEmail: 'ari.williams@example.com',
    orderDate: '2026-06-21',
    orderType: 'Web',
    enterprise: 'Foot Locker North America',
    organization: 'KFL-US',
    paymentStatus: 'Authorized',
    totalAmount: 129.98,
    status: 'Back Ordered',
    onHold: true,
    holdReason: 'Inventory allocation review',
    totalUnits: 2,
    fulfillmentTypeSummary: 'DC allocation exception',
    fulfillmentType: 'DC',
    communications: [
      { dateTime: '2026-06-22 08:46 CT', channel: 'Email', agent: 'Marcus Lee', direction: 'Outbound', summary: 'Advised customer of the inventory allocation delay.', caseId: 'CASE-90511' },
      { dateTime: '2026-06-22 13:20 CT', channel: 'Internal Note', agent: 'Inventory Helpdesk', direction: 'Internal', summary: 'Escalated allocation review to Camp Hill warehouse.', caseId: 'CASE-90511' }
    ],
    releases: [
      {
        releaseNumber: 'REL-900211',
        releaseLineId: '1',
        orderLineId: '1.1',
        lineNumber: '1.1',
        sku: 'BB550VTA',
        productName: 'New Balance 550 Varsity Team',
        orderedQty: 2,
        lineTotal: 129.98,
        cancelledTotal: 0,
        currentStatus: 'Back Ordered',
        itemId: 'BB550VTA',
        releaseStatus: 'Back Ordered',
        releaseDate: '2026-06-21',
        fulfillmentMethod: 'DC Ship',
        quantity: 2,
        fulfilledQty: 0,
        cancelledQty: 0,
        assignedNode: 'PHX-DC-02',
        assignedNodeType: 'DC',
        updatedDate: '2026-06-21 19:16 CT'
      }
    ],
    nodes: [
      {
        type: 'Distribution Center',
        id: 'PHX-DC-02',
        name: 'Phoenix Distribution Center',
        inventoryAvailable: 0,
        allocatedQty: 0
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-610211',
        type: 'Warehouse',
        nodeId: 'CPH-WH-03',
        nodeName: 'Camp Hill Warehouse',
        status: 'Awaiting Inventory',
        releaseNumber: 'REL-900211',
        releaseLineId: '1',
        packageId: 'PKG-770211',
        packageDetailId: 'PKGD-770211-01',
        shipmentId: 'SHP-550211',
        quantity: 2,
        shipVia: 'UPS Ground',
        trackingNumber: 'Pending'
      }
    ]
  },
  {
    orderNumber: 'FL-10048110',
    customerId: 'C-330182',
    customerName: 'Sofia Martinez',
    customerEmail: 'sofia.martinez@example.com',
    orderDate: '2026-06-18',
    orderType: 'SaveTheSale',
    enterprise: 'Foot Locker Canada',
    organization: 'FL-CA',
    paymentStatus: 'Refunded',
    returnOrderId: 'RET-300194',
    totalAmount: 189.99,
    status: 'Cancelled',
    onHold: false,
    totalUnits: 1,
    fulfillmentTypeSummary: 'Store fulfillment cancelled',
    fulfillmentType: 'Store',
    communications: [
      { dateTime: '2026-06-18 16:40 CT', channel: 'Phone', agent: 'Tanya Brooks', direction: 'Inbound', summary: 'Customer requested cancellation before store dispatch.', caseId: 'CASE-89971' },
      { dateTime: '2026-06-18 17:05 CT', channel: 'Email', agent: 'Tanya Brooks', direction: 'Outbound', summary: 'Cancellation and refund confirmation sent to customer.', caseId: 'CASE-89971' },
      { dateTime: '2026-06-19 07:35 CT', channel: 'Internal Note', agent: 'Returns Helpdesk', direction: 'Internal', summary: 'Return order RET-300194 linked to the original transaction.', caseId: 'CASE-89971' }
    ],
    releases: [
      {
        releaseNumber: 'REL-899981',
        releaseLineId: '1',
        orderLineId: '1.1',
        lineNumber: '1.1',
        sku: 'U9060ECA',
        productName: 'New Balance 9060 Sea Salt',
        orderedQty: 1,
        lineTotal: 189.99,
        cancelledTotal: 189.99,
        currentStatus: 'Cancelled',
        itemId: 'U9060ECA',
        releaseStatus: 'Cancelled',
        releaseDate: '2026-06-18',
        fulfillmentMethod: 'Store Ship',
        quantity: 1,
        fulfilledQty: 0,
        cancelledQty: 1,
        assignedNode: 'ST-4501',
        assignedNodeType: 'Store',
        updatedDate: '2026-06-18 17:52 CT'
      }
    ],
    nodes: [
      {
        type: 'Store Fulfillment',
        id: 'ST-4501',
        name: 'Foot Locker Eaton Centre',
        location: 'Toronto, ON',
        pickStatus: 'Cancelled at Source'
      }
    ],
    fulfillments: [
      {
        fulfillmentId: 'FUL-609981',
        type: 'Store',
        nodeId: 'ST-4501',
        nodeName: 'Foot Locker Eaton Centre',
        status: 'Cancelled',
        releaseNumber: 'REL-899981',
        releaseLineId: '1',
        packageId: 'PKG-769981',
        packageDetailId: 'PKGD-769981-01',
        shipmentId: 'SHP-549981',
        quantity: 1,
        shipVia: 'Store Ship',
        trackingNumber: 'Not Shipped'
      }
    ]
  }
];

const blankAddress: OrderAddress = {
  line1: '',
  line2: '',
  city: '',
  state: '',
  postalCode: '',
  country: ''
};

function normalizeAddress(address?: OrderAddress): OrderAddress {
  return {
    line1: address?.line1 ?? '',
    line2: address?.line2 ?? '',
    city: address?.city ?? '',
    state: address?.state ?? '',
    postalCode: address?.postalCode ?? '',
    country: address?.country ?? ''
  };
}

function withNumericReleaseLineIds(order: Order): Order {
  const releaseLineMap = new Map<string, string>();
  const releaseByOriginalLineId = new Map(order.releases.map((release) => [release.releaseLineId, release]));
  const releases = order.releases.map((release, index) => {
    const releaseLineId = String(index + 1);
    releaseLineMap.set(release.releaseLineId, releaseLineId);
    return {
      releaseNumber: release.releaseNumber ?? '',
      releaseLineId,
      orderLineId: release.orderLineId ?? '',
      lineNumber: release.lineNumber ?? '',
      sku: release.sku ?? '',
      productName: release.productName ?? '',
      orderedQty: release.orderedQty ?? 0,
      lineTotal: release.lineTotal ?? 0,
      cancelledTotal: release.cancelledTotal ?? 0,
      currentStatus: release.currentStatus ?? 'Open',
      itemId: release.itemId ?? '',
      releaseStatus: release.releaseStatus ?? '',
      releaseDate: release.releaseDate ?? '',
      fulfillmentMethod: release.fulfillmentMethod ?? '',
      quantity: release.quantity ?? 0,
      fulfilledQty: release.fulfilledQty ?? 0,
      cancelledQty: release.cancelledQty ?? 0,
      assignedNode: release.assignedNode ?? '',
      assignedNodeType: release.assignedNodeType ?? '',
      updatedDate: release.updatedDate ?? ''
    };
  });

  const nodes = order.nodes.map((node) => ({
    type: node.type ?? '',
    id: node.id ?? '',
    name: node.name ?? '',
    location: node.location ?? '',
    inventoryAvailable: node.inventoryAvailable ?? 0,
    allocatedQty: node.allocatedQty ?? 0,
    pickStatus: node.pickStatus ?? '',
    supplierId: node.supplierId ?? '',
    asnNumber: node.asnNumber ?? '',
    shipmentStatus: node.shipmentStatus ?? ''
  }));

  const fulfillments = order.fulfillments.map((fulfillment, index) => {
    const sourceRelease = releaseByOriginalLineId.get(fulfillment.releaseLineId);
    return {
      fulfillmentId: fulfillment.fulfillmentId ?? '',
      type: fulfillment.type ?? '',
      nodeId: fulfillment.nodeId ?? '',
      nodeName: fulfillment.nodeName ?? '',
      status: fulfillment.status ?? '',
      releaseNumber: fulfillment.releaseNumber ?? '',
      releaseLineId: releaseLineMap.get(fulfillment.releaseLineId) ?? fulfillment.releaseLineId,
      packageId: fulfillment.packageId ?? '',
      packageDetailId: String(index + 1),
      shipmentId: fulfillment.shipmentId ?? '',
      quantity: fulfillment.quantity ?? 0,
      shipVia: fulfillment.shipVia ?? '',
      trackingNumber: fulfillment.trackingNumber ?? '',
      createdDate: fulfillment.createdDate ?? sourceRelease?.releaseDate ?? order.orderDate,
      updatedDate: fulfillment.updatedDate ?? sourceRelease?.updatedDate ?? sourceRelease?.releaseDate ?? order.orderDate
    };
  });

  return {
    ...order,
    shippingAddress: normalizeAddress(order.shippingAddress ?? blankAddress),
    billingAddress: normalizeAddress(order.billingAddress ?? blankAddress),
    returnOrderId: order.returnOrderId ?? '',
    holdReason: order.holdReason ?? '',
    releases,
    nodes,
    fulfillments
  };
}

const generatedSkus = [
  ['FV5029-141', 'Nike Air Max Dn White Metallic Silver'],
  ['ID3715', 'adidas Samba OG Cloud White'],
  ['BB550VTA', 'New Balance 550 Varsity Athletic'],
  ['HF2903-100', 'Nike Dunk Low Retro White Black'],
  ['VN000D3HY28', 'Vans Knu Skool Black White'],
  ['U9060ECA', 'New Balance 9060 Concrete Grey']
];

const generatedNodes = [
  { nodeId: 'MILTON-WH-01', nodeName: 'Milton Warehouse', assignedNodeType: 'DC', fulfillmentType: 'Warehouse' },
  { nodeId: 'JC-WH-01', nodeName: 'JC Warehouse', assignedNodeType: 'DC', fulfillmentType: 'Warehouse' },
  { nodeId: 'RENO-WH-01', nodeName: 'Reno Warehouse', assignedNodeType: 'DC', fulfillmentType: 'Warehouse' },
  { nodeId: 'CAMPHILL-WH-01', nodeName: 'Camp Hill Warehouse', assignedNodeType: 'DC', fulfillmentType: 'Warehouse' },
  { nodeId: 'ST-1842', nodeName: 'Foot Locker Lenox Square', assignedNodeType: 'Store', fulfillmentType: 'Store' },
  { nodeId: 'DS-NIKE-08', nodeName: 'Nike Dropship', assignedNodeType: 'Supplier', fulfillmentType: 'Dropship' }
];

function createGeneratedRelease(orderSeed: number, index: number, prefix: string): Release {
  const [sku, productName] = generatedSkus[index % generatedSkus.length];
  const node = generatedNodes[index % generatedNodes.length];
  const statusOptions: OrderStatus[] = ['Open', 'Allocated', 'Released', 'In Process', 'Picked', 'Packed', 'Fulfilled', 'Carrier Scanned'];
  const currentStatus = statusOptions[index % statusOptions.length];
  const quantity = (index % 3) + 1;
  const fulfilledQty = currentStatus === 'Fulfilled' || currentStatus === 'Carrier Scanned' ? quantity : currentStatus === 'Packed' ? Math.max(0, quantity - 1) : 0;
  const cancelledQty = index % 37 === 0 ? 1 : 0;
  const lineNumber = String(index + 1);
  return {
    releaseNumber: `${prefix}-REL-${String(orderSeed).padStart(4, '0')}-${String(index + 1).padStart(5, '0')}`,
    releaseLineId: String(index + 1),
    orderLineId: lineNumber,
    lineNumber,
    sku,
    productName,
    orderedQty: quantity,
    lineTotal: Number((quantity * (79.99 + (index % 6) * 15)).toFixed(2)),
    cancelledTotal: cancelledQty ? Number((cancelledQty * 79.99).toFixed(2)) : 0,
    currentStatus,
    itemId: sku,
    releaseStatus: currentStatus,
    releaseDate: `2026-06-${String(10 + (index % 18)).padStart(2, '0')}`,
    fulfillmentMethod: node.fulfillmentType === 'Store' ? 'Store Pickup' : node.fulfillmentType === 'Dropship' ? 'Dropship' : 'DC Ship',
    quantity,
    fulfilledQty,
    cancelledQty,
    assignedNode: node.nodeId,
    assignedNodeType: node.assignedNodeType,
    updatedDate: `2026-06-${String(10 + (index % 18)).padStart(2, '0')} ${String(8 + (index % 12)).padStart(2, '0')}:${String((index * 7) % 60).padStart(2, '0')} CT`
  };
}

function createGeneratedFulfillment(release: Release, orderSeed: number, index: number, prefix: string): Fulfillment {
  const node = generatedNodes.find((candidate) => candidate.nodeId === release.assignedNode) ?? generatedNodes[0];
  const fulfillmentStatuses = ['Manifested', 'In Transit', 'Ready for Pickup', 'Awaiting Pick', 'Label Created', 'Packed', 'Shipped'];
  return {
    fulfillmentId: `${prefix}-FUL-${String(orderSeed).padStart(4, '0')}-${String(index + 1).padStart(5, '0')}`,
    type: node.fulfillmentType,
    nodeId: node.nodeId,
    nodeName: node.nodeName,
    status: fulfillmentStatuses[index % fulfillmentStatuses.length],
    releaseNumber: release.releaseNumber,
    releaseLineId: release.releaseLineId,
    packageId: `${prefix}-PKG-${String(orderSeed).padStart(4, '0')}-${String(index + 1).padStart(5, '0')}`,
    packageDetailId: String(index + 1),
    shipmentId: `${prefix}-SHP-${String(orderSeed).padStart(4, '0')}-${String(index + 1).padStart(5, '0')}`,
    quantity: release.quantity,
    shipVia: node.fulfillmentType === 'Store' ? 'Store Pickup' : node.fulfillmentType === 'Dropship' ? 'FedEx Ground' : 'UPS Ground',
    trackingNumber: index % 9 === 0 ? 'Pending' : `1ZFL${String(orderSeed).padStart(4, '0')}${String(index + 1).padStart(6, '0')}`,
    createdDate: `${release.releaseDate} 09:${String(index % 60).padStart(2, '0')} CT`,
    updatedDate: release.updatedDate
  };
}

function createGeneratedOrder({
  orderNumber,
  orderSeed,
  lineCount,
  customer,
  orderType
}: {
  orderNumber: string;
  orderSeed: number;
  lineCount: number;
  customer: boolean;
  orderType: string;
}): Order {
  const releases = Array.from({ length: lineCount }, (_, index) => createGeneratedRelease(orderSeed, index, customer ? 'CUST' : 'BULK'));
  const fulfillments = releases.map((release, index) => createGeneratedFulfillment(release, orderSeed, index, customer ? 'CUST' : 'BULK'));
  const totalAmount = releases.reduce((total, release) => total + release.lineTotal - release.cancelledTotal, 0);
  const totalUnits = releases.reduce((total, release) => total + release.orderedQty, 0);
  return {
    orderNumber,
    customerId: customer ? `C-STRESS-${orderSeed}` : `BULK-CUST-${orderSeed}`,
    customerName: customer ? `Customer Stress Demo ${orderSeed}` : `Enterprise Bulk Account ${orderSeed}`,
    customerEmail: customer ? `stress.customer.${orderSeed}@example.com` : `bulk.ops.${orderSeed}@footlocker.example`,
    orderDate: `2026-06-${String(10 + (orderSeed % 18)).padStart(2, '0')}`,
    orderType,
    enterprise: customer ? 'Foot Locker North America' : 'Foot Locker Enterprise Operations',
    organization: ['FL-US', 'CH-US', 'KFL-US', 'FL-CA', 'CH-CA'][orderSeed % 5],
    paymentStatus: customer ? (orderSeed % 3 === 0 ? 'Captured' : 'Authorized') : 'Approved',
    totalAmount: Number(totalAmount.toFixed(2)),
    status: customer ? 'Released' : (orderSeed % 4 === 0 ? 'Allocated' : 'Released'),
    onHold: !customer && orderSeed % 9 === 0,
    holdReason: !customer && orderSeed % 9 === 0 ? 'Bulk allocation review pending' : '',
    totalUnits,
    fulfillmentTypeSummary: customer ? `${lineCount} customer release lines` : `${lineCount} bulk release lines across DC, store, and dropship nodes`,
    fulfillmentType: 'WIP',
    communications: [
      {
        dateTime: `2026-06-${String(10 + (orderSeed % 18)).padStart(2, '0')} 10:15 CT`,
        channel: customer ? 'Email' : 'Internal Note',
        agent: customer ? 'Customer Care' : 'Enterprise Ops',
        direction: customer ? 'Outbound' : 'Internal',
        summary: customer ? 'Stress order generated for customer-order performance validation.' : 'Bulk order generated for non-customer high-volume validation.',
        caseId: `${customer ? 'CASE' : 'BULK'}-${String(orderSeed).padStart(5, '0')}`
      }
    ],
    releases,
    nodes: generatedNodes.map((node) => ({
      type: node.assignedNodeType,
      id: node.nodeId,
      name: node.nodeName,
      location: node.nodeName,
      inventoryAvailable: 5000 + orderSeed,
      allocatedQty: Math.min(lineCount, 250)
    })),
    fulfillments
  };
}

const generatedCustomerStressOrders = [
  createGeneratedOrder({ orderNumber: 'FL-STRESS-100LINES', orderSeed: 7100, lineCount: 100, customer: true, orderType: 'Web' })
];

const generatedNonCustomerOrders = Array.from({ length: 50 }, (_, index) => createGeneratedOrder({
  orderNumber: index === 0 ? 'NC-STRESS-2500LINES' : `NC-BULK-${String(index).padStart(4, '0')}`,
  orderSeed: 8200 + index,
  lineCount: index === 0 ? 2500 : 12 + (index % 9),
  customer: false,
  orderType: index % 3 === 0 ? 'EnterpriseBulk' : index % 3 === 1 ? 'StoreTransfer' : 'Replenishment'
}));

export const orders: Order[] = [
  ...featuredOrders,
  ...generatedCustomerStressOrders,
  ...generatedNonCustomerOrders
].map(withNumericReleaseLineIds);

export const dashboardKpis = [
  { label: 'Total Orders', value: '38,492', delta: '+11.8% vs LW', tone: '#d71920' },
  { label: 'Open Orders', value: '8,216', delta: '+4.2% vs LW', tone: '#1769e0' },
  { label: 'Released Orders', value: '12,874', delta: '+7.5% vs LW', tone: '#e77718' },
  { label: 'Fulfilled Orders', value: '16,204', delta: '+13.1% vs LW', tone: '#168a51' },
  { label: 'Cancelled Orders', value: '1,198', delta: '-2.7% vs LW', tone: '#c62828' },
  { label: 'Inventory Availability', value: '94.6%', delta: '+1.9 pts', tone: '#117c8b' },
  { label: 'Gross Demand', value: '$8.42M', delta: '+9.6% vs LW', tone: '#7c3aed' },
  { label: 'Net Sales', value: '$7.96M', delta: '+10.2% vs LW', tone: '#0f766e' },
  { label: 'Fill Rate', value: '96.8%', delta: '+1.4 pts', tone: '#168a51' },
  { label: 'On-Time Ship', value: '94.2%', delta: '+2.1 pts', tone: '#1769e0' },
  { label: 'Perfect Order Rate', value: '91.7%', delta: '+1.2 pts', tone: '#b45309' },
  { label: 'Average Cycle Time', value: '6.4h', delta: '-0.8h vs LW', tone: '#475569' }
];

export const ordersByStatus = [
  { name: 'Open', value: 4280 },
  { name: 'Back Ordered', value: 1946 },
  { name: 'Allocated', value: 6310 },
  { name: 'Released', value: 12874 },
  { name: 'Fulfilled', value: 9105 },
  { name: 'Delivered', value: 7099 },
  { name: 'Cancelled', value: 1198 }
];

export const fulfillmentMix = [
  { name: 'DC', orders: 15420 },
  { name: 'Store', orders: 11480 },
  { name: 'Supplier', orders: 11592 }
];

export const inventoryTrend = [
  { day: 'Mon', available: 93, reserved: 28 },
  { day: 'Tue', available: 95, reserved: 31 },
  { day: 'Wed', available: 94, reserved: 34 },
  { day: 'Thu', available: 96, reserved: 30 },
  { day: 'Fri', available: 94, reserved: 36 },
  { day: 'Sat', available: 92, reserved: 41 },
  { day: 'Sun', available: 95, reserved: 35 }
];

export const dailyOrderVolume = [
  { day: 'Jun 15', orders: 4210, grossDemand: 0.91, netSales: 0.85 },
  { day: 'Jun 16', orders: 4388, grossDemand: 0.97, netSales: 0.91 },
  { day: 'Jun 17', orders: 4621, grossDemand: 1.03, netSales: 0.98 },
  { day: 'Jun 18', orders: 4910, grossDemand: 1.12, netSales: 1.06 },
  { day: 'Jun 19', orders: 5238, grossDemand: 1.24, netSales: 1.18 },
  { day: 'Jun 20', orders: 5875, grossDemand: 1.68, netSales: 1.58 },
  { day: 'Jun 21', orders: 5512, grossDemand: 1.47, netSales: 1.40 }
];

export const serviceLevelTrend = [
  { day: 'Jun 15', fillRate: 94.8, onTimeShip: 91.2, perfectOrder: 88.7 },
  { day: 'Jun 16', fillRate: 95.1, onTimeShip: 91.9, perfectOrder: 89.2 },
  { day: 'Jun 17', fillRate: 95.6, onTimeShip: 92.5, perfectOrder: 89.9 },
  { day: 'Jun 18', fillRate: 96.0, onTimeShip: 92.8, perfectOrder: 90.1 },
  { day: 'Jun 19', fillRate: 96.3, onTimeShip: 93.4, perfectOrder: 90.8 },
  { day: 'Jun 20', fillRate: 96.5, onTimeShip: 93.8, perfectOrder: 91.2 },
  { day: 'Jun 21', fillRate: 96.8, onTimeShip: 94.2, perfectOrder: 91.7 }
];

export const exceptionTrend = [
  { day: 'Jun 15', inventory: 312, payment: 118, carrier: 76 },
  { day: 'Jun 16', inventory: 296, payment: 104, carrier: 82 },
  { day: 'Jun 17', inventory: 341, payment: 96, carrier: 71 },
  { day: 'Jun 18', inventory: 278, payment: 91, carrier: 68 },
  { day: 'Jun 19', inventory: 254, payment: 87, carrier: 61 },
  { day: 'Jun 20', inventory: 231, payment: 79, carrier: 56 },
  { day: 'Jun 21', inventory: 218, payment: 73, carrier: 49 }
];

export const bannerPerformance = [
  { name: 'FL-US', orders: 19420, revenue: 4.21, fillRate: 97.4 },
  { name: 'CH-US', orders: 8930, revenue: 1.94, fillRate: 96.8 },
  { name: 'KFL-US', orders: 6142, revenue: 1.18, fillRate: 95.9 },
  { name: 'FL-CA', orders: 2860, revenue: 0.45, fillRate: 94.7 },
  { name: 'CH-CA', orders: 1140, revenue: 0.18, fillRate: 94.1 }
];

export const nodePerformance = [
  { name: 'JC Warehouse', onTime: 97.2, fillRate: 98.1, backlog: 412 },
  { name: 'Reno Warehouse', onTime: 95.8, fillRate: 97.4, backlog: 528 },
  { name: 'Camp Hill', onTime: 93.9, fillRate: 96.2, backlog: 684 },
  { name: 'Store Network', onTime: 92.7, fillRate: 95.6, backlog: 936 },
  { name: 'Supplier Direct', onTime: 90.8, fillRate: 94.9, backlog: 377 }
];

export const returnTrend = [
  { week: 'W20', returnRate: 8.4, refundCycle: 3.8 },
  { week: 'W21', returnRate: 8.1, refundCycle: 3.6 },
  { week: 'W22', returnRate: 7.9, refundCycle: 3.5 },
  { week: 'W23', returnRate: 8.3, refundCycle: 3.3 },
  { week: 'W24', returnRate: 7.7, refundCycle: 3.1 },
  { week: 'W25', returnRate: 7.4, refundCycle: 2.9 }
];

export const activities = [
  'REL-900188 shipped from Nike Memphis Direct Ship',
  'FL-10048355 moved to backorder after PHX-DC-02 shortage',
  'Inventory sync completed for 1,284 Foot Locker stores',
  'ST-1842 accepted pickup release REL-900143',
  'Payment authorization refreshed for high-value launch orders'
];

export const alerts = [
  { severity: 'High', text: 'BB550VTA has zero available units at PHX-DC-02' },
  { severity: 'Medium', text: '18 store pickup releases are beyond SLA in Midwest region' },
  { severity: 'Low', text: 'Supplier ASN feed latency detected for vendor ADI-US' }
];

export const inventoryRows = [
  { sku: 'FV5029-141', productName: 'Nike Air Max Dn White Metallic Silver', category: 'Running', available: 1840, reserved: 226, safety: 200, nodes: 'ATL-DC-01, ST-1842' },
  { sku: 'ID3715', productName: 'adidas Samba OG Cloud White', category: 'Lifestyle', available: 913, reserved: 148, safety: 160, nodes: 'DFW-DC-03, ST-1093' },
  { sku: 'HF2903-100', productName: 'Jordan Retro 4 White Thunder', category: 'Launch', available: 302, reserved: 277, safety: 250, nodes: 'SUP-NIKE-08' },
  { sku: 'BB550VTA', productName: 'New Balance 550 Varsity Team', category: 'Lifestyle', available: 0, reserved: 82, safety: 120, nodes: 'PHX-DC-02' },
  { sku: 'U9060ECA', productName: 'New Balance 9060 Sea Salt', category: 'Lifestyle', available: 620, reserved: 97, safety: 140, nodes: 'ST-4501, EWR-DC-04' }
];

export const productCatalog = inventoryRows.map((item, index) => ({
  ...item,
  price: [170, 100, 220, 115, 190][index],
  vendor: ['Nike', 'adidas', 'Jordan', 'New Balance', 'New Balance'][index],
  image: `https://images.unsplash.com/photo-${['1542291026-7eec264c27ff', '1608231387042-66d1773070a5', '1595950653106-6c9ebd614d3a', '1491553895911-0055eca6402d', '1525966222134-fcfa99b8ae77'][index]}?auto=format&fit=crop&w=900&q=80`
}));

export const users = [
  { userId: 'estone', firstName: 'Erica', lastName: 'Stone', name: 'Erica Stone', role: 'OMS Administrator', permissions: 'Full Access', status: 'Active' },
  { userId: 'rpatel', firstName: 'Ravi', lastName: 'Patel', name: 'Ravi Patel', role: 'OMS Ops L2', permissions: 'Role managed', status: 'Active' },
  { userId: 'tbrooks', firstName: 'Tanya', lastName: 'Brooks', name: 'Tanya Brooks', role: 'OMS Ops L1', permissions: 'Role managed', status: 'Active' },
  { userId: 'mlee', firstName: 'Marcus', lastName: 'Lee', name: 'Marcus Lee', role: 'Business Read', permissions: 'Role managed', status: 'Disabled' }
];
