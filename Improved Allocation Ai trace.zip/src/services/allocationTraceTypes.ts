export type AllocationTraceRequest = {
  fromDate: string;
  toDate: string;
  timezone: string;
};

export type AllocationTraceSummaryRow = {
  node: string;
  allocationOrders: number;
  allocationQty: number;
  maoOrders: number;
  maoQty: number;
  maoCancelledOrders: number;
  maoCancelledQty: number;
  whseOrders: number;
  whseQty: number;
};

export type AllocationTraceMismatchRow = {
  soOrder: string;
  store: string;
  fulfillmentWhse: string;
  allocationStatus: string;
  allocationQty: number;
  maoStatus: string;
  maoQty: number;
  whseStatus: string;
  whseQty: number;
  variance: number;
  mismatch: string;
  lastEvent: string;
};

export type AllocationTraceResponse = {
  range: {
    fromDate: string;
    toDate: string;
    timezone: string;
  };
  summary: AllocationTraceSummaryRow[];
  mismatches: AllocationTraceMismatchRow[];
  generatedAt: string;
};
