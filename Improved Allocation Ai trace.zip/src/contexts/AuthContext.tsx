import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { authConfig } from '../config/authConfig';
import { authTokenStore } from '../services/authTokenStore';

type AuthUser = {
  name: string;
  email: string;
  role: string;
  initials: string;
};

type AuthContextValue = {
  isAuthenticated: boolean;
  authEnabled: boolean;
  user: AuthUser | null;
  signIn: () => void;
  signOut: () => void;
  setDevAccessToken: (token: string) => void;
};

const devUser: AuthUser = {
  name: 'Erica Stone',
  email: 'erica.stone@footlocker.com',
  role: 'OMS Admin',
  initials: 'FL'
};

const tokenStorageKey = 'cr_global_app_ops_access_token';
const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(authConfig.enabled ? null : devUser);

  useEffect(() => {
    authTokenStore.setTokenProvider(() => window.localStorage.getItem(tokenStorageKey));
    return () => authTokenStore.clear();
  }, []);

  const value = useMemo<AuthContextValue>(() => ({
    isAuthenticated: Boolean(user),
    authEnabled: authConfig.enabled,
    user,
    signIn: () => {
      if (!authConfig.enabled) {
        setUser(devUser);
        return;
      }

      const returnUrl = encodeURIComponent(window.location.href);
      window.location.assign(`/auth/login?returnUrl=${returnUrl}`);
    },
    signOut: () => {
      window.localStorage.removeItem(tokenStorageKey);
      if (!authConfig.enabled) {
        setUser(devUser);
        return;
      }

      setUser(null);
      const logoutUrl = `${authConfig.authority}/oauth2/v2.0/logout?post_logout_redirect_uri=${encodeURIComponent(authConfig.postLogoutRedirectUri)}`;
      window.location.assign(logoutUrl);
    },
    setDevAccessToken: (token: string) => {
      window.localStorage.setItem(tokenStorageKey, token);
      setUser(devUser);
    }
  }), [user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
