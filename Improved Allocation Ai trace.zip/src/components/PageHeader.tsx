import { Box, Chip, Stack, Typography } from '@mui/material';

type PageHeaderProps = {
  title: string;
  subtitle: string;
  badge?: string;
};

export default function PageHeader({ title, subtitle, badge }: PageHeaderProps) {
  return (
    <Box sx={{ mb: { xs: 1.7, md: 2.3 } }}>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={{ xs: 1, md: 1.5 }} sx={{ minWidth: 0 }}>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="h4" sx={{ fontSize: 'clamp(1.35rem, 1.08rem + .86vw, 1.9rem)', lineHeight: 1.12, overflowWrap: 'anywhere' }}>
            {title}
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mt: 0.55, maxWidth: 780, fontSize: 'clamp(.76rem, .7rem + .18vw, .9rem)' }}>
            {subtitle}
          </Typography>
        </Box>
        {badge && <Chip label={badge} color="primary" variant="outlined" sx={{ alignSelf: 'flex-start', maxWidth: '100%' }} />}
      </Stack>
    </Box>
  );
}
