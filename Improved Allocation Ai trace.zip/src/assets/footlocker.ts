export const footLockerLogo = 'https://images.seeklogo.com/logo-png/5/1/foot-locker-logo-png_seeklogo-56477.png';
export const footLockerMark = footLockerLogo;
