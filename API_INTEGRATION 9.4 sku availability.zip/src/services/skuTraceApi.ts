import { apiClient, apiConfiguration } from './apiClient';

export const skuTraceTabKeys = [
  'banners',
  'selling-channel',
  'sku-availability',
  'product-attributes',
  'upc',
  'xref',
  'exclusions',
  'dirty-node'
] as const;

export type SkuTraceTabKey = (typeof skuTraceTabKeys)[number];
export type SkuTraceSearchRequest = {
  launchDate?: string;
  skus?: string[];
};
export type SkuTraceSearchResult = {
  sku: string;
  skuStatus: 'A' | 'D' | 'I' | '';
  launchDate: string;
  launchReservationDate: string;
  launchType: 'Atomic' | 'Hot' | 'Flow' | 'Cool';
  launchedBanners: string;
  banners: string;
  image: 'Yes' | 'No';
  copy: 'Yes' | 'No';
  productType: 'Yes' | 'No';
  sportsAttribute: 'Yes' | 'No';
  frenchName: 'Yes' | 'No' | 'N/A';
  frenchCopy: 'Yes' | 'No' | 'N/A';
  description: string;
  availableInIex: 'Yes' | 'No';
  avavailableInIexStore: 'Yes' | 'No';
  avavailbleInIexWhse: 'Yes' | 'No';
  avavailableInIexDropship: 'Yes' | 'No';
};
export type SkuTraceSearchResponse = {
  results: SkuTraceSearchResult[];
  total: number;
  searchedAt: string;
  criteria: SkuTraceSearchRequest;
};
export type OnlineAvailabilityCheck = { sku: string; banners: string[] };
export type OnlineAvailabilityResult = { sku: string; banner: string; online: boolean };
export type OnlineAvailabilityResponse = { results: OnlineAvailabilityResult[]; checkedAt: string };
export type TraceDetailItem = { label: string; value: string };
export type BannerTrace = {
  banner: string;
  iex: boolean;
  iexStaging: boolean;
  internetChannel: boolean;
  online: boolean;
};
export type SellingChannelTrace = {
  sellingChannel: string;
  skuLevelEnabled?: boolean;
  maoBanners: string[];
  sesBanners: string[];
  commonProductBanners: string[];
};
export const availabilityViews = ['FL-US-ShiptoHome', 'CH-US-ShiptoHome', 'KFL-US-ShiptoHome'] as const;
export type AvailabilityView = (typeof availabilityViews)[number];
export type AvailabilityGroupStatus = 'matched' | 'near-match' | 'discrepancy';
export type AvailabilityDcMetrics = { whseCurrent: number; mao: number; maoStaging: number; iexInventoryStaging: number };
export type AvailabilityDropshipMetrics = { dsco: number; mao: number; flStaging: number; iexInventory: number };
export type AvailabilityStoreMetrics = { mao: number; flStaging: number; iexInventory: number };
export type AvailabilityOverallMetrics = { mao: number; flStaging: number; iexInventory: number };
export type SkuAvailabilityRow = {
  size: string;
  globalSizeId: string;
  iexPxd: 'Available' | 'Unavailable';
  dc: AvailabilityDcMetrics;
  dropship: AvailabilityDropshipMetrics;
  store: AvailabilityStoreMetrics;
  overall: AvailabilityOverallMetrics;
};
export type SkuAvailabilityTrace = {
  views: AvailabilityView[];
  selectedView: AvailabilityView;
  rows: SkuAvailabilityRow[];
};
export type AvailabilityOnlineCheckRequest = { sku: string; view: AvailabilityView; globalSizeIds: string[] };
export type AvailabilityOnlineResult = { globalSizeId: string; online: boolean };
export type AvailabilityOnlineResponse = { results: AvailabilityOnlineResult[]; checkedAt: string };
export type SkuExclusionTrace = {
  banner: string;
  styleId: string;
  colorId: string;
  type: 'BOSS' | 'BOPIS' | 'CBF' | 'CBP';
  status: 'active' | 'cancelled' | 'failed' | 'scheduled';
  maoStatus?: 'active' | 'inactive' | 'cancelled' | 'failed' | 'scheduled';
  startDate: string;
  endDate: string;
};
export type XrefTrace = {
  cpid: string;
  skuNumber: string;
  vendorStyle: string;
  sizeDesc: string;
  sizeId: string;
  globalColorId: string;
  globalStyleId: string;
  globalSizeId: string;
  sizeCode: string;
  styleDesc: string;
  division: string;
  department: string;
  countryCode: string;
};
export const productAttributeColumnKeys = [
  'LEGACY_SKU',
  'LEGACY_SIZE_DESC',
  'GLOBAL_SIZE_ID',
  'SOLD_ONLINE',
  'SOLD_IN_STORES',
  'ISNONMERCHANDISE',
  'ISCASELOT',
  'VENDORSTYLE',
  'FLBOSSBLOCK',
  'ISDIGITALELIGIBLEFLUS',
  'ISDIGITALELIGIBLECHUS',
  'ISDIGITALELIGIBLEKFLUS',
  'ISDIGITALELIGIBLEFLCA',
  'ISDIGITALELIGIBLECHCA',
  'FLUSCFINCLUSION',
  'FLUSCFINCLUDEINV',
  'CHUSCFINCLUDEINV',
  'KFLUSCFINCLUDEINV',
  'FLCACFINCLUDEINV',
  'CHCACFINCLUDEINV',
  'FLUSCFEXCLUDECHINV',
  'FLUSCFEXCLUDEKFLINV',
  'FLUSCFEXCLUSIONCH',
  'CHUSCFEXCLUDEFLINV',
  'CHUSCFEXCLUDEKFLINV',
  'KFLUSCFEXCLUDEFLINV',
  'KFLUSCFEXCLUDECHINV',
  'FLCACFEXCLUDECHINV',
  'CHCACFEXCLUDEFLINV',
  'CHCACFEXCLUDEKFLINV',
  'FLUSINCLUDESTOREINVSHIP',
  'CHUSINCLUDESTOREINVSHIP',
  'KFLUSINCLUDESTOREINVSHIP',
  'FLCAINCLUDESTOREINVSHIP',
  'CHCAINCLUDESTOREINVSHIP',
  'FLUSINCLUDESTOREINVPICK',
  'CHUSINCLUDESTOREINVPICK',
  'KFLUSINCLUDESTOREINVPICK',
  'FLCAINCLUDESTOREINVPICK',
  'CHCAINCLUDESTOREINVPICK',
  'INCLUDEDROPSHIPFLUS',
  'INCLUDEDROPSHIPCHUS',
  'INCLUDEDROPSHIPKFLUS',
  'INCLUDEDROPSHIPFLCA',
  'INCLUDEDROPSHIPCHCA'
] as const;
export type ProductAttributeColumnKey = (typeof productAttributeColumnKeys)[number];
export type ProductAttributeTrace = Record<ProductAttributeColumnKey, string | boolean | null>;
export type SkuTraceTabResponse = {
  sku: string;
  tab: SkuTraceTabKey;
  title: string;
  subtitle: string;
  refreshedAt: string;
  items?: TraceDetailItem[];
  banners?: BannerTrace[];
  sellingChannels?: SellingChannelTrace[];
  availability?: SkuAvailabilityTrace;
  exclusions?: SkuExclusionTrace[];
  productAttributes?: ProductAttributeTrace[];
  xrefs?: XrefTrace[];
};

const tabCopy: Record<SkuTraceTabKey, { title: string; subtitle: string }> = {
  banners: { title: 'Banner publication', subtitle: 'Publication readiness across every retail banner and channel.' },
  'selling-channel': { title: 'Selling channels', subtitle: 'Commerce channel assignment and go-live status for this SKU.' },
  'sku-availability': { title: 'SKU availability', subtitle: 'Availability by selling site and fulfillment experience.' },
  'product-attributes': { title: 'Product attributes', subtitle: 'Core product configuration supplied by the product hub.' },
  upc: { title: 'Universal Product Codes', subtitle: 'UPC records linked to this SKU.' },
  xref: { title: 'Cross references', subtitle: 'Connected product and vendor identifiers.' },
  exclusions: { title: 'Exclusions', subtitle: 'Publication and fulfillment exclusions.' },
  'dirty-node': { title: 'Dirty node', subtitle: 'Outstanding synchronization events requiring attention.' }
};

export const skuTraceTabApiRequests = {
  banners: (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/banners`,
  'selling-channel': (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/selling-channel`,
  'sku-availability': (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/sku-availability`,
  'product-attributes': (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/product-attributes`,
  upc: (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/upc`,
  xref: (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/xref`,
  exclusions: (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/exclusions`,
  'dirty-node': (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/dirty-node`
} satisfies Record<SkuTraceTabKey, (sku: string) => string>;

export const skuTraceSearchApiRequest = '/skus/trace/search';
export const skuTraceOnlineAvailabilityApiRequest = '/skus/trace/online-availability';
export const skuAvailabilityOnlineCheckApiRequest = (sku: string) => `/skus/${encodeURIComponent(sku)}/trace/sku-availability/online-check`;

const synchronizedExclusionSkus = new Set<string>();

function buildMockSearchResult(sku: string, index: number, launchDate?: string): SkuTraceSearchResult {
  const date = launchDate || `2026-07-${String((index % 28) + 1).padStart(2, '0')}`;
  const types: SkuTraceSearchResult['launchType'][] = ['Atomic', 'Hot', 'Flow', 'Cool'];
  const isFootLockerSample = sku.toUpperCase() === 'F6357102';
  return {
    sku,
    skuStatus: isFootLockerSample ? 'A' : index % 17 === 0 ? '' : index % 11 === 0 ? 'D' : index % 7 === 0 ? 'I' : 'A',
    launchDate: `${date} 00:00:00.000`,
    launchReservationDate: `2026-08-${String((index % 27) + 1).padStart(2, '0')} 00:00:00.000`,
    launchType: types[index % types.length],
    launchedBanners: isFootLockerSample ? 'FL' : ['FL, CS, KFL', 'FL, FLCA', 'CS, CSCA', 'FL, KFL, FLCA', 'FL, CSCA'][index % 5],
    banners: isFootLockerSample ? 'FL' : ['CHP, FL, KIDS', 'FL, FLCA', 'CHP, CSCA', 'FL, KIDS, CSCA', 'FL, FLCA, CSCA'][index % 5],
    image: index % 6 === 0 ? 'No' : 'Yes',
    copy: index % 5 === 0 ? 'No' : 'Yes',
    productType: index % 8 === 0 ? 'No' : 'Yes',
    sportsAttribute: index % 7 === 0 ? 'No' : 'Yes',
    frenchName: index % 6 === 0 ? 'N/A' : index % 4 === 0 ? 'No' : 'Yes',
    frenchCopy: index % 5 === 0 ? 'N/A' : index % 3 === 0 ? 'No' : 'Yes',
    description: isFootLockerSample ? "Nike Air Max 90 EasyOn - Boys' Preschool" : `SKU trace result ${String(index + 1).padStart(2, '0')} · Product configuration sample`,
    availableInIex: index % 3 === 0 ? 'No' : 'Yes',
    avavailableInIexStore: index % 4 === 0 ? 'No' : 'Yes',
    avavailbleInIexWhse: index % 5 === 0 ? 'No' : 'Yes',
    avavailableInIexDropship: index % 2 === 0 ? 'Yes' : 'No'
  };
}

export function buildSkuTraceSearchMockResponse(criteria: SkuTraceSearchRequest): SkuTraceSearchResponse {
  const requestedSkus = [...new Set((criteria.skus ?? []).map((sku) => sku.trim()).filter(Boolean))];
  const skus = requestedSkus.length
    ? requestedSkus
    : Array.from({ length: 50 }, (_, index) => `31${String(4103249000 + index * 37).padStart(10, '0')}`.slice(0, 12));
  const results = skus.slice(0, 50).map((sku, index) => buildMockSearchResult(sku, index, criteria.launchDate));
  return { results, total: results.length, searchedAt: new Date().toISOString(), criteria };
}

function buildMockOnlineAvailabilityResponse(items: OnlineAvailabilityCheck[]): OnlineAvailabilityResponse {
  return {
    checkedAt: new Date().toISOString(),
    results: items.flatMap(({ sku, banners }) => banners.map((banner, index) => ({
      sku,
      banner,
      online: sku.toUpperCase() === 'F6357102' && banner.toUpperCase() === 'FL'
        ? true
        : (Number(sku.slice(-1)) + index + banner.length) % 5 !== 0
    })))
  };
}

export function buildSkuTraceMockResponse(sku: string, tab: SkuTraceTabKey, view?: string): SkuTraceTabResponse {
  const common = { sku, tab, ...tabCopy[tab], refreshedAt: new Date().toISOString() };
  if (tab === 'banners') {
    return {
      ...common,
      banners: [
        { banner: 'Foot Locker', iex: true, iexStaging: true, internetChannel: true, online: true },
        { banner: 'Kids Foot Locker', iex: true, iexStaging: true, internetChannel: true, online: sku.endsWith('04') },
        { banner: 'Champs Sports', iex: true, iexStaging: false, internetChannel: true, online: true },
        { banner: 'WSS', iex: true, iexStaging: true, internetChannel: false, online: false }
      ]
    };
  }
  if (tab === 'selling-channel') {
    return {
      ...common,
      sellingChannels: [
        {
          sellingChannel: 'Internet',
          maoBanners: ['Foot Locker', 'Kids Foot Locker', 'Champs Sports'],
          sesBanners: ['Foot Locker', 'Kids Foot Locker', 'Champs Sports'],
          commonProductBanners: ['Foot Locker', 'Kids Foot Locker', 'Champs Sports']
        },
        {
          sellingChannel: 'Dropship',
          skuLevelEnabled: true,
          maoBanners: ['Foot Locker', 'Champs Sports'],
          sesBanners: [],
          commonProductBanners: ['Foot Locker']
        }
      ]
    };
  }
  if (tab === 'sku-availability') {
    const selectedView: AvailabilityView = (view && (availabilityViews as readonly string[]).includes(view) ? view : availabilityViews[0]) as AvailabilityView;
    const viewIndex = availabilityViews.indexOf(selectedView);
    const sizes = ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '12'];
    // Realistic reconciliation mix: most sizes match cleanly, a minority land
    // within tolerance (near-match), and a small tail shows a real discrepancy
    // (variance > 10) in exactly one source group.
    const affectedGroups: Array<'dc' | 'dropship' | 'store'> = ['dc', 'dropship', 'store'];
    const rows: SkuAvailabilityRow[] = sizes.map((size, index) => {
      const rowSeed = (index * 17 + viewIndex * 11) % 20;
      const profile: 'matched' | 'near' | 'discrepancy' = rowSeed < 13 ? 'matched' : rowSeed < 18 ? 'near' : 'discrepancy';
      const affectedGroup = affectedGroups[(index + viewIndex) % affectedGroups.length];
      const sign = index % 2 === 0 ? 1 : -1;
      const driftFor = (group: 'dc' | 'dropship' | 'store') => {
        if (profile === 'matched' || group !== affectedGroup) return 0;
        return profile === 'near' ? 3 + (index % 3) : 16 + (index % 8);
      };

      const whseCurrent = 40 + ((index * 7 + viewIndex * 5) % 60);
      const dcDrift = driftFor('dc');
      const dc: AvailabilityDcMetrics = {
        whseCurrent,
        mao: Math.max(0, whseCurrent + sign * dcDrift),
        maoStaging: Math.max(0, whseCurrent - Math.round(sign * dcDrift * 0.6)),
        iexInventoryStaging: Math.max(0, whseCurrent + Math.round(sign * dcDrift * 0.4))
      };

      const dsco = 20 + ((index * 5 + viewIndex * 4) % 40);
      const dropDrift = driftFor('dropship');
      const dropship: AvailabilityDropshipMetrics = {
        dsco,
        mao: Math.max(0, dsco + sign * dropDrift),
        flStaging: Math.max(0, dsco - Math.round(sign * dropDrift * 0.6)),
        iexInventory: Math.max(0, dsco + Math.round(sign * dropDrift * 0.4))
      };

      const storeBase = 8 + ((index * 3 + viewIndex * 2) % 20);
      const storeDrift = driftFor('store');
      const store: AvailabilityStoreMetrics = {
        mao: Math.max(0, storeBase + sign * storeDrift),
        flStaging: Math.max(0, storeBase - Math.round(sign * storeDrift * 0.6)),
        iexInventory: Math.max(0, storeBase + Math.round(sign * storeDrift * 0.4))
      };

      const overall: AvailabilityOverallMetrics = {
        mao: dc.mao + dropship.mao + store.mao,
        flStaging: dc.maoStaging + dropship.flStaging + store.flStaging,
        iexInventory: dc.iexInventoryStaging + dropship.iexInventory + store.iexInventory
      };

      return {
        size,
        globalSizeId: `GS-${sku.slice(-4)}-${String(index + 1).padStart(3, '0')}`,
        iexPxd: (index + viewIndex) % 6 === 0 ? 'Unavailable' : 'Available',
        dc,
        dropship,
        store,
        overall
      };
    });
    return {
      ...common,
      availability: { views: [...availabilityViews], selectedView, rows }
    };
  }
  if (tab === 'product-attributes') {
    const sizes = ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '12'];
    return {
      ...common,
      productAttributes: sizes.map((size, rowIndex) => Object.fromEntries(productAttributeColumnKeys.map((key, columnIndex) => {
        if (key === 'LEGACY_SKU') return [key, sku];
        if (key === 'LEGACY_SIZE_DESC') return [key, size];
        if (key === 'GLOBAL_SIZE_ID') return [key, `GS-${sku.slice(-4)}-${String(rowIndex + 1).padStart(3, '0')}`];
        if (key === 'VENDORSTYLE') return [key, `VS-${sku.slice(0, 6)}`];
        if ((rowIndex + columnIndex) % 23 === 0) return [key, null];
        return [key, (rowIndex * 3 + columnIndex) % 7 !== 0];
      })) as ProductAttributeTrace)
    };
  }
  if (tab === 'xref') {
    const sizes = ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '12'];
    return {
      ...common,
      xrefs: sizes.map((size, index) => ({
        cpid: `CP-${sku.slice(-6)}-${String(index + 1).padStart(2, '0')}`,
        skuNumber: sku,
        vendorStyle: `VS-${sku.slice(0, 6)}`,
        sizeDesc: size,
        sizeId: `SZ-${String(index + 7).padStart(3, '0')}`,
        globalColorId: `GC-${sku.slice(-3)}`,
        globalStyleId: `GST-${sku.slice(-6)}`,
        globalSizeId: `GS-${sku.slice(-4)}-${String(index + 1).padStart(3, '0')}`,
        sizeCode: size.replace('.', ''),
        styleDesc: 'Nike Air Max Dn8',
        division: index % 2 === 0 ? 'Footwear' : 'Athletic Footwear',
        department: index % 3 === 0 ? 'Men\'s' : index % 3 === 1 ? 'Women\'s' : 'Kids',
        countryCode: index > 7 ? 'CA' : 'US'
      }))
    };
  }
  if (tab === 'exclusions') {
    const styleId = `ST-${sku.slice(-6)}`;
    const colorId = sku.slice(-3);
    const synchronized = synchronizedExclusionSkus.has(sku);
    return {
      ...common,
      exclusions: [
        { banner: 'FL', styleId, colorId, type: 'BOSS', status: 'active', maoStatus: 'active', startDate: '2026-07-15', endDate: '2026-08-15' },
        { banner: 'KFL', styleId, colorId, type: 'BOPIS', status: 'active', maoStatus: synchronized ? 'active' : 'inactive', startDate: '2026-07-18', endDate: '2026-08-31' },
        { banner: 'CHCA', styleId, colorId: `${colorId}-CA`, type: 'CBF', status: 'active', maoStatus: 'active', startDate: '2026-07-20', endDate: '2026-09-01' },
        { banner: 'FLCA', styleId, colorId: `${colorId}-CA`, type: 'CBP', status: 'active', maoStatus: synchronized ? 'active' : 'inactive', startDate: '2026-07-22', endDate: '2026-09-10' },
        { banner: 'CHP', styleId: `${styleId}-CHP`, colorId, type: 'BOSS', status: 'active', maoStatus: 'active', startDate: '2026-07-25', endDate: '2026-08-25' }
      ]
    };
  }

  if (tab === 'upc') {
    return {
      ...common,
      items: [
      { label: 'Primary UPC', value: sku },
      { label: 'Case UPC', value: `1${sku.slice(0, 11)}` },
      { label: 'Status', value: 'Validated' },
      { label: 'Source', value: 'Product Hub' }
      ]
    };
  }
  return {
    ...common,
    items: [
      { label: 'Current state', value: 'Clean' },
      { label: 'Node', value: 'Product Hub' },
      { label: 'Retry count', value: '0' },
      { label: 'Resolution', value: 'No action required' }
    ]
  };
}

function buildMockAvailabilityOnlineResponse(request: AvailabilityOnlineCheckRequest): AvailabilityOnlineResponse {
  const viewIndex = availabilityViews.indexOf(request.view);
  return {
    checkedAt: new Date().toISOString(),
    results: request.globalSizeIds.map((globalSizeId, index) => ({
      globalSizeId,
      online: (index + viewIndex + Number(request.sku.slice(-1) || 0)) % 5 !== 0
    }))
  };
}

function mockResponse<T>(payload: T, signal?: AbortSignal): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeout = window.setTimeout(() => resolve(payload), 520);
    signal?.addEventListener('abort', () => {
      window.clearTimeout(timeout);
      reject(new DOMException('The request was aborted.', 'AbortError'));
    }, { once: true });
  });
}

export const skuTraceApi = {
  search: (criteria: SkuTraceSearchRequest, signal?: AbortSignal) =>
    apiConfiguration.useMockApi
      ? mockResponse(buildSkuTraceSearchMockResponse(criteria), signal)
      : apiClient.post<SkuTraceSearchResponse>(skuTraceSearchApiRequest, criteria, { signal }),
  checkOnlineAvailability: (items: OnlineAvailabilityCheck[], signal?: AbortSignal) =>
    apiConfiguration.useMockApi
      ? mockResponse(buildMockOnlineAvailabilityResponse(items), signal)
      : apiClient.post<OnlineAvailabilityResponse>(skuTraceOnlineAvailabilityApiRequest, { items }, { signal }),
  getTab: (sku: string, tab: SkuTraceTabKey, signal?: AbortSignal, view?: string) =>
    apiConfiguration.useMockApi
      ? mockResponse(buildSkuTraceMockResponse(sku, tab, view), signal)
      : apiClient.get<SkuTraceTabResponse>(skuTraceTabApiRequests[tab](sku), { signal, query: { view } }),
  checkAvailabilityOnline: (request: AvailabilityOnlineCheckRequest, signal?: AbortSignal) =>
    apiConfiguration.useMockApi
      ? mockResponse(buildMockAvailabilityOnlineResponse(request), signal)
      : apiClient.post<AvailabilityOnlineResponse>(skuAvailabilityOnlineCheckApiRequest(request.sku), request, { signal }),
  syncSellingChannels: (sku: string, signal?: AbortSignal) =>
    apiConfiguration.useMockApi
      ? mockResponse({ sku, status: 'success', message: 'Selling channels synchronized successfully.', synchronizedAt: new Date().toISOString() }, signal)
      : apiClient.post<{ sku: string; status: string; message: string; synchronizedAt: string }>(
        `/skus/${encodeURIComponent(sku)}/trace/selling-channel/sync`,
        undefined,
        { signal }
      ),
  syncExclusions: async (sku: string, signal?: AbortSignal) => {
    if (apiConfiguration.useMockApi) {
      const response = await mockResponse({ sku, status: 'success', message: 'Exclusion mismatches synchronized successfully.', synchronizedAt: new Date().toISOString() }, signal);
      synchronizedExclusionSkus.add(sku);
      return response;
    }
    return apiClient.post<{ sku: string; status: string; message: string; synchronizedAt: string }>(
      `/skus/${encodeURIComponent(sku)}/trace/exclusions/sync`,
      undefined,
      { signal }
    );
  }
};
