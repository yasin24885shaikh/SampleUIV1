import { Fragment, useMemo, useState, type ReactNode } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  ButtonBase,
  Chip,
  Dialog,
  DialogContent,
  FormControl,
  InputAdornment,
  InputLabel,
  LinearProgress,
  MenuItem,
  Pagination,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Tooltip,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha, useTheme } from '@mui/material/styles';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import BoltIcon from '@mui/icons-material/Bolt';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import HubIcon from '@mui/icons-material/Hub';
import InsightsIcon from '@mui/icons-material/Insights';
import PsychologyIcon from '@mui/icons-material/Psychology';
import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import SearchIcon from '@mui/icons-material/Search';
import SyncIcon from '@mui/icons-material/Sync';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import { Bar, BarChart, CartesianGrid, Cell, LabelList, Pie, PieChart, ResponsiveContainer, Tooltip as ChartTooltip, XAxis, YAxis } from 'recharts';
import { motion } from 'framer-motion';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi, type AllocationTraceMismatchRow, type AllocationTraceResponse, type AllocationTraceSummaryRow } from '../services/omsApi';

type SortKey = keyof AllocationTraceMismatchRow;
type JourneyType = 'release' | 'fulfillment';
type CauseId = 'alloc-mao' | 'mao' | 'mao-whse' | 'whse';
type CauseCategory = { id: CauseId; label: string; system: string; short: string; accent: string; description: string };
type CauseReason = { reason: string; count: number; orders: string[]; nodes: string[]; variance: number };
type CauseBreakdown = CauseCategory & { count: number; variance: number; reasons: CauseReason[]; nodes: string[] };
type ActionPlanStep = CauseBreakdown & { priority: 'High' | 'Medium' | 'Low'; confidence: number; action: string; automation: string };
type AllocationTotals = { allocationOrders: number; allocationQty: number; maoOrders: number; maoQty: number; maoCancelledOrders: number; maoCancelledQty: number; whseOrders: number; whseQty: number };

const emptySummaryRows: AllocationTraceSummaryRow[] = [];
const emptyMismatchRows: AllocationTraceMismatchRow[] = [];

const number = new Intl.NumberFormat('en-US');

const journeyOptions: Array<{ value: JourneyType; label: string }> = [
  { value: 'release', label: 'Allocation Order Release Journey' },
  { value: 'fulfillment', label: 'Allocation Order Fulfillment Journey' }
];

function buildTimeOptions() {
  const times: string[] = [];
  for (let hour = 0; hour < 24; hour += 1) {
    for (const minute of [0, 30]) {
      const period = hour < 12 ? 'AM' : 'PM';
      const displayHour = hour % 12 === 0 ? 12 : hour % 12;
      times.push(`${String(displayHour).padStart(2, '0')}:${String(minute).padStart(2, '0')} ${period}`);
    }
  }
  return times;
}

const timeOptions = buildTimeOptions();

const causeCategories: CauseCategory[] = [
  { id: 'alloc-mao', label: 'Allocation → MAO handoff', system: 'Allocation Service → MAO', short: 'Alloc → MAO', accent: '#1769e0', description: 'Store SO was submitted by the Allocation engine but never created in MAO.' },
  { id: 'mao', label: 'MAO order processing', system: 'MAO', short: 'MAO', accent: '#7c3aed', description: 'MAO created the store SO but with a quantity or state difference from allocation.' },
  { id: 'mao-whse', label: 'MAO → Warehouse integration', system: 'MAO → Warehouse', short: 'MAO → WHSE', accent: '#e77718', description: 'The release payload failed to reach, was rejected by, or is unacknowledged at the warehouse.' },
  { id: 'whse', label: 'Warehouse fulfillment', system: 'Warehouse / Store', short: 'WHSE / Store', accent: '#c62828', description: 'The warehouse received the store SO but under-fulfilled the requested quantity.' }
];

const causeById = new Map(causeCategories.map((cause) => [cause.id, cause]));

function classifyMismatch(row: AllocationTraceMismatchRow): CauseId {
  const reason = row.mismatch.toLowerCase();
  if (reason.includes('not created')) return 'alloc-mao';
  if (reason.includes('ingestion') || reason.includes('payload') || reason.includes('rejected') || reason.includes('acknowledg')) return 'mao-whse';
  if (reason.includes('mao') && (reason.includes('quantity') || reason.includes('exceeds'))) return 'mao';
  return 'whse';
}

const actionPlaybook: Record<CauseId, { action: string; automation: string }> = {
  'alloc-mao': { action: 'Replay allocation submissions missing in MAO', automation: 'Agent re-publishes the store SO create events to MAO and confirms acknowledgement for each SO order.' },
  'mao': { action: 'Reconcile MAO store-SO quantities to allocation', automation: 'Agent recomputes SO quantity from the allocation source of truth and patches drifted lines in MAO.' },
  'mao-whse': { action: 'Re-release and resync warehouse payloads', automation: 'Agent re-publishes release payloads to the fulfilling warehouse and runs the acknowledgement sync loop.' },
  'whse': { action: 'Escalate warehouse under-fulfillment', automation: 'Agent opens a node review task and stages short units for reallocation to an alternate warehouse.' }
};

function buildCauseBreakdown(mismatchRows: AllocationTraceMismatchRow[]): CauseBreakdown[] {
  return causeCategories.map((cause) => {
    const rows = mismatchRows.filter((row) => classifyMismatch(row) === cause.id);
    const reasonMap = new Map<string, CauseReason>();
    rows.forEach((row) => {
      const entry = reasonMap.get(row.mismatch) ?? { reason: row.mismatch, count: 0, orders: [], nodes: [], variance: 0 };
      entry.count += 1;
      entry.orders.push(row.soOrder);
      if (!entry.nodes.includes(row.fulfillmentWhse)) entry.nodes.push(row.fulfillmentWhse);
      entry.variance += Math.abs(row.variance);
      reasonMap.set(row.mismatch, entry);
    });
    return {
      ...cause,
      count: rows.length,
      variance: rows.reduce((sum, row) => sum + Math.abs(row.variance), 0),
      reasons: [...reasonMap.values()].sort((a, b) => b.count - a.count),
      nodes: [...new Set(rows.map((row) => row.fulfillmentWhse))]
    };
  });
}

function pct(part: number, whole: number) {
  if (whole <= 0) return 100;
  return Math.max(0, Math.min(100, (part / whole) * 100));
}

export default function AllocationOrderTrace() {
  const [journeyType, setJourneyType] = useState<JourneyType>('release');
  const [traceDate, setTraceDate] = useState('2026-07-12');
  const [traceTime, setTraceTime] = useState('09:00 AM');
  const [submittedCriteria, setSubmittedCriteria] = useState<{ date: string; time: string; journeyType: JourneyType } | null>(null);
  const [traceData, setTraceData] = useState<AllocationTraceResponse | null>(null);
  const [fetchError, setFetchError] = useState('');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState<Record<string, string>>({});
  const [sortKey, setSortKey] = useState<SortKey>('lastEvent');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const [selectedCause, setSelectedCause] = useState<CauseId | ''>('');
  const pageSize = 15;
  const summaryRows = traceData?.summary ?? emptySummaryRows;
  const mismatchRows = traceData?.mismatches ?? emptyMismatchRows;

  const totals = useMemo(() => summaryRows.reduce((total, row) => ({
    allocationOrders: total.allocationOrders + row.allocationOrders,
    allocationQty: total.allocationQty + row.allocationQty,
    maoOrders: total.maoOrders + row.maoOrders,
    maoQty: total.maoQty + row.maoQty,
    maoCancelledOrders: total.maoCancelledOrders + row.maoCancelledOrders,
    maoCancelledQty: total.maoCancelledQty + row.maoCancelledQty,
    whseOrders: total.whseOrders + row.whseOrders,
    whseQty: total.whseQty + row.whseQty
  }), { allocationOrders: 0, allocationQty: 0, maoOrders: 0, maoQty: 0, maoCancelledOrders: 0, maoCancelledQty: 0, whseOrders: 0, whseQty: 0 }), [summaryRows]);

  const filteredMismatches = useMemo(() => {
    const global = globalSearch.trim().toLowerCase();
    return mismatchRows
      .filter((row) => {
        if (selectedWarehouse && row.fulfillmentWhse !== selectedWarehouse) return false;
        if (selectedCause && classifyMismatch(row) !== selectedCause) return false;
        const record = Object.values(row).join(' ').toLowerCase();
        if (global && !record.includes(global)) return false;
        return Object.entries(columnSearch).every(([key, value]) => !value.trim() || String(row[key as SortKey]).toLowerCase().includes(value.trim().toLowerCase()));
      })
      .sort((a, b) => {
        const left = a[sortKey];
        const right = b[sortKey];
        const comparison = typeof left === 'number' && typeof right === 'number' ? left - right : String(left).localeCompare(String(right));
        return sortDirection === 'asc' ? comparison : -comparison;
      });
  }, [columnSearch, globalSearch, mismatchRows, selectedCause, selectedWarehouse, sortDirection, sortKey]);
  const pageCount = Math.max(1, Math.ceil(filteredMismatches.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const paginatedMismatches = filteredMismatches.slice((safePage - 1) * pageSize, safePage * pageSize);
  const mismatchSummary = useMemo(() => ({
    count: filteredMismatches.length,
    quantityVariance: filteredMismatches.reduce((sum, row) => sum + Math.abs(row.variance), 0),
    affectedNodes: new Set(filteredMismatches.map((row) => row.fulfillmentWhse)).size,
    unresolved: filteredMismatches.filter((row) => row.maoStatus !== 'Created' || row.whseStatus !== 'Received').length
  }), [filteredMismatches]);

  const submitTrace = async () => {
    if (!traceDate) return;
    setLoading(true);
    setProgress(10);
    setFetchError('');
    setPage(1);
    const timer = window.setInterval(() => setProgress((current) => Math.min(current + 16, 92)), 170);
    try {
      const response = await omsApi.getAllocationOrderTrace({ fromDate: traceDate, toDate: traceDate, timezone: 'America/Chicago', journeyType, time: traceTime });
      window.clearInterval(timer);
      setProgress(100);
      setTraceData(response);
      setSubmittedCriteria({ date: response.range?.fromDate ?? traceDate, time: traceTime, journeyType });
      setGlobalSearch('');
      setColumnSearch({});
      setSelectedWarehouse('');
      setSelectedCause('');
    } catch (requestError) {
      window.clearInterval(timer);
      setTraceData(null);
      setSubmittedCriteria(null);
      setFetchError(requestError instanceof Error ? requestError.message : 'Unable to load allocation trace data.');
    } finally {
      window.setTimeout(() => {
        setLoading(false);
        setProgress(0);
      }, 320);
    }
  };

  const changeSort = (key: SortKey) => {
    setPage(1);
    if (sortKey === key) setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  const focusCause = (id: CauseId | '') => {
    setSelectedCause((current) => current === id ? '' : id);
    setPage(1);
  };

  return (
    <Box>
      <PageHeader title="Allocation Order Trace" subtitle="Trace allocation orders created for destination stores and fulfilled from JC, Camp Hill, Reno, or Milton warehouses." badge="STORE ALLOCATION" />

      <GlassCard sx={{ p: { xs: 1.75, md: 2.25 }, mb: 2 }}>
        <Stack direction="row" spacing={1.1} alignItems="center" sx={{ mb: 1.75 }}>
          <Box sx={{ width: 36, height: 36, borderRadius: 1.3, display: 'grid', placeItems: 'center', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12), color: 'primary.main' }}>
            <AccountTreeIcon fontSize="small" />
          </Box>
          <Box>
            <Typography variant="subtitle1" fontWeight={950} lineHeight={1.2}>Trace search criteria</Typography>
            <Typography variant="caption" color="text.secondary">Choose a journey, date, and time to reconcile allocation activity.</Typography>
          </Box>
        </Stack>
        <Grid container spacing={1.5} alignItems="flex-end">
          <Grid item xs={12} sm={6} md={4}>
            <FormControl size="small" fullWidth>
              <InputLabel id="journey-type-label">Journey type</InputLabel>
              <Select
                labelId="journey-type-label"
                label="Journey type"
                value={journeyType}
                onChange={(event) => setJourneyType(event.target.value as JourneyType)}
                startAdornment={<InputAdornment position="start"><AccountTreeIcon fontSize="small" color="primary" sx={{ ml: 0.5 }} /></InputAdornment>}
              >
                {journeyOptions.map((option) => <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={2.5}>
            <TextField
              size="small"
              fullWidth
              type="date"
              label="Date"
              value={traceDate}
              onChange={(event) => setTraceDate(event.target.value)}
              InputLabelProps={{ shrink: true }}
              InputProps={{ startAdornment: <InputAdornment position="start"><CalendarMonthIcon fontSize="small" color="primary" /></InputAdornment> }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={2.5}>
            <FormControl size="small" fullWidth>
              <InputLabel id="trace-time-label">Time</InputLabel>
              <Select
                labelId="trace-time-label"
                label="Time"
                value={traceTime}
                onChange={(event) => setTraceTime(event.target.value)}
                startAdornment={<InputAdornment position="start"><AccessTimeIcon fontSize="small" color="primary" sx={{ ml: 0.5 }} /></InputAdornment>}
                MenuProps={{ PaperProps: { sx: { maxHeight: 320 } } }}
              >
                {timeOptions.map((time) => <MenuItem key={time} value={time}>{time}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Button
              variant="contained"
              fullWidth
              size="large"
              startIcon={<AccountTreeIcon />}
              onClick={submitTrace}
              disabled={!traceDate}
              sx={{ minHeight: 40, px: 2.5, fontWeight: 850, borderRadius: 1.4, whiteSpace: 'nowrap', boxShadow: (theme) => `0 10px 24px ${alpha(theme.palette.primary.main, 0.28)}` }}
            >
              Run Allocation Trace
            </Button>
          </Grid>
        </Grid>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>Time shown is Central Time.</Typography>
        {fetchError && <Alert severity="error" sx={{ mt: 1.25 }} onClose={() => setFetchError('')}>{fetchError}</Alert>}
      </GlassCard>

      {!submittedCriteria && (
        <GlassCard sx={{ p: 3, textAlign: 'center' }}>
          <CalendarMonthIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h6" fontWeight={950} sx={{ mt: 1 }}>Select trace criteria to begin</Typography>
          <Typography color="text.secondary">Choose a journey type, date, and time, then run the trace to compare store SO order counts and quantities across Allocation, MAO, and the fulfilling warehouse.</Typography>
        </GlassCard>
      )}

      {submittedCriteria && (
        <Stack spacing={2}>
          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="01" title="Reconciliation Summary" subtitle={`${journeyOptions.find((option) => option.value === submittedCriteria.journeyType)?.label} · ${submittedCriteria.date} at ${submittedCriteria.time} CT · Store allocations grouped by fulfilling warehouse`} />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Grid container spacing={1.25} sx={{ mb: 1.75 }}>
                <SummaryKpi label="Store allocations submitted" orders={totals.allocationOrders} quantity={totals.allocationQty} tone="primary" />
                <SummaryKpi label="MAO store SO created" orders={totals.maoOrders} quantity={totals.maoQty} tone="success" />
                <SummaryKpi label="Cancelled in MAO" orders={totals.maoCancelledOrders} quantity={totals.maoCancelledQty} tone="warning" />
                <SummaryKpi label="WHSE fulfillment received" orders={totals.whseOrders} quantity={totals.whseQty} tone="info" />
                <SummaryKpi label="Actual mismatches" orders={mismatchRows.length} quantity={mismatchRows.reduce((sum, row) => sum + Math.abs(row.variance), 0)} tone="error" mismatch />
              </Grid>
              <Alert severity="info" sx={{ mb: 1.5 }}>
                MAO-cancelled store SOs are intentionally stopped before warehouse release. They remain visible in the summary but are excluded from the actionable warehouse mismatch count.
              </Alert>
              <Box sx={{ mb: 1.5 }}>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ sm: 'center' }} sx={{ mb: 1 }}>
                  <Box>
                    <Typography fontWeight={950}>Warehouse reconciliation flow</Typography>
                    <Typography variant="caption" color="text.secondary">Select a warehouse lane to focus the mismatch table.</Typography>
                  </Box>
                  {selectedWarehouse && <Chip size="small" label={`${selectedWarehouse} selected`} color="primary" onDelete={() => { setSelectedWarehouse(''); setPage(1); }} />}
                </Stack>
                <Grid container spacing={1}>
                  {summaryRows.map((row) => (
                    <Grid item xs={12} lg={6} key={`flow-${row.node}`}>
                      <WarehouseFlowLane
                        row={row}
                        selected={selectedWarehouse === row.node}
                        onSelect={() => {
                          setSelectedWarehouse((current) => current === row.node ? '' : row.node);
                          setPage(1);
                        }}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Box>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table className="sku-trace-table-style allocation-summary-table" size="small" sx={{ minWidth: 960 }}>
                  <TableHead>
                    <TableRow>
                      <TableCell rowSpan={2}>Fulfilling warehouse</TableCell>
                      <TableCell colSpan={2} align="center">Allocation → Store</TableCell>
                      <TableCell colSpan={2} align="center">MAO Store SO</TableCell>
                      <TableCell colSpan={2} align="center">Cancelled in MAO</TableCell>
                      <TableCell colSpan={2} align="center">WHSE fulfillment</TableCell>
                      <TableCell rowSpan={2} align="right">Actionable gap</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {summaryRows.map((row) => (
                      <TableRow key={row.node} hover>
                        <TableCell><Stack direction="row" spacing={1} alignItems="center"><WarehouseIcon color="action" fontSize="small" /><Typography fontWeight={900}>{row.node}</Typography></Stack></TableCell>
                        <TableCell align="right">{number.format(row.allocationOrders)}</TableCell><TableCell align="right">{number.format(row.allocationQty)}</TableCell>
                        <TableCell align="right">{number.format(row.maoOrders)}</TableCell><TableCell align="right">{number.format(row.maoQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="warning" variant="outlined" label={number.format(row.maoCancelledOrders)} /></TableCell><TableCell align="right">{number.format(row.maoCancelledQty)}</TableCell>
                        <TableCell align="right">{number.format(row.whseOrders)}</TableCell><TableCell align="right">{number.format(row.whseQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" variant="outlined" label={`-${number.format(Math.max(row.maoOrders - row.maoCancelledOrders - row.whseOrders, 0))}`} /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Box>
            </Box>
          </GlassCard>

          <AiAgentSummary
            sectionNumber="02"
            journeyLabel={journeyOptions.find((option) => option.value === submittedCriteria.journeyType)?.label ?? ''}
            dateTimeLabel={`${submittedCriteria.date} at ${submittedCriteria.time} CT`}
            mismatchRows={mismatchRows}
            totals={totals}
            selectedCause={selectedCause}
            onSelectCause={focusCause}
          />

          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="03" title="Actual Mismatches" subtitle="Store SO-level exceptions with Allocation, MAO, and fulfilling-warehouse details side by side" />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: 1, mb: 1.5 }}>
                <MismatchSummaryCard label="Matching mismatches" value={mismatchSummary.count} detail="Current search and filters" tone="error" />
                <MismatchSummaryCard label="Quantity variance" value={mismatchSummary.quantityVariance} detail="Absolute unit variance" tone="warning" />
                <MismatchSummaryCard label="Affected nodes" value={mismatchSummary.affectedNodes} detail="Fulfillment locations" tone="info" />
                <MismatchSummaryCard label="Missing / unresolved" value={mismatchSummary.unresolved} detail="Needs operational review" tone="primary" />
              </Box>
              <Alert severity="info" icon={<SyncIcon />} sx={{ mb: 1.5 }}>
                <Typography fontWeight={900}>How actual mismatches are fetched</Typography>
                <Typography variant="body2">The trace joins each store allocation to its MAO SO by SO order number, identifies the assigned fulfillment warehouse, and compares that warehouse's acknowledgement and quantity. Only missing records or unequal quantities appear below.</Typography>
              </Alert>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between" sx={{ mb: 1.25 }}>
                <TextField size="small" label="Global search" placeholder="Search any mismatch detail" value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} sx={{ minWidth: { md: 360 } }} InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
                <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                  {selectedCause && <Chip color="primary" icon={<HubIcon />} label={`AI focus: ${causeById.get(selectedCause)?.short}`} onDelete={() => focusCause('')} sx={{ fontWeight: 900 }} />}
                  <Chip color="error" label={`${filteredMismatches.length} mismatches`} />
                  <Typography variant="caption" color="text.secondary">Click any column heading to sort</Typography>
                </Stack>
              </Stack>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table className="sku-trace-table-style allocation-mismatch-table" size="small" sx={{ minWidth: 1540 }}>
                  <TableHead>
                    <TableRow>
                      <SortableHead label="SO order" field="soOrder" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Destination store" field="store" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Fulfilling WHSE" field="fulfillmentWhse" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Allocation status" field="allocationStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Alloc qty" field="allocationQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO status" field="maoStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO qty" field="maoQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="WHSE / Store status" field="whseStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Node qty" field="whseQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Variance" field="variance" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Mismatch reason" field="mismatch" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Last event" field="lastEvent" active={sortKey} direction={sortDirection} onSort={changeSort} />
                    </TableRow>
                    <TableRow>
                      {(['soOrder', 'store', 'fulfillmentWhse', 'allocationStatus', 'allocationQty', 'maoStatus', 'maoQty', 'whseStatus', 'whseQty', 'variance', 'mismatch', 'lastEvent'] as SortKey[]).map((field) => (
                        <TableCell key={field} sx={{ py: 0.7 }}><TextField variant="standard" size="small" placeholder="Filter" value={columnSearch[field] ?? ''} onChange={(event) => { setColumnSearch((current) => ({ ...current, [field]: event.target.value })); setPage(1); }} InputProps={{ disableUnderline: true }} sx={{ minWidth: field === 'mismatch' ? 170 : 90, '& input': { fontSize: '.75rem', py: 0.4 } }} /></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedMismatches.map((row) => (
                      <TableRow key={row.soOrder} hover>
                        <TableCell><Typography fontWeight={950} color="primary.main">{row.soOrder}</Typography></TableCell>
                        <TableCell><Typography fontWeight={850}>{row.store}</Typography></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" color="action" /><Typography fontWeight={850}>{row.fulfillmentWhse}</Typography></Stack></TableCell>
                        <TableCell><Status value={row.allocationStatus} /></TableCell><TableCell align="right">{row.allocationQty}</TableCell>
                        <TableCell><Status value={row.maoStatus} /></TableCell><TableCell align="right">{row.maoQty}</TableCell>
                        <TableCell><Status value={row.whseStatus} /></TableCell><TableCell align="right">{row.whseQty}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" label={row.variance > 0 ? `+${row.variance}` : row.variance} /></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><ErrorOutlineIcon color="error" fontSize="small" /><Typography variant="body2" fontWeight={800}>{row.mismatch}</Typography></Stack></TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.lastEvent}</TableCell>
                      </TableRow>
                    ))}
                    {!filteredMismatches.length && <TableRow><TableCell colSpan={12}><Alert severity="success">No mismatches match the current search and column filters.</Alert></TableCell></TableRow>}
                  </TableBody>
                </Table>
              </Box>
              {filteredMismatches.length > 0 && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems="center" sx={{ mt: 1.4 }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {number.format((safePage - 1) * pageSize + 1)}–{number.format(Math.min(safePage * pageSize, filteredMismatches.length))} of {number.format(filteredMismatches.length)} orders · 15 per page
                  </Typography>
                  <Pagination page={safePage} count={pageCount} onChange={(_, value) => setPage(value)} color="primary" size="small" showFirstButton showLastButton />
                </Stack>
              )}
            </Box>
          </GlassCard>
        </Stack>
      )}

      <Dialog open={loading} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 2.25 } }}>
        <DialogContent sx={{ p: 2.4 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Box><Typography variant="overline" color="primary.main" fontWeight={950}>Live reconciliation</Typography><Typography variant="h6" fontWeight={950}>{progress === 100 ? 'Trace ready' : 'Fetching order layers'}</Typography></Box>
            <Typography fontWeight={950} color="primary.main">{progress}%</Typography>
          </Stack>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 999, '& .MuiLinearProgress-bar': { borderRadius: 999 } }} />
          <Stack spacing={0.8} sx={{ mt: 1.5 }}>
            <ProgressStep done={progress >= 25} label="Allocation submissions loaded" />
            <ProgressStep done={progress >= 55} label="MAO SO orders correlated" />
            <ProgressStep done={progress >= 85} label="Store and warehouse actuals compared" />
          </Stack>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function SectionHeader({ number: sectionNumber, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return <Box sx={{ px: 2, py: 1.45, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}><Stack direction="row" spacing={1.2} alignItems="center"><Box sx={{ width: 36, height: 36, borderRadius: 1.3, display: 'grid', placeItems: 'center', bgcolor: 'primary.main', color: 'primary.contrastText', fontWeight: 950 }}>{sectionNumber}</Box><Box><Typography variant="h6" fontWeight={950}>{title}</Typography><Typography variant="body2" color="text.secondary">{subtitle}</Typography></Box></Stack></Box>;
}

function SummaryKpi({ label, orders, quantity, tone, mismatch = false }: { label: string; orders: number; quantity: number; tone: 'primary' | 'success' | 'info' | 'warning' | 'error'; mismatch?: boolean }) {
  return <Grid item xs={12} sm={6} lg={3}><Box sx={{ p: 1.4, height: '100%', border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.055) }}><Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography><Typography variant="h5" fontWeight={950}>{number.format(orders)}</Typography><Typography variant="body2" color="text.secondary">{mismatch ? `${number.format(quantity)} quantity variance` : `${number.format(quantity)} units · SO order level`}</Typography></Box></Grid>;
}

function MismatchSummaryCard({ label, value, detail, tone }: { label: string; value: number; detail: string; tone: 'primary' | 'info' | 'warning' | 'error' }) {
  return (
    <Box sx={{ px: 1.35, py: 1.15, border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.28), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.065), boxShadow: (theme) => `inset 4px 0 0 ${theme.palette[tone].main}` }}>
      <Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography>
      <Typography variant="h5" fontWeight={950}>{number.format(value)}</Typography>
      <Typography variant="caption" color="text.secondary">{detail}</Typography>
    </Box>
  );
}

function WarehouseFlowLane({ row, selected, onSelect }: { row: AllocationTraceSummaryRow; selected: boolean; onSelect: () => void }) {
  const eligibleMaoOrders = Math.max(row.maoOrders - row.maoCancelledOrders, 0);
  const maoGap = Math.max(row.allocationOrders - row.maoOrders, 0);
  const warehouseGap = Math.max(eligibleMaoOrders - row.whseOrders, 0);
  return (
    <ButtonBase
      onClick={onSelect}
      aria-pressed={selected}
      sx={{
        width: '100%', p: 0, overflow: 'hidden', border: 1, borderColor: selected ? 'primary.main' : 'divider', borderRadius: 1.6,
        bgcolor: (theme) => selected ? alpha(theme.palette.primary.main, 0.08) : alpha(theme.palette.background.paper, 0.72),
        textAlign: 'left', display: 'block'
      }}
    >
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ px: 1.15, py: 0.85, color: '#fff', background: selected ? 'linear-gradient(135deg, #244f70, #2f668f)' : 'linear-gradient(135deg, #376f96, #2f668f)' }}
      >
        <Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" sx={{ color: '#fff' }} /><Typography fontWeight={950}>{row.node}</Typography></Stack>
        <Chip size="small" label={`${warehouseGap} actionable gap`} sx={{ fontWeight: 900, color: warehouseGap ? '#a0161d' : '#17633c', bgcolor: warehouseGap ? '#fde8e9' : '#e1f4e9', border: '1px solid', borderColor: warehouseGap ? '#f3b5b9' : '#abd8bc' }} />
      </Stack>
      <Stack direction="row" spacing={0.65} alignItems="stretch" sx={{ p: 1.15 }}>
        <FlowStage label="Allocation → Store" value={row.allocationOrders} detail={`${maoGap} not created`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="MAO eligible" value={eligibleMaoOrders} detail={`${row.maoCancelledOrders} cancelled`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="WHSE received" value={row.whseOrders} detail={`${number.format(row.whseQty)} units`} />
      </Stack>
    </ButtonBase>
  );
}

function FlowStage({ label, value, detail }: { label: string; value: number; detail: string }) {
  return <Box sx={{ flex: 1, minWidth: 0, px: 0.8, py: 0.65, borderRadius: 1.1, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.055) }}><Typography variant="caption" color="text.secondary" noWrap>{label}</Typography><Typography fontWeight={950}>{number.format(value)}</Typography><Typography variant="caption" color="text.secondary" noWrap>{detail}</Typography></Box>;
}

function SortableHead({ label, field, active, direction, onSort }: { label: string; field: SortKey; active: SortKey; direction: 'asc' | 'desc'; onSort: (field: SortKey) => void }) {
  const isActive = active === field;
  return <TableCell sortDirection={isActive ? direction : false} sx={{ whiteSpace: 'nowrap' }}><TableSortLabel active={isActive} direction={isActive ? direction : 'asc'} hideSortIcon={false} onClick={() => onSort(field)} sx={{ width: '100%', '& .MuiTableSortLabel-icon': { opacity: isActive ? 1 : 0.55 } }}>{label}</TableSortLabel></TableCell>;
}

function Status({ value }: { value: string }) {
  const good = ['Submitted', 'Created', 'Received'].includes(value);
  const pending = value === 'Pending';
  return <Chip size="small" variant={good ? 'outlined' : 'filled'} color={good ? 'success' : pending ? 'warning' : 'error'} label={value} />;
}

function ProgressStep({ done, label }: { done: boolean; label: string }) {
  return <Stack direction="row" spacing={0.8} alignItems="center"><CheckCircleIcon color={done ? 'success' : 'disabled'} fontSize="small" /><Typography variant="body2" fontWeight={done ? 850 : 650} color={done ? 'text.primary' : 'text.secondary'}>{label}</Typography></Stack>;
}

function AiAgentSummary({ sectionNumber, journeyLabel, dateTimeLabel, mismatchRows, totals, selectedCause, onSelectCause }: {
  sectionNumber: string;
  journeyLabel: string;
  dateTimeLabel: string;
  mismatchRows: AllocationTraceMismatchRow[];
  totals: AllocationTotals;
  selectedCause: CauseId | '';
  onSelectCause: (id: CauseId | '') => void;
}) {
  const theme = useTheme();
  const causeBreakdown = useMemo(() => buildCauseBreakdown(mismatchRows), [mismatchRows]);
  const totalMismatches = mismatchRows.length;
  const rankedCauses = useMemo(() => causeBreakdown.filter((cause) => cause.count > 0).sort((a, b) => b.count - a.count), [causeBreakdown]);
  const topCause = rankedCauses[0];
  const causeCount = (id: CauseId) => causeBreakdown.find((cause) => cause.id === id)?.count ?? 0;

  const nodeFailure = useMemo(() => {
    const map = new Map<string, number>();
    mismatchRows.forEach((row) => map.set(row.fulfillmentWhse, (map.get(row.fulfillmentWhse) ?? 0) + 1));
    return [...map.entries()].map(([node, failures]) => ({ node, failures })).sort((a, b) => b.failures - a.failures);
  }, [mismatchRows]);

  const reasonTotals = useMemo(() => {
    const map = new Map<string, { reason: string; count: number; accent: string }>();
    mismatchRows.forEach((row) => {
      const accent = causeById.get(classifyMismatch(row))?.accent ?? '#64748b';
      const entry = map.get(row.mismatch) ?? { reason: row.mismatch, count: 0, accent };
      entry.count += 1;
      map.set(row.mismatch, entry);
    });
    return [...map.values()].sort((a, b) => b.count - a.count);
  }, [mismatchRows]);

  const hops = [
    { id: 'alloc-mao' as CauseId, label: 'Allocation → MAO', system: 'Allocation Service ↔ MAO', processed: totals.allocationOrders, failed: causeCount('alloc-mao') },
    { id: 'mao' as CauseId, label: 'MAO processing', system: 'MAO order engine', processed: totals.maoOrders, failed: causeCount('mao') },
    { id: 'mao-whse' as CauseId, label: 'MAO → Warehouse', system: 'MAO ↔ Warehouse', processed: Math.max(totals.maoOrders - totals.maoCancelledOrders, 0), failed: causeCount('mao-whse') },
    { id: 'whse' as CauseId, label: 'Warehouse → Fulfilled', system: 'Warehouse / Store', processed: totals.whseOrders, failed: causeCount('whse') }
  ];
  const worstHopId = hops.reduce((worst, hop) => hop.failed > worst.failed ? hop : worst, hops[0]).id;

  const analyzed = totals.allocationOrders;
  const cleanPct = pct(analyzed - totalMismatches, analyzed);
  const topNode = nodeFailure[0];
  const variance = mismatchRows.reduce((sum, row) => sum + Math.abs(row.variance), 0);
  const donutData = causeBreakdown.filter((cause) => cause.count > 0).map((cause) => ({ id: cause.id, name: cause.short, value: cause.count, accent: cause.accent }));
  const reasonData = reasonTotals.slice(0, 6);
  const actionSteps: ActionPlanStep[] = rankedCauses.map((cause, index) => ({
    ...cause,
    priority: index === 0 ? 'High' : index === 1 ? 'Medium' : 'Low',
    confidence: Math.max(62, 96 - index * 8),
    action: actionPlaybook[cause.id].action,
    automation: actionPlaybook[cause.id].automation
  }));

  return (
    <GlassCard sx={{ overflow: 'hidden' }}>
      <SectionHeader number={sectionNumber} title="AI Agent Diagnostic Summary" subtitle={`Agentic reconciliation of Allocation, MAO, and Warehouse interactions · ${journeyLabel} · ${dateTimeLabel}`} />
      <Box sx={{ p: { xs: 1.4, md: 2 } }}>
        {totalMismatches === 0 || !topCause ? (
          <Alert severity="success" icon={<AutoAwesomeIcon />}>
            The AI agent reconciled every store-SO interaction across Allocation, MAO, and Warehouse systems with no exceptions. No remediation is required.
          </Alert>
        ) : (
          <>
            <Box component={motion.div} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}
              sx={{ p: { xs: 1.4, md: 1.8 }, borderRadius: 2, border: 1, borderColor: (t) => alpha(t.palette.primary.main, 0.2), background: (t) => `linear-gradient(120deg, ${alpha(t.palette.primary.main, 0.1)}, ${alpha(t.palette.background.paper, 0.5)})` }}
            >
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
                <Box sx={{ width: 34, height: 34, borderRadius: 1.3, display: 'grid', placeItems: 'center', color: '#fff', bgcolor: 'primary.main' }}><AutoAwesomeIcon fontSize="small" /></Box>
                <Box sx={{ flex: 1 }}>
                  <Stack direction="row" spacing={0.8} alignItems="center" flexWrap="wrap" useFlexGap>
                    <Typography fontWeight={950}>AI reconciliation summary</Typography>
                    <Chip size="small" color="primary" variant="outlined" icon={<PsychologyIcon />} label="Agent generated" sx={{ height: 20, fontWeight: 800 }} />
                  </Stack>
                  <Typography variant="caption" color="text.secondary">Synthesized from {number.format(analyzed)} store-SO interactions across Allocation, MAO, and Warehouse systems.</Typography>
                </Box>
              </Stack>
              <Grid container spacing={1} sx={{ mb: 1.25 }}>
                <NarrativeMetric label="Interactions analyzed" value={number.format(analyzed)} tone="primary" />
                <NarrativeMetric label="Exceptions detected" value={number.format(totalMismatches)} tone="error" />
                <NarrativeMetric label="Clean reconciliation" value={`${cleanPct.toFixed(2)}%`} tone="success" />
                <NarrativeMetric label="Quantity variance" value={`${number.format(variance)} units`} tone="warning" />
              </Grid>
              <Stack spacing={0.7}>
                <AiInsightRow icon={<InsightsIcon fontSize="small" />} text={<>The largest concentration is in <b>{topCause.label}</b> — {topCause.count} of {totalMismatches} exceptions ({pct(topCause.count, totalMismatches).toFixed(0)}%), driven mainly by “{topCause.reasons[0]?.reason}”.</>} />
                {topNode && <AiInsightRow icon={<WarehouseIcon fontSize="small" />} text={<><b>{topNode.node}</b> is the most affected node with {topNode.failures} exception{topNode.failures === 1 ? '' : 's'} along the fulfillment path.</>} />}
                <AiInsightRow icon={<BoltIcon fontSize="small" />} text={<>Recommended first action: <b>{actionPlaybook[topCause.id].action}</b>.</>} />
              </Stack>
            </Box>

            <SubHeader icon={<HubIcon fontSize="small" />} title="System interaction health" caption="Per-hop reconciliation across the Allocation → MAO → Warehouse path · select a hop to focus its exceptions" />
            <SystemInteractionFlow hops={hops} worstHopId={worstHopId} selectedCause={selectedCause} onSelectCause={onSelectCause} />

            <SubHeader icon={<InsightsIcon fontSize="small" />} title="Failure analytics" caption="What failed, where, and for which reason" />
            <Grid container spacing={1.5}>
              <Grid item xs={12} md={4}>
                <MiniChartCard title="Failures by system interaction" subtitle="Click a slice or chip to focus">
                  <CauseDonut data={donutData} total={totalMismatches} selectedCause={selectedCause} onSelectCause={onSelectCause} />
                </MiniChartCard>
              </Grid>
              <Grid item xs={12} md={4}>
                <MiniChartCard title="Failures by warehouse node" subtitle="Fulfilling warehouse exposure">
                  <NodeFailureChart data={nodeFailure} />
                </MiniChartCard>
              </Grid>
              <Grid item xs={12} md={4}>
                <MiniChartCard title="Top failure reasons" subtitle="Distinct mismatch reasons">
                  <ReasonFailureChart data={reasonData} />
                </MiniChartCard>
              </Grid>
            </Grid>

            <SubHeader icon={<AccountTreeIcon fontSize="small" />} title="Root-cause fishbone" caption="Ishikawa cause-and-effect across the four system interactions" />
            <FishboneDiagram causeBreakdown={causeBreakdown} total={totalMismatches} selectedCause={selectedCause} onSelectCause={onSelectCause} textColor={theme.palette.text.primary} />

            <SubHeader icon={<ReportProblemIcon fontSize="small" />} title="Root-cause explorer" caption="Expand a category to see what failed and for which reason" />
            <RootCauseExplorer causeBreakdown={causeBreakdown} total={totalMismatches} selectedCause={selectedCause} onSelectCause={onSelectCause} />

            <SubHeader icon={<AutoAwesomeIcon fontSize="small" />} title="Agentic AI action plan" caption="Recommended automated remediation, staged for human approval" />
            <AgenticActionPlan steps={actionSteps} totalMismatches={totalMismatches} />
          </>
        )}
      </Box>
    </GlassCard>
  );
}

function SubHeader({ icon, title, caption }: { icon: ReactNode; title: string; caption: string }) {
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 2, mb: 1 }}>
      <Box sx={{ width: 30, height: 30, borderRadius: 1.2, display: 'grid', placeItems: 'center', color: 'primary.main', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.1) }}>{icon}</Box>
      <Box><Typography fontWeight={950} lineHeight={1.15}>{title}</Typography><Typography variant="caption" color="text.secondary">{caption}</Typography></Box>
    </Stack>
  );
}

function NarrativeMetric({ label, value, tone }: { label: string; value: string; tone: 'primary' | 'success' | 'warning' | 'error' }) {
  return (
    <Grid item xs={6} md={3}>
      <Box sx={{ p: 1, borderRadius: 1.4, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.08), border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.22) }}>
        <Typography variant="caption" color={`${tone}.main`} fontWeight={900} sx={{ display: 'block', lineHeight: 1.1 }}>{label}</Typography>
        <Typography variant="h6" fontWeight={950} sx={{ lineHeight: 1.15 }}>{value}</Typography>
      </Box>
    </Grid>
  );
}

function AiInsightRow({ icon, text }: { icon: ReactNode; text: ReactNode }) {
  return (
    <Stack direction="row" spacing={1} alignItems="flex-start">
      <Box sx={{ color: 'primary.main', mt: 0.2, flex: '0 0 auto' }}>{icon}</Box>
      <Typography variant="body2">{text}</Typography>
    </Stack>
  );
}

function MiniChartCard({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <Box sx={{ height: '100%', p: 1.25, border: 1, borderColor: 'divider', borderRadius: 1.75, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.6) }}>
      <Typography fontWeight={900} variant="body2">{title}</Typography>
      {subtitle && <Typography variant="caption" color="text.secondary">{subtitle}</Typography>}
      <Box sx={{ mt: 1 }}>{children}</Box>
    </Box>
  );
}

function SystemInteractionFlow({ hops, worstHopId, selectedCause, onSelectCause }: {
  hops: Array<{ id: CauseId; label: string; system: string; processed: number; failed: number }>;
  worstHopId: CauseId;
  selectedCause: CauseId | '';
  onSelectCause: (id: CauseId | '') => void;
}) {
  return (
    <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, alignItems: 'stretch', gap: 1 }}>
      {hops.map((hop, index) => {
        const health = pct(hop.processed - hop.failed, hop.processed);
        const tone: 'success' | 'warning' | 'error' = hop.failed === 0 ? 'success' : hop.id === worstHopId ? 'error' : 'warning';
        const active = selectedCause === hop.id;
        return (
          <Fragment key={hop.id}>
            <ButtonBase onClick={() => onSelectCause(hop.id)} sx={{ flex: 1, display: 'block', textAlign: 'left', p: 1.2, borderRadius: 1.6, border: 2, borderColor: active ? `${tone}.main` : 'divider', bgcolor: (theme) => alpha(theme.palette[tone].main, active ? 0.12 : 0.04) }}>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 0.6 }}>
                <Typography variant="caption" color="text.secondary" fontWeight={800} noWrap>{hop.system}</Typography>
                <Chip size="small" color={tone} variant={hop.failed ? 'filled' : 'outlined'} label={hop.failed ? `${hop.failed} failed` : 'Healthy'} sx={{ height: 20, fontWeight: 900 }} />
              </Stack>
              <Typography fontWeight={950} noWrap>{hop.label}</Typography>
              <Typography variant="caption" color="text.secondary">{number.format(hop.processed)} SO processed · {health.toFixed(2)}% clean</Typography>
              <LinearProgress variant="determinate" value={health} color={tone} sx={{ mt: 0.6, height: 6, borderRadius: 999 }} />
            </ButtonBase>
            {index < hops.length - 1 && <Box sx={{ display: 'grid', placeItems: 'center', px: 0.2 }}><ArrowForwardIcon color="disabled" sx={{ transform: { xs: 'rotate(90deg)', md: 'none' } }} /></Box>}
          </Fragment>
        );
      })}
    </Box>
  );
}

function CauseDonut({ data, total, selectedCause, onSelectCause }: {
  data: Array<{ id: CauseId; name: string; value: number; accent: string }>;
  total: number;
  selectedCause: CauseId | '';
  onSelectCause: (id: CauseId | '') => void;
}) {
  const handleSlice = (entry: any) => {
    const id: CauseId | undefined = entry?.id ?? entry?.payload?.id;
    if (id) onSelectCause(id);
  };
  return (
    <Box>
      <Box sx={{ position: 'relative' }}>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius={54} outerRadius={82} paddingAngle={2} onClick={handleSlice}>
              {data.map((slice) => <Cell key={slice.id} fill={slice.accent} fillOpacity={!selectedCause || selectedCause === slice.id ? 1 : 0.3} />)}
            </Pie>
            <ChartTooltip formatter={(value: number, name: string) => [`${value} failures`, name]} />
          </PieChart>
        </ResponsiveContainer>
        <Box sx={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" fontWeight={950} lineHeight={1}>{number.format(total)}</Typography>
            <Typography variant="caption" color="text.secondary">exceptions</Typography>
          </Box>
        </Box>
      </Box>
      <Stack direction="row" flexWrap="wrap" useFlexGap spacing={0.5} sx={{ mt: 0.5, justifyContent: 'center' }}>
        {data.map((slice) => (
          <Chip key={slice.id} size="small" onClick={() => onSelectCause(slice.id)} variant={selectedCause === slice.id ? 'filled' : 'outlined'} label={`${slice.name} · ${slice.value}`}
            sx={{ fontWeight: 800, borderColor: slice.accent, color: selectedCause === slice.id ? '#fff' : slice.accent, bgcolor: selectedCause === slice.id ? slice.accent : 'transparent', '&:hover': { bgcolor: selectedCause === slice.id ? slice.accent : alpha(slice.accent, 0.1) }, '& .MuiChip-label': { px: 0.9 } }} />
        ))}
      </Stack>
    </Box>
  );
}

function NodeFailureChart({ data }: { data: Array<{ node: string; failures: number }> }) {
  return (
    <ResponsiveContainer width="100%" height={232}>
      <BarChart data={data} margin={{ top: 14, right: 12, bottom: 4, left: -20 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(100,116,139,.18)" vertical={false} />
        <XAxis dataKey="node" tick={{ fontSize: 11 }} interval={0} />
        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
        <ChartTooltip formatter={(value: number) => [`${value} failures`, 'Failures']} />
        <Bar dataKey="failures" radius={[6, 6, 0, 0]} fill="#2f668f">
          <LabelList dataKey="failures" position="top" style={{ fontSize: 11, fontWeight: 700 }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function ReasonFailureChart({ data }: { data: Array<{ reason: string; count: number; accent: string }> }) {
  return (
    <ResponsiveContainer width="100%" height={232}>
      <BarChart layout="vertical" data={data} margin={{ top: 4, right: 30, bottom: 4, left: 6 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(100,116,139,.18)" horizontal={false} />
        <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
        <YAxis type="category" dataKey="reason" width={150} tick={{ fontSize: 9.5 }} tickFormatter={(value: string) => value.length > 26 ? `${value.slice(0, 25)}…` : value} />
        <ChartTooltip formatter={(value: number) => [`${value} orders`, 'Failures']} />
        <Bar dataKey="count" radius={[0, 6, 6, 0]}>
          {data.map((entry, index) => <Cell key={index} fill={entry.accent} />)}
          <LabelList dataKey="count" position="right" style={{ fontSize: 11, fontWeight: 700 }} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function FishboneDiagram({ causeBreakdown, total, selectedCause, onSelectCause, textColor }: {
  causeBreakdown: CauseBreakdown[];
  total: number;
  selectedCause: CauseId | '';
  onSelectCause: (id: CauseId | '') => void;
  textColor: string;
}) {
  const anchors = [200, 330, 470, 600];
  const truncate = (value: string, max = 30) => value.length > max ? `${value.slice(0, max - 1)}…` : value;
  return (
    <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75, p: 1, bgcolor: (theme) => alpha(theme.palette.background.paper, 0.5) }}>
      <svg viewBox="0 0 760 430" width="100%" style={{ minWidth: 720, display: 'block' }}>
        <line x1={40} y1={215} x2={628} y2={215} stroke={textColor} strokeOpacity={0.55} strokeWidth={3} />
        <polygon points="628,182 720,182 756,215 720,248 628,248" fill={textColor} fillOpacity={0.88} />
        <text x={674} y={210} textAnchor="middle" fill="#fff" fontSize={12} fontWeight={800}>Mismatches</text>
        <text x={674} y={230} textAnchor="middle" fill="#fff" fontSize={14} fontWeight={800}>{total}</text>
        <text x={690} y={276} textAnchor="middle" fill={textColor} fillOpacity={0.6} fontSize={10} fontWeight={700}>Allocation ↔ Fulfillment</text>
        {causeBreakdown.map((cause, index) => {
          const ax = anchors[index];
          const top = index % 2 === 0;
          const ox = ax - 120;
          const oy = top ? 80 : 350;
          const boxY = top ? oy - 58 : oy;
          const dim = selectedCause !== '' && selectedCause !== cause.id;
          const isSelected = selectedCause === cause.id;
          return (
            <g key={cause.id} style={{ cursor: 'pointer' }} opacity={dim ? 0.32 : 1} onClick={() => onSelectCause(cause.id)}>
              <line x1={ax} y1={215} x2={ox} y2={oy} stroke={cause.accent} strokeWidth={2.4} />
              <circle cx={ax} cy={215} r={4.5} fill={cause.accent} />
              <rect x={ox} y={boxY} width={182} height={58} rx={8} fill={cause.accent} fillOpacity={isSelected ? 0.22 : 0.12} stroke={cause.accent} strokeWidth={isSelected ? 2 : 1.2} />
              <text x={ox + 10} y={boxY + 19} fill={cause.accent} fontSize={12} fontWeight={800}>{cause.short} · {cause.count}</text>
              {cause.count === 0 ? (
                <text x={ox + 10} y={boxY + 37} fill={textColor} fillOpacity={0.55} fontSize={10}>No failures detected</text>
              ) : cause.reasons.length <= 2 ? (
                cause.reasons.map((reason, rIndex) => (
                  <text key={reason.reason} x={ox + 10} y={boxY + 36 + rIndex * 13} fill={textColor} fillOpacity={0.72} fontSize={9.5}>• {truncate(`${reason.reason} (${reason.count})`)}</text>
                ))
              ) : (
                <>
                  <text x={ox + 10} y={boxY + 36} fill={textColor} fillOpacity={0.72} fontSize={9.5}>• {truncate(`${cause.reasons[0].reason} (${cause.reasons[0].count})`)}</text>
                  <text x={ox + 10} y={boxY + 49} fill={textColor} fillOpacity={0.55} fontSize={9}>+{cause.reasons.length - 1} more reason{cause.reasons.length - 1 === 1 ? '' : 's'}</text>
                </>
              )}
            </g>
          );
        })}
      </svg>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>Select a bone to focus its exceptions in the mismatch table below.</Typography>
    </Box>
  );
}

function RootCauseExplorer({ causeBreakdown, total, selectedCause, onSelectCause }: {
  causeBreakdown: CauseBreakdown[];
  total: number;
  selectedCause: CauseId | '';
  onSelectCause: (id: CauseId | '') => void;
}) {
  const [expanded, setExpanded] = useState<CauseId | false>(() => causeBreakdown.find((cause) => cause.count > 0)?.id ?? false);
  return (
    <Box>
      {causeBreakdown.map((cause) => {
        const share = pct(cause.count, total);
        const focused = selectedCause === cause.id;
        return (
          <Accordion
            key={cause.id}
            expanded={expanded === cause.id}
            onChange={(_, isExpanded) => setExpanded(isExpanded ? cause.id : false)}
            disableGutters
            sx={{ mb: 1, borderRadius: 1.6, border: 2, borderColor: focused ? cause.accent : 'divider', '&:before': { display: 'none' }, overflow: 'hidden' }}
          >
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Stack direction="row" alignItems="center" spacing={1.2} sx={{ width: '100%', pr: 1 }}>
                <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: cause.accent, flex: '0 0 auto' }} />
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography fontWeight={900} noWrap>{cause.label}</Typography>
                  <Typography variant="caption" color="text.secondary" noWrap>{cause.system}</Typography>
                </Box>
                <Box sx={{ width: { xs: 70, sm: 130 }, flex: '0 0 auto' }}>
                  <LinearProgress variant="determinate" value={share} sx={{ height: 6, borderRadius: 999, '& .MuiLinearProgress-bar': { bgcolor: cause.accent } }} />
                </Box>
                <Chip size="small" label={`${cause.count}`} sx={{ fontWeight: 900, color: '#fff', bgcolor: cause.accent, minWidth: 40 }} />
              </Stack>
            </AccordionSummary>
            <AccordionDetails sx={{ bgcolor: (theme) => alpha(theme.palette.background.default, 0.5) }}>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{cause.description}</Typography>
              {cause.count === 0 ? (
                <Alert severity="success">No exceptions attributed to this system interaction.</Alert>
              ) : (
                <Stack spacing={1}>
                  {cause.reasons.map((reason) => (
                    <Box key={reason.reason} sx={{ p: 1, border: 1, borderColor: 'divider', borderRadius: 1.3, bgcolor: 'background.paper' }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
                        <Stack direction="row" spacing={0.7} alignItems="center"><ErrorOutlineIcon fontSize="small" sx={{ color: cause.accent }} /><Typography fontWeight={850} variant="body2">{reason.reason}</Typography></Stack>
                        <Stack direction="row" spacing={0.5}><Chip size="small" variant="outlined" label={`${reason.count} order${reason.count === 1 ? '' : 's'}`} /><Chip size="small" variant="outlined" color="warning" label={`${reason.variance} units`} /></Stack>
                      </Stack>
                      <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap sx={{ mb: 0.5 }}>
                        {reason.nodes.map((node) => <Chip key={node} size="small" icon={<WarehouseIcon />} label={node} sx={{ height: 22 }} />)}
                      </Stack>
                      <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                        {reason.orders.slice(0, 6).map((order) => <Chip key={order} size="small" variant="outlined" label={order} sx={{ height: 22 }} />)}
                        {reason.orders.length > 6 && <Chip size="small" variant="outlined" label={`+${reason.orders.length - 6} more`} sx={{ height: 22 }} />}
                      </Stack>
                    </Box>
                  ))}
                  <Button size="small" variant={focused ? 'contained' : 'outlined'} startIcon={<HubIcon />} onClick={() => onSelectCause(cause.id)} sx={{ alignSelf: 'flex-start', fontWeight: 800 }}>
                    {focused ? 'Focused in mismatch table' : 'Focus these in the mismatch table'}
                  </Button>
                </Stack>
              )}
            </AccordionDetails>
          </Accordion>
        );
      })}
    </Box>
  );
}

function AgenticActionPlan({ steps, totalMismatches }: { steps: ActionPlanStep[]; totalMismatches: number }) {
  const [queued, setQueued] = useState<Set<CauseId>>(new Set());
  const toggle = (id: CauseId) => setQueued((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });
  const queueAll = () => setQueued(new Set(steps.map((step) => step.id)));
  const priorityColor = (priority: ActionPlanStep['priority']): 'error' | 'warning' | 'info' => priority === 'High' ? 'error' : priority === 'Medium' ? 'warning' : 'info';
  return (
    <Box sx={{ border: 1, borderColor: (theme) => alpha(theme.palette.primary.main, 0.25), borderRadius: 1.75, overflow: 'hidden' }}>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} spacing={1} sx={{ px: 1.5, py: 1.2, background: (theme) => `linear-gradient(120deg, ${alpha(theme.palette.primary.main, 0.12)}, ${alpha(theme.palette.background.paper, 0.4)})` }}>
        <Stack direction="row" spacing={1} alignItems="center">
          <PsychologyIcon color="primary" />
          <Box>
            <Typography fontWeight={950}>Recommended remediation plan</Typography>
            <Typography variant="caption" color="text.secondary">{steps.length} agent action{steps.length === 1 ? '' : 's'} to resolve {number.format(totalMismatches)} exceptions</Typography>
          </Box>
        </Stack>
        <Button size="small" variant="contained" startIcon={<BoltIcon />} onClick={queueAll} disabled={queued.size === steps.length} sx={{ fontWeight: 800, borderRadius: 1.4 }}>Queue all actions</Button>
      </Stack>
      <Stack sx={{ p: 1.25 }} spacing={1}>
        {steps.map((step, index) => {
          const isQueued = queued.has(step.id);
          return (
            <Box key={step.id} sx={{ p: 1.2, border: 1, borderColor: isQueued ? 'success.main' : 'divider', borderRadius: 1.4, bgcolor: (theme) => isQueued ? alpha(theme.palette.success.main, 0.06) : 'background.paper', boxShadow: `inset 4px 0 0 ${step.accent}` }}>
              <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" spacing={1}>
                <Stack direction="row" spacing={1.2} sx={{ minWidth: 0 }}>
                  <Box sx={{ width: 28, height: 28, flex: '0 0 auto', borderRadius: 1, display: 'grid', placeItems: 'center', color: '#fff', bgcolor: step.accent, fontWeight: 950 }}>{index + 1}</Box>
                  <Box sx={{ minWidth: 0 }}>
                    <Stack direction="row" spacing={0.7} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mb: 0.3 }}>
                      <Typography fontWeight={900}>{step.action}</Typography>
                      <Chip size="small" color={priorityColor(step.priority)} label={`${step.priority} priority`} sx={{ height: 20, fontWeight: 800 }} />
                      <Tooltip title="Model confidence that the automated action resolves this cause" arrow>
                        <Chip size="small" variant="outlined" label={`${step.confidence}% confidence`} sx={{ height: 20, fontWeight: 800 }} />
                      </Tooltip>
                    </Stack>
                    <Typography variant="body2" color="text.secondary">{step.automation}</Typography>
                    <Typography variant="caption" color="text.secondary">Target: {step.system} · Resolves {step.count} exception{step.count === 1 ? '' : 's'} ({step.variance} units)</Typography>
                  </Box>
                </Stack>
                <Box sx={{ flex: '0 0 auto', alignSelf: { md: 'center' } }}>
                  <Button size="small" variant={isQueued ? 'outlined' : 'contained'} color={isQueued ? 'success' : 'primary'} startIcon={isQueued ? <CheckCircleIcon /> : <AutoAwesomeIcon />} onClick={() => toggle(step.id)} sx={{ fontWeight: 800, borderRadius: 1.4, whiteSpace: 'nowrap' }}>
                    {isQueued ? 'Queued' : 'Queue action'}
                  </Button>
                </Box>
              </Stack>
            </Box>
          );
        })}
      </Stack>
      <Box sx={{ px: 1.5, py: 1, borderTop: 1, borderColor: 'divider' }}>
        <Stack direction="row" spacing={0.8} alignItems="center"><TipsAndUpdatesIcon fontSize="small" color="warning" /><Typography variant="caption" color="text.secondary">Simulation only — queued actions are staged for a human operator to approve. Nothing is executed automatically.</Typography></Stack>
      </Box>
    </Box>
  );
}
