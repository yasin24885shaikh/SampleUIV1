# OMS REST API Integration

The UI reads and writes through `src/services/omsApi.ts`. It uses the populated mock REST adapter by default, so the demo works without a server.

## Connect a backend

Create `.env.local` from `.env.example` and set:

```env
VITE_API_BASE_URL=/api/v1
VITE_OMS_API_BASE_URL=/api/oms/v1
VITE_USER_API_BASE_URL=/api/users/v1
VITE_AI_API_BASE_URL=/api/ai/v1
VITE_OMS_API_TARGET=http://localhost:8080
VITE_USER_API_TARGET=http://localhost:8081
VITE_AI_API_TARGET=http://localhost:8090
VITE_API_TIMEOUT_MS=15000
VITE_USE_MOCK_API=false
```

Restart Vite after changing environment variables. During local development, Vite proxies same-origin frontend routes to backend services, which avoids browser CORS errors while still calling the real APIs.

| Frontend path | Backend target | Intended service |
| --- | --- | --- |
| `/api/v1/**` | `VITE_OMS_API_TARGET` | Default OMS compatibility route |
| `/api/oms/v1/**` | `VITE_OMS_API_TARGET` | OMS order APIs |
| `/api/users/v1/**` | `VITE_USER_API_TARGET` | User/admin APIs |
| `/api/ai/v1/**` | `VITE_AI_API_TARGET` | AI analytics APIs |

The proxy rewrites `/api/oms`, `/api/users`, and `/api/ai` back to `/api` before forwarding. For example, `/api/ai/v1/order-trace` is sent to `http://localhost:8090/api/v1/order-trace`.

Requests send and accept JSON and use `credentials: include` for cookie-based sessions. Authentication headers can be added once in `src/services/apiClient.ts` if the backend uses bearer tokens.

## Read endpoints

| Method | Endpoint | UI consumer | Response |
| --- | --- | --- | --- |
| GET | `/dashboard` | Executive Dashboard | `DashboardResponse` |
| POST | `/orders/details` | Order Live Tracking search | `CollectionResponse<Order>`, `{ "items": [] }`, `{ "orders": [] }`, `{ "data": [] }`, or raw `Order[]` |
| POST | `/orders/allocation-trace` | Allocation Order Trace | `AllocationTraceResponse` |
| GET | `/inventory` | Inventory Management | `InventoryResponse` |
| GET | `/products` | Common Products | `CollectionResponse<Product>` |
| GET | `/products/{sku}/documentation` | SKU Documentation | `SkuDocumentationResponse` |
| GET | `/users` | User Management | `CollectionResponse<OmsUser>` |
| GET | `/notifications` | Header notification drawer | `NotificationResponse` |

`POST /orders/details` is called only when the user clicks Search. The request body sends the selected order IDs:

```json
{
  "orderIds": [
    "FL-10048291"
  ]
}
```

`POST /orders/allocation-trace` is called only after a valid date range is submitted. Existing summary and mismatch row field names are preserved:

```json
{
  "fromDate": "2026-07-12",
  "toDate": "2026-07-13",
  "timezone": "America/Chicago"
}
```

The response contains the existing row structures under `summary` and `mismatches`:

```json
{
  "range": {
    "fromDate": "2026-07-12",
    "toDate": "2026-07-13",
    "timezone": "America/Chicago"
  },
  "summary": [],
  "mismatches": [],
  "generatedAt": "2026-07-14T12:00:00.000Z"
}
```

Collection responses use this envelope:

```json
{
  "items": [],
  "total": 0,
  "page": 1,
  "pageSize": 20
}
```

## SKU Tracert tab APIs

### SKU search

Both search paths use the same request, so a launch-calendar selection and a manual list are handled consistently. The manual list supports up to 50 SKU values.

| Search | Method | Endpoint | Request body |
| --- | --- | --- | --- |
| Launch date | POST | `/skus/trace/search` | `{ "launchDate": "2026-07-14" }` |
| Manual SKUs | POST | `/skus/trace/search` | `{ "skus": ["314103249004", "314103249104"] }` |

The response contains `{ results, total, searchedAt, criteria }`. Each result carries the All, Launch, Product Attributes, and Inventory-view fields. In mock mode, a date search deliberately returns 50 results to exercise the paged multiple-SKU experience.

After the results render, the UI runs one non-blocking bulk availability check and marks each launched-banner or banner link with an Online **Yes** or **No** badge:

| Method | Endpoint | Request body |
| --- | --- | --- |
| POST | `/skus/trace/online-availability` | `{ "items": [{ "sku": "314103249004", "banners": ["FL", "CS"] }] }` |

The backend performs the external product-page requests and returns `{ "results": [{ "sku": "314103249004", "banner": "FL", "online": true }], "checkedAt": "..." }`. This server-side check avoids browser CORS restrictions and keeps the retail-site traffic out of the client.

Opening a SKU calls the Banners endpoint. Selecting another tab calls that tab's endpoint, and the tab-level Refresh button repeats the same request. SKU Availability also repeats its request when the selected banner changes.

| Tab | Method | Endpoint | Response data |
| --- | --- | --- | --- |
| Banners | GET | `/skus/{sku}/trace/banners` | `banners: BannerTrace[]` |
| Selling Channel | GET | `/skus/{sku}/trace/selling-channel` | `sellingChannels: SellingChannelTrace[]` |
| SKU Availability | GET | `/skus/{sku}/trace/sku-availability?banner={banner}` | `availability: SkuAvailabilityTrace` |
| Product Attributes | GET | `/skus/{sku}/trace/product-attributes` | `productAttributes: ProductAttributeTrace[]` |
| UPC | GET | `/skus/{sku}/trace/upc` | `items: TraceDetailItem[]` |
| Xref | GET | `/skus/{sku}/trace/xref` | `xrefs: XrefTrace[]` |
| Exclusions | GET | `/skus/{sku}/trace/exclusions` | `exclusions: SkuExclusionTrace[]` |
| Dirty Node | GET | `/skus/{sku}/trace/dirty-node` | `items: TraceDetailItem[]` |

Every tab returns the shared response metadata plus its tab-specific data:

```json
{
  "sku": "314103249004",
  "tab": "xref",
  "title": "Cross references",
  "subtitle": "Connected product and vendor identifiers.",
  "refreshedAt": "2026-07-21T12:00:00.000Z",
  "xrefs": []
}
```

The same TypeScript contracts drive live and mock modes. Mock mode is enabled unless `VITE_USE_MOCK_API=false`. The explicit request map is exported as `skuTraceTabApiRequests`, and deterministic mock payloads are available through `buildSkuTraceMockResponse` in `src/services/skuTraceApi.ts`.

Mock payload collections by tab:

```json
{
  "banners": [{ "banner": "Foot Locker", "iex": true, "iexStaging": true, "internetChannel": true, "online": true }],
  "sellingChannels": [{ "sellingChannel": "Internet", "maoBanners": ["Foot Locker"], "sesBanners": ["Foot Locker"], "commonProductBanners": ["Foot Locker"] }],
  "availability": { "banners": ["Foot Locker"], "selectedBanner": "Foot Locker", "ecomRfEnabled": true, "sizeAvailability": [], "warehouseAvailability": [] },
  "productAttributes": [],
  "items": [{ "label": "Primary UPC", "value": "314103249004" }],
  "xrefs": [{ "cpid": "CP-249004-01", "skuNumber": "314103249004", "globalSizeId": "GS-9004-001" }],
  "exclusions": [{ "banner": "FL", "type": "BOSS", "status": "active", "maoStatus": "active" }]
}
```

Command requests remain separate from tab reads:

| Action | Method | Endpoint |
| --- | --- | --- |
| Sync selling channels | POST | `/skus/{sku}/trace/selling-channel/sync` |
| Sync exclusion mismatches | POST | `/skus/{sku}/trace/exclusions/sync` |

## Command endpoints

| Method | Endpoint | Request body |
| --- | --- | --- |
| POST | `/releases/{releaseId}/rerelease` | none |
| POST | `/releases/{releaseId}/reroute` | `{ "createDeliveryNote": true }` |
| POST | `/releases/{releaseId}/hard-cancel` | none |
| POST | `/fulfillments/{fulfillmentId}/sync` | none |

All TypeScript response contracts are exported from `src/services/omsApi.ts`. Failed non-2xx responses may return `{ "message": "..." }`; the shared client turns these into `ApiError` instances and the screens expose retry states.
