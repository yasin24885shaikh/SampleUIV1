import { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  ButtonBase,
  Chip,
  Dialog,
  DialogContent,
  InputAdornment,
  LinearProgress,
  Pagination,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Typography
} from '@mui/material';
import Grid from '@mui/material/GridLegacy';
import { alpha } from '@mui/material/styles';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import SearchIcon from '@mui/icons-material/Search';
import SyncIcon from '@mui/icons-material/Sync';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import GlassCard from '../components/GlassCard';
import PageHeader from '../components/PageHeader';
import { omsApi, type AllocationTraceMismatchRow, type AllocationTraceResponse, type AllocationTraceSummaryRow } from '../services/omsApi';

type SortKey = keyof AllocationTraceMismatchRow;

const emptySummaryRows: AllocationTraceSummaryRow[] = [];
const emptyMismatchRows: AllocationTraceMismatchRow[] = [];

const number = new Intl.NumberFormat('en-US');

export default function AllocationOrderTrace() {
  const [fromDate, setFromDate] = useState('2026-07-12');
  const [toDate, setToDate] = useState('2026-07-13');
  const [submittedRange, setSubmittedRange] = useState<{ from: string; to: string } | null>(null);
  const [traceData, setTraceData] = useState<AllocationTraceResponse | null>(null);
  const [fetchError, setFetchError] = useState('');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState<Record<string, string>>({});
  const [sortKey, setSortKey] = useState<SortKey>('lastEvent');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const pageSize = 15;
  const summaryRows = traceData?.summary ?? emptySummaryRows;
  const mismatchRows = traceData?.mismatches ?? emptyMismatchRows;
  const inclusiveRangeDays = fromDate && toDate
    ? Math.floor((Date.parse(`${toDate}T00:00:00Z`) - Date.parse(`${fromDate}T00:00:00Z`)) / 86_400_000) + 1
    : 0;
  const dateError = fromDate && toDate
    ? fromDate > toDate
      ? 'From date must be before or equal to the to date.'
      : inclusiveRangeDays > 2
        ? 'Date range cannot exceed 2 calendar days. Select a shorter range.'
        : ''
    : '';

  const totals = useMemo(() => summaryRows.reduce((total, row) => ({
    allocationOrders: total.allocationOrders + row.allocationOrders,
    allocationQty: total.allocationQty + row.allocationQty,
    maoOrders: total.maoOrders + row.maoOrders,
    maoQty: total.maoQty + row.maoQty,
    maoCancelledOrders: total.maoCancelledOrders + row.maoCancelledOrders,
    maoCancelledQty: total.maoCancelledQty + row.maoCancelledQty,
    whseOrders: total.whseOrders + row.whseOrders,
    whseQty: total.whseQty + row.whseQty
  }), { allocationOrders: 0, allocationQty: 0, maoOrders: 0, maoQty: 0, maoCancelledOrders: 0, maoCancelledQty: 0, whseOrders: 0, whseQty: 0 }), [summaryRows]);

  const filteredMismatches = useMemo(() => {
    const global = globalSearch.trim().toLowerCase();
    return mismatchRows
      .filter((row) => {
        if (selectedWarehouse && row.fulfillmentWhse !== selectedWarehouse) return false;
        const record = Object.values(row).join(' ').toLowerCase();
        if (global && !record.includes(global)) return false;
        return Object.entries(columnSearch).every(([key, value]) => !value.trim() || String(row[key as SortKey]).toLowerCase().includes(value.trim().toLowerCase()));
      })
      .sort((a, b) => {
        const left = a[sortKey];
        const right = b[sortKey];
        const comparison = typeof left === 'number' && typeof right === 'number' ? left - right : String(left).localeCompare(String(right));
        return sortDirection === 'asc' ? comparison : -comparison;
      });
  }, [columnSearch, globalSearch, mismatchRows, selectedWarehouse, sortDirection, sortKey]);
  const pageCount = Math.max(1, Math.ceil(filteredMismatches.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const paginatedMismatches = filteredMismatches.slice((safePage - 1) * pageSize, safePage * pageSize);
  const mismatchSummary = useMemo(() => ({
    count: filteredMismatches.length,
    quantityVariance: filteredMismatches.reduce((sum, row) => sum + Math.abs(row.variance), 0),
    affectedNodes: new Set(filteredMismatches.map((row) => row.fulfillmentWhse)).size,
    unresolved: filteredMismatches.filter((row) => row.maoStatus !== 'Created' || row.whseStatus !== 'Received').length
  }), [filteredMismatches]);

  const submitTrace = async () => {
    if (!fromDate || !toDate || dateError) return;
    setLoading(true);
    setProgress(10);
    setFetchError('');
    setPage(1);
    const timer = window.setInterval(() => setProgress((current) => Math.min(current + 16, 92)), 170);
    try {
      const response = await omsApi.getAllocationOrderTrace({ fromDate, toDate, timezone: 'America/Chicago' });
      window.clearInterval(timer);
      setProgress(100);
      setTraceData(response);
      setSubmittedRange({ from: response.range?.fromDate ?? fromDate, to: response.range?.toDate ?? toDate });
      setGlobalSearch('');
      setColumnSearch({});
      setSelectedWarehouse('');
    } catch (requestError) {
      window.clearInterval(timer);
      setTraceData(null);
      setSubmittedRange(null);
      setFetchError(requestError instanceof Error ? requestError.message : 'Unable to load allocation trace data.');
    } finally {
      window.setTimeout(() => {
        setLoading(false);
        setProgress(0);
      }, 320);
    }
  };

  const changeSort = (key: SortKey) => {
    setPage(1);
    if (sortKey === key) setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
    else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  return (
    <Box>
      <PageHeader title="Allocation Order Trace" subtitle="Trace allocation orders created for destination stores and fulfilled from JC, Camp Hill, Reno, or Milton warehouses." badge="STORE ALLOCATION" />

      <GlassCard sx={{ p: { xs: 1.5, md: 2 }, mb: 2 }}>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.25} alignItems={{ xs: 'stretch', md: 'center' }}>
          <TextField size="small" type="date" label="From date" value={fromDate} onChange={(event) => setFromDate(event.target.value)} InputLabelProps={{ shrink: true }} inputProps={{ max: toDate }} sx={{ minWidth: 190 }} />
          <TextField size="small" type="date" label="To date" value={toDate} onChange={(event) => setToDate(event.target.value)} InputLabelProps={{ shrink: true }} inputProps={{ min: fromDate }} sx={{ minWidth: 190 }} />
          <Button variant="contained" startIcon={<AccountTreeIcon />} onClick={submitTrace} disabled={!fromDate || !toDate || Boolean(dateError)} sx={{ minHeight: 40, px: 2.5 }}>Run Allocation Trace</Button>
          <Typography variant="caption" color="text.secondary" sx={{ ml: { md: 'auto !important' } }}>Dates use Central Time · Maximum range: 2 calendar days</Typography>
        </Stack>
        {dateError && <Alert severity="error" sx={{ mt: 1.25 }}>{dateError}</Alert>}
        {fetchError && <Alert severity="error" sx={{ mt: 1.25 }} onClose={() => setFetchError('')}>{fetchError}</Alert>}
      </GlassCard>

      {!submittedRange && (
        <GlassCard sx={{ p: 3, textAlign: 'center' }}>
          <CalendarMonthIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h6" fontWeight={950} sx={{ mt: 1 }}>Select a date range to begin</Typography>
          <Typography color="text.secondary">The trace compares store SO order counts and quantities across Allocation, MAO, and the fulfilling warehouse.</Typography>
        </GlassCard>
      )}

      {submittedRange && (
        <Stack spacing={2}>
          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="01" title="Reconciliation Summary" subtitle={`${submittedRange.from} through ${submittedRange.to} · Store allocations grouped by fulfilling warehouse`} />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Grid container spacing={1.25} sx={{ mb: 1.75 }}>
                <SummaryKpi label="Store allocations submitted" orders={totals.allocationOrders} quantity={totals.allocationQty} tone="primary" />
                <SummaryKpi label="MAO store SO created" orders={totals.maoOrders} quantity={totals.maoQty} tone="success" />
                <SummaryKpi label="Cancelled in MAO" orders={totals.maoCancelledOrders} quantity={totals.maoCancelledQty} tone="warning" />
                <SummaryKpi label="WHSE fulfillment received" orders={totals.whseOrders} quantity={totals.whseQty} tone="info" />
                <SummaryKpi label="Actual mismatches" orders={mismatchRows.length} quantity={mismatchRows.reduce((sum, row) => sum + Math.abs(row.variance), 0)} tone="error" mismatch />
              </Grid>
              <Alert severity="info" sx={{ mb: 1.5 }}>
                MAO-cancelled store SOs are intentionally stopped before warehouse release. They remain visible in the summary but are excluded from the actionable warehouse mismatch count.
              </Alert>
              <Box sx={{ mb: 1.5 }}>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ sm: 'center' }} sx={{ mb: 1 }}>
                  <Box>
                    <Typography fontWeight={950}>Warehouse reconciliation flow</Typography>
                    <Typography variant="caption" color="text.secondary">Select a warehouse lane to focus the mismatch table.</Typography>
                  </Box>
                  {selectedWarehouse && <Chip size="small" label={`${selectedWarehouse} selected`} color="primary" onDelete={() => { setSelectedWarehouse(''); setPage(1); }} />}
                </Stack>
                <Grid container spacing={1}>
                  {summaryRows.map((row) => (
                    <Grid item xs={12} lg={6} key={`flow-${row.node}`}>
                      <WarehouseFlowLane
                        row={row}
                        selected={selectedWarehouse === row.node}
                        onSelect={() => {
                          setSelectedWarehouse((current) => current === row.node ? '' : row.node);
                          setPage(1);
                        }}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Box>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table className="sku-trace-table-style allocation-summary-table" size="small" sx={{ minWidth: 960 }}>
                  <TableHead>
                    <TableRow>
                      <TableCell rowSpan={2}>Fulfilling warehouse</TableCell>
                      <TableCell colSpan={2} align="center">Allocation → Store</TableCell>
                      <TableCell colSpan={2} align="center">MAO Store SO</TableCell>
                      <TableCell colSpan={2} align="center">Cancelled in MAO</TableCell>
                      <TableCell colSpan={2} align="center">WHSE fulfillment</TableCell>
                      <TableCell rowSpan={2} align="right">Actionable gap</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">SO orders</TableCell><TableCell align="right">Quantity</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {summaryRows.map((row) => (
                      <TableRow key={row.node} hover>
                        <TableCell><Stack direction="row" spacing={1} alignItems="center"><WarehouseIcon color="action" fontSize="small" /><Typography fontWeight={900}>{row.node}</Typography></Stack></TableCell>
                        <TableCell align="right">{number.format(row.allocationOrders)}</TableCell><TableCell align="right">{number.format(row.allocationQty)}</TableCell>
                        <TableCell align="right">{number.format(row.maoOrders)}</TableCell><TableCell align="right">{number.format(row.maoQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="warning" variant="outlined" label={number.format(row.maoCancelledOrders)} /></TableCell><TableCell align="right">{number.format(row.maoCancelledQty)}</TableCell>
                        <TableCell align="right">{number.format(row.whseOrders)}</TableCell><TableCell align="right">{number.format(row.whseQty)}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" variant="outlined" label={`-${number.format(Math.max(row.maoOrders - row.maoCancelledOrders - row.whseOrders, 0))}`} /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Box>
            </Box>
          </GlassCard>

          <GlassCard sx={{ overflow: 'hidden' }}>
            <SectionHeader number="02" title="Actual Mismatches" subtitle="Store SO-level exceptions with Allocation, MAO, and fulfilling-warehouse details side by side" />
            <Box sx={{ p: { xs: 1.4, md: 2 } }}>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: 1, mb: 1.5 }}>
                <MismatchSummaryCard label="Matching mismatches" value={mismatchSummary.count} detail="Current search and filters" tone="error" />
                <MismatchSummaryCard label="Quantity variance" value={mismatchSummary.quantityVariance} detail="Absolute unit variance" tone="warning" />
                <MismatchSummaryCard label="Affected nodes" value={mismatchSummary.affectedNodes} detail="Fulfillment locations" tone="info" />
                <MismatchSummaryCard label="Missing / unresolved" value={mismatchSummary.unresolved} detail="Needs operational review" tone="primary" />
              </Box>
              <Alert severity="info" icon={<SyncIcon />} sx={{ mb: 1.5 }}>
                <Typography fontWeight={900}>How actual mismatches are fetched</Typography>
                <Typography variant="body2">The trace joins each store allocation to its MAO SO by SO order number, identifies the assigned fulfillment warehouse, and compares that warehouse's acknowledgement and quantity. Only missing records or unequal quantities appear below.</Typography>
              </Alert>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} alignItems={{ xs: 'stretch', md: 'center' }} justifyContent="space-between" sx={{ mb: 1.25 }}>
                <TextField size="small" label="Global search" placeholder="Search any mismatch detail" value={globalSearch} onChange={(event) => { setGlobalSearch(event.target.value); setPage(1); }} sx={{ minWidth: { md: 360 } }} InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
                <Stack direction="row" spacing={1} alignItems="center"><Chip color="error" label={`${filteredMismatches.length} mismatches`} /><Typography variant="caption" color="text.secondary">Click any column heading to sort</Typography></Stack>
              </Stack>
              <Box sx={{ overflowX: 'auto', border: 1, borderColor: 'divider', borderRadius: 1.75 }}>
                <Table className="sku-trace-table-style allocation-mismatch-table" size="small" sx={{ minWidth: 1540 }}>
                  <TableHead>
                    <TableRow>
                      <SortableHead label="SO order" field="soOrder" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Destination store" field="store" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Fulfilling WHSE" field="fulfillmentWhse" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Allocation status" field="allocationStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Alloc qty" field="allocationQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO status" field="maoStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="MAO qty" field="maoQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="WHSE / Store status" field="whseStatus" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Node qty" field="whseQty" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Variance" field="variance" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Mismatch reason" field="mismatch" active={sortKey} direction={sortDirection} onSort={changeSort} />
                      <SortableHead label="Last event" field="lastEvent" active={sortKey} direction={sortDirection} onSort={changeSort} />
                    </TableRow>
                    <TableRow>
                      {(['soOrder', 'store', 'fulfillmentWhse', 'allocationStatus', 'allocationQty', 'maoStatus', 'maoQty', 'whseStatus', 'whseQty', 'variance', 'mismatch', 'lastEvent'] as SortKey[]).map((field) => (
                        <TableCell key={field} sx={{ py: 0.7 }}><TextField variant="standard" size="small" placeholder="Filter" value={columnSearch[field] ?? ''} onChange={(event) => { setColumnSearch((current) => ({ ...current, [field]: event.target.value })); setPage(1); }} InputProps={{ disableUnderline: true }} sx={{ minWidth: field === 'mismatch' ? 170 : 90, '& input': { fontSize: '.75rem', py: 0.4 } }} /></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedMismatches.map((row) => (
                      <TableRow key={row.soOrder} hover>
                        <TableCell><Typography fontWeight={950} color="primary.main">{row.soOrder}</Typography></TableCell>
                        <TableCell><Typography fontWeight={850}>{row.store}</Typography></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" color="action" /><Typography fontWeight={850}>{row.fulfillmentWhse}</Typography></Stack></TableCell>
                        <TableCell><Status value={row.allocationStatus} /></TableCell><TableCell align="right">{row.allocationQty}</TableCell>
                        <TableCell><Status value={row.maoStatus} /></TableCell><TableCell align="right">{row.maoQty}</TableCell>
                        <TableCell><Status value={row.whseStatus} /></TableCell><TableCell align="right">{row.whseQty}</TableCell>
                        <TableCell align="right"><Chip size="small" color="error" label={row.variance > 0 ? `+${row.variance}` : row.variance} /></TableCell>
                        <TableCell><Stack direction="row" spacing={0.7} alignItems="center"><ErrorOutlineIcon color="error" fontSize="small" /><Typography variant="body2" fontWeight={800}>{row.mismatch}</Typography></Stack></TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.lastEvent}</TableCell>
                      </TableRow>
                    ))}
                    {!filteredMismatches.length && <TableRow><TableCell colSpan={12}><Alert severity="success">No mismatches match the current search and column filters.</Alert></TableCell></TableRow>}
                  </TableBody>
                </Table>
              </Box>
              {filteredMismatches.length > 0 && (
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems="center" sx={{ mt: 1.4 }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing {number.format((safePage - 1) * pageSize + 1)}–{number.format(Math.min(safePage * pageSize, filteredMismatches.length))} of {number.format(filteredMismatches.length)} orders · 15 per page
                  </Typography>
                  <Pagination page={safePage} count={pageCount} onChange={(_, value) => setPage(value)} color="primary" size="small" showFirstButton showLastButton />
                </Stack>
              )}
            </Box>
          </GlassCard>
        </Stack>
      )}

      <Dialog open={loading} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 2.25 } }}>
        <DialogContent sx={{ p: 2.4 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Box><Typography variant="overline" color="primary.main" fontWeight={950}>Live reconciliation</Typography><Typography variant="h6" fontWeight={950}>{progress === 100 ? 'Trace ready' : 'Fetching order layers'}</Typography></Box>
            <Typography fontWeight={950} color="primary.main">{progress}%</Typography>
          </Stack>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 999, '& .MuiLinearProgress-bar': { borderRadius: 999 } }} />
          <Stack spacing={0.8} sx={{ mt: 1.5 }}>
            <ProgressStep done={progress >= 25} label="Allocation submissions loaded" />
            <ProgressStep done={progress >= 55} label="MAO SO orders correlated" />
            <ProgressStep done={progress >= 85} label="Store and warehouse actuals compared" />
          </Stack>
        </DialogContent>
      </Dialog>
    </Box>
  );
}

function SectionHeader({ number: sectionNumber, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return <Box sx={{ px: 2, py: 1.45, borderBottom: 1, borderColor: 'divider', bgcolor: (theme) => alpha(theme.palette.primary.main, 0.045) }}><Stack direction="row" spacing={1.2} alignItems="center"><Box sx={{ width: 36, height: 36, borderRadius: 1.3, display: 'grid', placeItems: 'center', bgcolor: 'primary.main', color: 'primary.contrastText', fontWeight: 950 }}>{sectionNumber}</Box><Box><Typography variant="h6" fontWeight={950}>{title}</Typography><Typography variant="body2" color="text.secondary">{subtitle}</Typography></Box></Stack></Box>;
}

function SummaryKpi({ label, orders, quantity, tone, mismatch = false }: { label: string; orders: number; quantity: number; tone: 'primary' | 'success' | 'info' | 'warning' | 'error'; mismatch?: boolean }) {
  return <Grid item xs={12} sm={6} lg={3}><Box sx={{ p: 1.4, height: '100%', border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.25), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.055) }}><Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography><Typography variant="h5" fontWeight={950}>{number.format(orders)}</Typography><Typography variant="body2" color="text.secondary">{mismatch ? `${number.format(quantity)} quantity variance` : `${number.format(quantity)} units · SO order level`}</Typography></Box></Grid>;
}

function MismatchSummaryCard({ label, value, detail, tone }: { label: string; value: number; detail: string; tone: 'primary' | 'info' | 'warning' | 'error' }) {
  return (
    <Box sx={{ px: 1.35, py: 1.15, border: 1, borderColor: (theme) => alpha(theme.palette[tone].main, 0.28), borderRadius: 1.6, bgcolor: (theme) => alpha(theme.palette[tone].main, 0.065), boxShadow: (theme) => `inset 4px 0 0 ${theme.palette[tone].main}` }}>
      <Typography variant="overline" color={`${tone}.main`} fontWeight={950}>{label}</Typography>
      <Typography variant="h5" fontWeight={950}>{number.format(value)}</Typography>
      <Typography variant="caption" color="text.secondary">{detail}</Typography>
    </Box>
  );
}

function WarehouseFlowLane({ row, selected, onSelect }: { row: AllocationTraceSummaryRow; selected: boolean; onSelect: () => void }) {
  const eligibleMaoOrders = Math.max(row.maoOrders - row.maoCancelledOrders, 0);
  const maoGap = Math.max(row.allocationOrders - row.maoOrders, 0);
  const warehouseGap = Math.max(eligibleMaoOrders - row.whseOrders, 0);
  return (
    <ButtonBase
      onClick={onSelect}
      aria-pressed={selected}
      sx={{
        width: '100%', p: 0, overflow: 'hidden', border: 1, borderColor: selected ? 'primary.main' : 'divider', borderRadius: 1.6,
        bgcolor: (theme) => selected ? alpha(theme.palette.primary.main, 0.08) : alpha(theme.palette.background.paper, 0.72),
        textAlign: 'left', display: 'block'
      }}
    >
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ px: 1.15, py: 0.85, color: '#fff', background: selected ? 'linear-gradient(135deg, #244f70, #2f668f)' : 'linear-gradient(135deg, #376f96, #2f668f)' }}
      >
        <Stack direction="row" spacing={0.7} alignItems="center"><WarehouseIcon fontSize="small" sx={{ color: '#fff' }} /><Typography fontWeight={950}>{row.node}</Typography></Stack>
        <Chip size="small" label={`${warehouseGap} actionable gap`} sx={{ fontWeight: 900, color: warehouseGap ? '#a0161d' : '#17633c', bgcolor: warehouseGap ? '#fde8e9' : '#e1f4e9', border: '1px solid', borderColor: warehouseGap ? '#f3b5b9' : '#abd8bc' }} />
      </Stack>
      <Stack direction="row" spacing={0.65} alignItems="stretch" sx={{ p: 1.15 }}>
        <FlowStage label="Allocation → Store" value={row.allocationOrders} detail={`${maoGap} not created`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="MAO eligible" value={eligibleMaoOrders} detail={`${row.maoCancelledOrders} cancelled`} />
        <ArrowForwardIcon color="action" sx={{ alignSelf: 'center', fontSize: 18 }} />
        <FlowStage label="WHSE received" value={row.whseOrders} detail={`${number.format(row.whseQty)} units`} />
      </Stack>
    </ButtonBase>
  );
}

function FlowStage({ label, value, detail }: { label: string; value: number; detail: string }) {
  return <Box sx={{ flex: 1, minWidth: 0, px: 0.8, py: 0.65, borderRadius: 1.1, bgcolor: (theme) => alpha(theme.palette.primary.main, 0.055) }}><Typography variant="caption" color="text.secondary" noWrap>{label}</Typography><Typography fontWeight={950}>{number.format(value)}</Typography><Typography variant="caption" color="text.secondary" noWrap>{detail}</Typography></Box>;
}

function SortableHead({ label, field, active, direction, onSort }: { label: string; field: SortKey; active: SortKey; direction: 'asc' | 'desc'; onSort: (field: SortKey) => void }) {
  const isActive = active === field;
  return <TableCell sortDirection={isActive ? direction : false} sx={{ whiteSpace: 'nowrap' }}><TableSortLabel active={isActive} direction={isActive ? direction : 'asc'} hideSortIcon={false} onClick={() => onSort(field)} sx={{ width: '100%', '& .MuiTableSortLabel-icon': { opacity: isActive ? 1 : 0.55 } }}>{label}</TableSortLabel></TableCell>;
}

function Status({ value }: { value: string }) {
  const good = ['Submitted', 'Created', 'Received'].includes(value);
  const pending = value === 'Pending';
  return <Chip size="small" variant={good ? 'outlined' : 'filled'} color={good ? 'success' : pending ? 'warning' : 'error'} label={value} />;
}

function ProgressStep({ done, label }: { done: boolean; label: string }) {
  return <Stack direction="row" spacing={0.8} alignItems="center"><CheckCircleIcon color={done ? 'success' : 'disabled'} fontSize="small" /><Typography variant="body2" fontWeight={done ? 850 : 650} color={done ? 'text.primary' : 'text.secondary'}>{label}</Typography></Stack>;
}
